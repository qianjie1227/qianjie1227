/**
 * 获取设备信息
 * @rc
 */

let statusBar = 0 //状态栏高度
let customBar = 0 // 状态栏高度 + 导航栏高度  
let windowHeight = 0
// 微信小程序胶囊
let capsule = {
	width:0,
	height:0
}
uni.getSystemInfo({
	success: (e) => {
		// #ifdef APP-PLUS
		statusBar = e.statusBarHeight
		customBar = e.statusBarHeight + 45
		windowHeight = e.windowHeight
		// #endif
		// #ifdef H5
		statusBar = 0
		customBar = e.statusBarHeight + 45
		windowHeight = e.windowHeight
		// #endif

	}
})
// console.log('statusBar', statusBar)
// console.log('customBar', customBar)
export default {
	statusBar,
	customBar,
	windowHeight
}