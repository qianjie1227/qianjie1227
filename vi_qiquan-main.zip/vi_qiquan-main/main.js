import App from './App'

// #ifndef VUE3
import Vue from 'vue'
import uView from "@/node_modules/uview-ui";
import VueI18n from 'vue-i18n'
import theme from '@/common/theme.js';
import util from '@/common/util';


Vue.use(uView)
Vue.use(VueI18n)

Vue.config.productionTip = false


Vue.prototype.$baseUrl = "https://api.bnkstock.xyz/"
Vue.prototype.$theme = theme;
Vue.prototype.$util = util;

// 设置语言环境为中文
const i18n = new VueI18n({
	locale: 'zh-Hans', // 默认语言为中文
})

App.mpType = 'app'
const app = new Vue({
	i18n, // 将i18n实例注入到Vue实例中
	...App
})
app.$mount()
// #endif

// 引入封装的请求
import request from "./utils/api.js";
Vue.prototype.$http = request;




// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif