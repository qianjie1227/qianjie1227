# vi_01
fork old 

# UpdateLog 2024.08.20
- 登入注册介面： LOGO处 放上我们自己设计的广告图片（我会发到群内）
- `position`:列表样式调整


```

@tap="goBack()"
// 根据当前平台，执行回退方式
goBack() {
	/*#ifdef APP-PLUS*/
	uni.navigateBack({
		delta: 1
	});
	/*#endif*/

	/*#ifdef H5*/
	history.back();
	/*#endif*/
},

	.college-bg {
	padding: 48rpx 24rpx 24rpx 24rpx;
	background-color: #363636;
	margin-bottom: 24rpx;
	display: flex;
	align-items: center;
}

<view class="college-bg">
	<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
	</image>
	<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Danh sách thông báo
	</view>
</view>

```