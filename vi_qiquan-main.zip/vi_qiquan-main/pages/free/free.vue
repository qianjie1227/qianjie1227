<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 130px;height: 70px;"></image>
			<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<view class="padding-10">
			<template v-if="!business || business.length<=0">
				<view style="text-align: center;margin-top: 10vh;">
					<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;"></image>
				</view>
			</template>
			<template v-else>
				<!--  @tap="productDetails(item.gid)" -->
				<view v-for="(item,index) in business" :key="index" style="background-color: #333333;"
					class="padding-10 radius10 flex flex-b margin-top-10" @tap="detailed(item.goods.name)">
					<view style="color: #fff;" class="margin-left-10">
						<view class="font-size-16 flex">
							{{item.goods.name}}
							<image mode="widthFix" src="/static/zhang.png"
								style="width: 12px;height: 12px;margin-left: 10px;" v-if="item.goods.rate>0"></image>
							<image mode="widthFix" src="/static/di	e.png"
								style="width: 12px;height: 12px;margin-left: 10px;" v-if="item.goods.rate<0"></image>
						</view>
						<view class="font-size-14" :style="$theme.setStockRiseFall(item.goods.rate>0)">
							{{item.goods.current_price .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						</view>
					</view>
					<view :style="$theme.setStockRiseFall(item.goods.rate>0)">{{item.goods.rate_num}}</view>
					<view class="flex" :style="$theme.setStockRiseFall(item.goods.rate>0)">{{item.goods.rate}}%
						<image src="/static/stock_follow.png" mode=""
							style="width: 20px;height: 20px;margin-left: 10px;"></image>
					</view>
				</view>
			</template>
		</view>

	</view>
</template>

<script>
	export default {

		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: [],
				updata: true,
				exchange: [],
				timerId: null
			}
		},
		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			// this.versionUpdate()
			this.free()
			// this.market()
			this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			console.log('自选结束1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('自选结束2');
			clearInterval(this.timerId);
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Đang tải',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.free()
			uni.stopPullDownRefresh()
		},
		methods: {
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//产品详情
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},


			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				console.log(`??`, list.data.data.list);
				this.business = list.data.data.list
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: gid,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = false
					this.updata = true
					this.free()
					// this.$router.go(0)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			// async market() {
			// 	let list = await this.$http.get('api/goods/updownlist', {
			// 		page: 1,
			// 		limit: 10,
			// 	})
			// 	//上证指数
			// 	this.exchange = list.data.zhishu
			// },
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			// //版本更新
			// async versionUpdate() {
			// 	let list = await this.$http.get('api/version/detail', {})
			// 	this.update = list.data.data
			// 	let version = list.data.data.version
			// 	let old_version = uni.getStorageSync('version') || 1.0
			// 	// console.log(list.data.data, '当前版本111111111111111');
			// 	if (old_version < version) {
			// 		this.updateFlag = true
			// 		this.$refs.update.upgrade()
			// 		uni.setStorageSync('version', version)
			// 	}
			// },
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('自选请求');
					this.free();
					// this.market()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
				// this.free();
				// this.market()
			},

		},
		//刚出来的时候加载
		// mounted() {
		// 	this.free()
		// 	// this.market()
		// 	this.versionUpdate()
		// 	// this.is_token()

		// },

	}
</script>

<style lang="scss">

</style>