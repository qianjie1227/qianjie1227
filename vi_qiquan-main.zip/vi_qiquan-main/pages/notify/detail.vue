<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Danh sách thông báo
			</view>
		</view>
		<view style="padding:36rpx;">
			<view v-html="item.content"> </view>
		</view>
	</view>
</template>

<script>
</script>

<style>
</style>