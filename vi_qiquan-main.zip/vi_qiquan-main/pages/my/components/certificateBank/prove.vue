<!-- 证转银 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding:0 80rpx;">
					<view style="text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;" @click="linkTo()">
						Nộp tiền 
					</view>
					<view style="text-align: center;color: #3E6EB2;font-size: 32rpx;font-weight: 500;">
						Rút tiền
					</view>
				</view>
			</view>
		</view>
		<view style="background-color: #242424;padding:12rpx 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tài sản của tôi
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Tài sản của tôi</view>
			</view>
			<view style="border-radius: 20rpx;background-image: url(/static/position_card_bg.png);
		background-repeat: no-repeat;background-position: 0 0;background-size: 100% 100%;">
				<view style="display: flex;flex-direction: column;justify-content: space-between;">
					<view style="padding: 30rpx;0 24rpx 24rpx;">
						<view style="display: flex;align-items: center;">
							<view style="color: #fff;">Tổng tài sản (VND)</view>
							<image :src="`/static/mask_${isMask?'hide':'show'}.png`" mode="aspectFit"
								style="width: 32rpx;height: 32rpx;padding-left: 12rpx;" @click="toggleMask()">
							</image>
						</view>
						<view style="font-size: 48rpx;font-weight: 700;color: #fff;line-height: 2;">
							{{isMask?`******`: toThousandFilter(userInformation.totalZichan*1+userInformation.holdYingli*1)}}
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng lãi lỗ</view>
							<view :style="{color:userInformation.holdYingli>0?'aqua':'red'}">
								{{isMask?`******`: toThousandFilter(userInformation.holdYingli)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng giá trị thị trường</view>
							<view style="color: #fff;">{{isMask?`******`: toThousandFilter(userInformation.frozen)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Sức mua</view>
							<view style="color: #fff;">{{isMask?`******`: toThousandFilter(userInformation.money)}}
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>

		<view style="background-color: #242424;padding:12rpx 24rpx;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số tiền rút
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Số tiền rút</view>
			</view>
			<view class="input_wrapper">
				<image src="/static/icon_sub.png" mode="aspectFit"
					style="width: 48rpx;height: 48rpx;padding-right: 24rpx;" @click="handleSub()"></image>
				<input placeholder="Vui lòng nhập số tiền cần rút " type="number" v-model="value1"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image src="/static/icon_add.png" mode="aspectFit" style="width: 48rpx;height: 48rpx;margin-left: auto;"
					@click="handleAdd()"></image>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Mật khẩu rút tiền
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Mật khẩu rút tiền
				</view>
			</view>
			<view class="input_wrapper">
				<template v-if="isMask">
					<input placeholder="Vui lòng nhập mật khẩu rút tiền" type="password" v-model="value2"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<template v-else>
					<input placeholder="Vui lòng nhập mật khẩu rút tiền" type="text" v-model="value2"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>
		</view>

		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="to_withdraw()">
			Xác nhận
		</view>

		<!-- <view class="point-out">
			<view>1、Lệnh hiện tại không thể rút tiền。</view>
			<view>2、Xin vui lòng rút tiền bằng tên thật và thẻ ngân hàng.。</view>
			<view>3、Thời gian rút tiền là 9:30 - 11:30 sáng, 1:00 - 3:00 chiều。</view>
			<view>4、Số tiền rút tối thiểu 100。</view>
			<view>
				5、<text>Rút tiền trong thời gian rút tiền thường là 2 giờ đến tài khoản, thời gian rút tiền bị ảnh hưởng bởi thời gian thanh toán giữa các ngân hàng, thời gian đến tài khoản của các ngân hàng khác nhau, muộn nhất T+1 đến tài khoản trước 24 giờ ngày hôm sau</text>
			</view>
		</view> -->



	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: null,
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		onShow() {
			this.isMask = uni.getStorageSync('mask');
		},
		methods: {
			linkTo() {
				uni.navigateTo({
					url: '/pages/my/components/certificateBank/silver',
				})
			},
			handleSub() {
				if (this.value1 <= 0) {
					return false;
				}
				this.value1 = this.value1 * 1 - 1;
			},
			handleAdd() {
				this.value1 = this.value1 * 1 + 1;
			},

			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 根据当前平台，执行回退方式
			goBack() {
				uni.switchTab({
					url: `/pages/index/index`
				})
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			async to_withdraw() {
				uni.showLoading({
					title: "Xin chờ một chút....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data

			},

		},

		onLoad(option) {
			this.gaint_info()
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		// background: #180d2b;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #fff;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>