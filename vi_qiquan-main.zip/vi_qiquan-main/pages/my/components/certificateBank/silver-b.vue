<!-- 银转证 -->
<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Nạp tiền</view>
				<view class=""></view>
			</view>
			<!-- 	<view class="progress">¥ {{userInformation.money}}</view>
			<view class="vacancies">当前可用余额</view> -->
		</view>
		<view class="content">
			Xin vui lòng liên hệ với dịch vụ khách hàng trực tuyến để xin thẻ tín dụng.
		</view>
		<view class="content">
			Xin vui lòng nhắc nhở bạn: Số thẻ tín dụng của bạn chỉ được sử dụng trong thời gian bạn đăng ký (trong vòng 30 phút), quá thời hạn, để đảm bảo an toàn cho tiền của bạn và cho bạn sử dụng giao dịch ngay từ đầu, vui lòng nhận được số thẻ tín dụng của bạn để chuyển tiền trước tiên, vào những thời điểm khác không được tự ý chuyển tiền vào số thẻ này, nếu việc chuyển tiền vi phạm gây ra bất kỳ tổn thất nào cho bạn đều do bạn tự chịu, Nếu có thắc mắc gì, bạn có thể liên hệ với tư vấn dịch vụ khách hàng trực tuyến bất cứ lúc nào.
		</view>
		<view class="ermai">
			<view class=""></view>
			<view class="kefu" @tap="customer()">
				<u-icon name="kefu-ermai" color="#B9B9B9" size="28"></u-icon>
				<view class="kefu-text">Dịch vụ</view>
			</view>

		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInformation: "",

			};
		},
		methods: {

			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
				});
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},

		},

		onLoad(option) {
			this.gaint_info()
		},
		mounted() {
			this.gaint_info()

		}
	}
</script>

<style lang="scss">
	page {
		background: #989898;
	}

	.college-bg {
		padding: 60rpx 30rpx 100rpx;
		// height: 280rpx;
		background: #989898;


		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #B9B9B9;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #f47b78;
			font-size: 26rpx;
		}
	}

	.content {
		color: #B9B9B9;
		padding: 30rpx;
		font-size: 36rpx;
		font-weight: 600;
		letter-spacing: 0.1em;
	}

	.ermai {
		// display: flex;
		// justify-content: space-between;
		// padding: 30rpx 60rpx;
		position: fixed;
		right: 30rpx;
		bottom: 300rpx;
	}

	.kefu {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	/deep/.u-icon {
		background: #FEFEFE !important;
		border-radius: 50% !important;
		width: 80rpx !important;
		height: 80rpx !important;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.kefu-text {
		color: #B25836;
		font-size: 24rpx;
		margin: 20rpx 0 0;
	}
</style>