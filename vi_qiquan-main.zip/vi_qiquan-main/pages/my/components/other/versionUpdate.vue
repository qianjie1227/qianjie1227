<!-- 版本更新 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">{{agreement.title}}</view>
			<view class=""></view>
		</view>
		<!-- 	<view class="college-content">
			<view class="about">
				<view>
					<image src="../../../../static/logo.png"></image>
				</view>
				<view class="ouyi-name">浙商</view>
				<view class="edition">版本:6.1.58</view>
			</view>

			<view>
				<u-cell title="检查版本" isLink :border="border">
					<text slot="value">已经是最新版本</text>
				</u-cell>
			</view>
		</view> -->
		<view class="">
			<view class="" v-html="agreement.content"></view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				agreement: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			async edition() {
				let list = await this.$http.get('api/version/detail', {
					// language: this.$i18n.locale
				})
				this.agreement = list.data.data
			},
		},
		mounted() {
			this.edition()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

		.about {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			margin: 30rpx 0;

			image {
				width: 200rpx;
				height: 200rpx;
			}

			.ouyi-name {
				font-size: 46rpx;
				font-weight: 900;
				margin: 20rpx 0;
			}

			.edition {
				font-size: 25rpx;
				color: #929292;
			}
		}

	}
</style>
