<template>
	<view>
		<view class="college-bg">
			<view style="display: flex;	align-items: center;">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;"
					@tap="goBack()">
				</image>
				<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">ETF
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 12rpx;">
				<block v-for="(item,index) in tabs">
					<view style="font-weight: 700;font-size: 32rpx;" @click="sectionChange(index)"
						:style="{color:current==index?'#6FAAFD':'#999999',borderBottom:`6rpx solid ${current==index?'#6FAAFD':'transparent'}`}">
						{{item}}
					</view>
				</block>
			</view>
		</view>

		<view v-if="current==0">
			<!-- <view class="tile">Vốn tối ưu</view> -->
			<!-- <view class="boxk">Vốn tối ưu, thu nhập tốt hơn</view> -->
			<view class="stock-fund" v-for="(item,index) in list">
				<view class="information">
					<view class="help">
						<image src="/static/chuanggai/new-logo.png" mode=""></image>
						<view style="color: #fff;">{{item.name}}</view>
					</view>
					<!-- <view class="detailed">
						<view class="">详情</view>
						<image src="../../../../static/jiantou.png" mode=""></image>
					</view> -->
				</view>
				<view class="increase">
					<view class="help">
						<image src="../../../../static/jijin/zhang.png" mode=""></image>
						<view class=""> {{item.syl}}
							<!-- <text style="font-size: 24rpx;"> %</text> -->
						</view>
					</view>
					<view class="detailed" style="color: #FFF;">
						<view class="">{{item.zhouqi}} ngày</view>
					</view>
				</view>
				<view class="last" style="padding-bottom: 24rpx;">
					<view class="help" style="color:#CCC;">
						{{item.gz==1?'Nhận lãi hàng ngày':'Nhận lãi từ thứ hai đến thứ sáu'}}
					</view>
					<view class="detailed" style="color: #CCC;">
						{{toThousandFilter(item.min_price)}}
					</view>
				</view>

				<view class="btn_common" style="font-size: 32rpx;width: 80%;margin:6rpx auto;line-height: 48rpx;"
					@click="buy(index)">
					Mua
				</view>
			</view>

			<!-- ws 获取的理财资金 -->
			<view class="stock-fund">
				<view style="display: flex;align-items: center;line-height: 1.6;font-size: 32rpx;color:#AAA;">
					<view style="flex:1;">Tên</view>
					<view style="flex:0 0 40%;">Giá hiện tại</view>
					<view style="margin: auto;">Tăng</view>
				</view>
				<block v-for="(item,index) in wealthNames" :key="item.name">
					<view
						style="display: flex;align-items: center;line-height: 1.8;padding-bottom: 12rpx;border-bottom: 1px solid #666;">
						<view style="flex:1;">{{item.name}}</view>
						<view style="flex:0 0 40%;" :style="{color:item.current_price*1>0?`#12F6B8`:`#FF2D30`}">
							{{item.current_price}}
						</view>
						<view style="margin: auto;">
							<view style="padding-right: 24rpx;" :style="{color:item.rate*1>0?`#12F6B8`:`#FF2D30`}">
								{{item.rate}}%
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<view v-if="current==1">
			<view style="background-color: #333;font-size: 14px;" class="padding-10 margin-10"
				v-for="(item,index) in order_list">
				<view class="flex flex-b color-white ">
					<view>Mua Quỹ FUESVS</view>
					<view style="color: #f6ab44;">Quỹ ETF SVS</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Số tiền </view>
					<view style="color: #f6ab44;">{{toThousandFilter(item.price)}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Chu kỳ đáo hạn quỹ</view>
					<view style="color: #f6ab44;">{{item.zhouqi+' ngày'}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Ngày thanh toán</view>
					<view style="color: #f6ab44;">{{item.endtime}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Mã giao dịch</view>
					<view style="color: #f6ab44;">{{item.ordersn}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Margin (Đòn bẩy)</view>
					<view style="color: #f6ab44;">{{item.ganggan}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Lợi nhuận hiện tại </view>
					<view style="color: #f6ab44;">{{item.syl}}</view>
				</view>

				<view @click="sell(item.id)" v-if="item.status==1" class="text-center padding-5 margin-top-10 radius10"
					style="color:#FFF;background-color: #FF2D30; ">Bán</view>
			</view>

		</view>

		<u-modal :show="xiangqing_show" title="Chi tiết lợi nhuận" :closeOnClickOverlay="true"
			:showConfirmButton="false" @close="xiangqing_show=false" @confirm="confirm" @cancel="xiangqing_show=false">
			<view class="slot-content" style="position: relative;width: 100%;">

				<view v-for="(item,index) in xq_list">
					<u-cell :title="item.created_at" :value="'+'+item.shouyi"></u-cell>
				</view>
			</view>

		</u-modal>

		<u-modal :show="show_js" :title="title" :content='content' :closeOnClickOverlay="true"
			:showConfirmButton="false" @close="show_js=false">
			<view class="slot-content">
				<rich-text :nodes="content"></rich-text>
			</view>
		</u-modal>


		<u-modal :show="show_buy" :title="`Mua Quỹ FUESVS`" confirmText="Mua" cancelText="Huỷ bỏ" @confirm="confirm"
			:showCancelButton="true" @cancel="show_buy=false" cancelColor="#CCC">
			<view style="width: 100%;">
				<view style="display: flex;align-items: center;">
					<view class="color-white" style="padding-right: 40rpx;">Số tiền</view>
					<view style="border-bottom: 1px solid #CACACA;">
						<input type="number" placeholder='' v-model="price"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view class="color-white" style="padding-right: 40rpx;">Margin</view>
					<view style="border-bottom: 1px solid #CACACA;">
						<input type="number" placeholder='' v-model="ganggan"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</view>
				</view>
			</view>
		</u-modal>
		<u-action-sheet :show="show" :actions="actions" title="Bội số (đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ganggan: 10,
				show: false,
				actions: [{
					name: '1',
					index: 1
				}],
				current: 0,
				show_js: false,
				title: "",
				content: "",
				show_buy: false,
				list: [],
				jijin_name: '',
				goods_buy: [],
				price: '',
				order_list: [],
				xiangqing_show: false,
				xq_list: [],
				socket: null,
				isConnected: false, // 是否链接socket
				wealthNames: [],
			};
		},
		computed: {
			tabs() {
				return [`Quỹ ETF SVS`, `Đơn hàng`]
			},
		},
		onShow() {
			if (this.socket) this.disconnect();
			this.getlist()
			this.userInfo()
		},
		onHide() {
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			async sell(id) {
				uni.showModal({
					content: "Bạn có chắc chắn muốn bán không?",
					cancelText: "Hủy bỏ",
					confirmText: "Bán",
					success: (res) => {
						if (res.confirm) {
							this._sell(id)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}

				})

			},
			async _sell(id) {
				var list = await this.$http.get('api/jijin/sell', {
					id: id,
				})
				uni.hideLoading()
				if (list.data.code == 1) {

					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				if (list.data.code == 1) {
					uni.reLaunch({
						url: "/pages/logon/logon/logon"
					})
				}
				this.actions = list.data.data.ganggan
			},
			async xiangqing(id) {

				var list = await this.$http.post('api/jijin/info', {
					id: id,

				})

				console.log(list)
				this.xq_list = list.data
				this.xiangqing_show = true
			},
			buy(index) {
				this.jijin_name = this.list[index].name
				this.show_buy = true
				this.goods_buy = this.list[index]
			},
			jieshao(index) {
				console.log(index);
				this.content = this.list[index].content
				this.show_js = true
			},
			confirm() {
				console.log(this.goods_buy);
				var price = this.price
				this.show_buy = false
				uni.showLoading({

				})
				if (!price || price == '') {
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('Vui lòng nhập số tiền');
				}


				this.buy_goods(price)
			},
			async buy_goods(price) {

				var list = await this.$http.get('api/jijin/buy', {
					id: this.goods_buy.id,
					price: price,
					ganggan: this.ganggan
				})
				uni.hideLoading()
				if (list.data.code == 1) {
					this.show_buy = false
					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast("Giao dịch thành công ");
					this.getlist()
				}

			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("基金列表", list);
				this.list = list.data.jj_list
				this.order_list = list.data.order;

				if (this.current == 0) {
					
					var etf_list = await this.$http.post('api/goods/list')
					console.log(11111,etf_list);

					
					this.wealthNames = etf_list.data.data
					this.connect();
				}
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WsUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res);
						uni.sendSocketMessage({
							data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`
						});
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});

					this.socket.send({
						data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`,
						success: (res) => {
							console.log(`send res:`, res);
						}
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(`data:`, data)
						// wealthNames
						this.wealthNames.forEach(item => {
							if (item.name == data[0]) {
								console.log(item.name, data[41])
								if(data[41]*1>0){
									item.current_price = data[41];
									item.rate = data[52];
								}
								
							}
						});
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			// socket() {
			// 	var that = this;
			// 	uni.onSocketClose(function(res) {
			// 		console.log('WebSocket 已关闭！');
			// 	});

			// 	uni.connectSocket({
			// 		url: this.$http.WsUrl,
			// 		success(res) {
			// 			console.log("连接成功");
			// 		},
			// 		fail() {
			// 			console.log("连接失败");
			// 		}
			// 	});
			// 	uni.onSocketOpen(function(res) {
			// 		console.log('WebSocket连接已打开！');
			// 		uni.sendSocketMessage({
			// 			data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`
			// 		});

			// 	});
			// 	uni.onSocketMessage(function(res) {
			// 		// console.log('收到服务器内容：' + );
			// 		var arr = JSON.parse(res.data);
			// 		console.log('收到服务器内容：' + arr);

			// 		// 然后再获取第41个是实时价
			// 		// 52是上涨比例

			// 		// wealthNames
			// 		that.wealthNames.forEach(item => {
			// 			if (item.name == arr[0]) {
			// 				item.current_price = arr[41];
			// 				item.rate = arr[52];
			// 			}
			// 		});

			// 		// if (that.productDetails.name == arr[0]) {
			// 		// 	console.log('收到服务器内容：' + arr);
			// 		// 	// console.log('goods：' + arr[53]);
			// 		// 	that.today.current_price = arr[41]
			// 		// 	that.today.rate = arr[52]
			// 		// }
			// 	});
			// 	uni.onSocketError(function(res) {
			// 		console.log('WebSocket连接打开失败，请检查！');
			// 		uni.showToast({
			// 			icon: 'none',
			// 			title: 'Mạng chậm'
			// 		})
			// 	});
			// },




			sectionChange(index) {
				console.log(index)
				this.current = index;
				if (this.socket) this.disconnect();
				this.getlist();
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			fundDetails() {
				uni.navigateTo({
					url: '/pages/index/components/fund/fundDetails'
				});
			}

		}
	}
</script>


<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 0 24rpx;
		background-color: #363636;
		border-bottom: 1px solid #9F9DA0;
		margin-bottom: 24rpx;
	}

	//  u-picker 样式覆盖
	/deep/.u-modal {
		background-color: #333 !important;

		.u-modal__title {
			color: #FFF;
		}
	}

	.active {
		color: #FFF;
		background-image: linear-gradient(90deg, #3E6EB2, #26397B);
		font-weight: bold;
		display: flex;
		justify-content: center;
		padding: 5px;
		border-radius: 30px;
	}

	.u-modal uni-view .u-modal__content {
		flex-direction: column !important;
	}

	.u-subsection--button {
		height: 90rpx;
	}

	.slot-content {
		flex-direction: column !important;
	}

	.u-subsection__bar .u-subsection--button__bar {
		height: 39px;
	}


	.tile {
		color: #333;
		font-size: 32rpx;
		font-weight: 500;
		margin: 10rpx 20rpx;
		font-weight: 700;
	}

	.boxk {
		color: rgb(153, 153, 153);
		margin: 0px 20rpx;
		font-size: 24rpx;
	}

	.stock-fund {
		margin: 20rpx 20rpx;
		background-color: #333;
		padding: 40rpx 20rpx;
		border-radius: 10rpx;
		color: #fff;
	}

	.information {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;
			color: #000;

			view {
				font-weight: bold;
			}

			image {
				width: 30rpx;
				height: 30rpx;
				margin-right: 10rpx;
			}
		}

		.detailed {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.increase {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx 0;

		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;

			view {
				font-weight: bold;
				color: #09a592;
				font-size: 36rpx;
			}

			image {
				width: 36rpx;
				height: 36rpx;
				margin-right: 10rpx;
			}
		}

		.detailed {
			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.last {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			color: #999999;
			font-size: 24rpx;
		}

		.detailed {
			color: #999999;
			font-size: 24rpx;
		}
	}

	uni-modal {
		background-color: #333 !important;
	}

	uni-modal .uni-modal__title {
		font-size: 14px !important;
	}
</style>