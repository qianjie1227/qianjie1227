<template>
	<view>

		<view class="before" :class="isShow">
			<view>时间:{{curData.day}};</view>
			<view>开:{{curData.open}};</view>
			<view>收:{{curData.close}};</view>
			<view>高:{{curData.high}};</view>
			<view>低:{{curData.low}};</view>
			<view>成交:{{curData.volume}};</view>
		</view>
		<canvas canvas-id="apPsgoaaWguBOdLhQYwUOuJaYrTlPHFu" id="apPsgoaaWguBOdLhQYwUOuJaYrTlPHFu" class="charts"
			@getIndex="getIndex" @touchstart="touchstart" @touchmove="touchmove" @touchend="touchend" />
	</view>
</template>

<script>
	import uCharts from '@/uni_modules/qiun-data-charts/js_sdk/u-charts/u-charts.js';
	var uChartsInstance = {};
	export default {
		data() {
			return {
				cWidth: 650,
				cHeight: 200,
				list: [],
				curData: {},
				isShow: "domhide",
			};
		},
		mounted() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(650);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(200);
			// this.getServerData();
			this.homeKLine()
		},
		methods: {
			getIndex(cur) {
				// console.log(cur, 'curuuu')
			},
			// K线首页
			async homeKLine() {
				let list = await this.$http.get('api/kline/index', {})
				// console.log(list.data.data, '99999999');
				this.getServerData(list.data.data)
				this.list = list.data.data
			},
			getServerData(data) {
				//模拟从服务器获取数据时的延时
				// setTimeout(() => {
				//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
				// console.log(data, 'data')
				const obj = {}
				data.forEach(item => {
					// console.log(item.day)
					// const day = item.day
					// const day = item.day.split(" ")[0] //截取时间字段
					const day = item.day.split(" ")[0].substring(5) //截取时间字段
					const time = item.day.split(" ")[1].substring(0, 5)
					if (obj[day]) {
						obj[day].push(time)
					} else {
						obj[day] = [day]
					}
				})
				let list = Object.values(obj).flat()
				let res = {
					categories: list,
					series: [{
						name: "高",
						data: data.map(item => Number(item.high))
					}, ]
				};

				this.drawCharts('apPsgoaaWguBOdLhQYwUOuJaYrTlPHFu', res, data);
				// }, 500);
			},
			tab(e) {
				// console.log(e)
			},
			drawCharts(id, data, formData) {
				const ctx = uni.createCanvasContext(id, this);
				// console.log(formData, 'd')
				uChartsInstance[id] = new uCharts({
					type: "area",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					categories: data.categories,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 15, 60],

					fontSize: 12,
					fontColor: "#666666",
					dataLabel: false,
					dataPointShape: false,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					//拖拽
					enableScroll: true,
					enableMarkLine: true,
					legend: {
						show: false,
						position: "top",
						float: "center",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						lineHeight: 11,
						hiddenColor: "#CECECE",
						itemGap: 20
					},
					xAxis: {
						disableGrid: true,
						disabled: false,
						axisLine: false,
						axisLineColor: "#CCCCCC",
						calibration: false,
						fontColor: "#666666",
						fontSize: 10,
						lineHeight: 10,
						marginTop: 0,
						rotateLabel: false,
						rotateAngle: 45,
						itemCount: 40,
						boundaryGap: "justify",
						splitNumber: 5,
						gridColor: "#CCCCCC",
						gridType: "solid",
						dashLength: 1,
						gridEval: 1,
						scrollShow: false,
						scrollAlign: "left",
						scrollColor: "#A6A6A6",
						scrollBackgroundColor: "#EFEBEF",
						title: "",
						titleFontSize: 13,
						titleOffsetY: 0,
						titleOffsetX: 0,
						titleFontColor: "#666666",
						formatter: "",
						// 限制数量
						labelCount: 20,
					},
					yAxis: {
						gridType: "dash",
						dashLength: 2,
						disabled: true,
						disableGrid: false,
						splitNumber: 5,
						gridColor: "#CCCCCC",
						padding: 10,
						showTitle: false,
						data: [],
						// position: 'right'
					},
					extra: {
						area: {
							type: "straight",
							opacity: 0.2,
							addLine: true,
							width: 1,
							gradient: true,
							activeType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: false,
							legendShape: "circle",
							splitLine: true,
							horizentalLine: true,
							xAxisLabel: false,
							yAxisLabel: true,
							labelBgColor: "#d7595b",
							labelBgOpacity: 0.7,
							labelFontColor: "#fff"
						},
						markLine: {
							type: "solid",
							dashLength: 4,
							data: []
						}
					}
				});
			},
			touchstart(e) {
				uChartsInstance[e.target.id].scrollStart(e);
				// console.log(1)
			},
			touchmove(e) {
				uChartsInstance[e.target.id].scroll(e);
				// console.log(e)
			},
			touchend(e) {
				// e.changedTouches[0].x = e.changedTouches[0].x - 50
				// e.changedTouches[0].y = e.changedTouches[0].y + 280
				uChartsInstance[e.target.id].scrollEnd(e);
				const index2 = uChartsInstance[e.target.id].showToolTip(e);
				const index1 = uChartsInstance[e.target.id].touchLegend(e);
				const index = uChartsInstance[e.target.id].getCurrentDataIndex(e);
				this.curData = this.list[index.index]
				console.log(this.curData, '点击跟踪数据,别点击空白地方');
				this.isShow = "domshow";
				console.log('为', this.isShow);
			},
		}
	};
</script>

<style lang="scss">
	.before {
		color: #D4D7DC;
		font-size: 24rpx;



		view {
			margin-right: 10rpx;
		}
	}

	.charts {
		width: 1600rpx;
		height: 200rpx;
	}

	.domhide {
		display: none;
	}

	.domshow {
		display: flex;
		flex-wrap: wrap;
		width: 40%;
	}
</style>