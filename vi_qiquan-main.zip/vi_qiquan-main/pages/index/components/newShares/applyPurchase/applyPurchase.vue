<!-- 申购 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;"
				@tap="$util.goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">
				ĐĂNG KÝ MUA
			</view>
		</view>

		<view class="" v-for="(item,index) in list" :key="index">
			<view style="background-color: #333;font-size: 14px;line-height: 1.6;" class="padding-10 margin-10">
				<view class="flex flex-b color-white ">
					<view>{{item.goods.name}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Giá mua</view>
					<view style="color: #FFF;">{{toThousandFilter(item.price)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Khối lượng</view>
					<view style="color: #FFF;">{{toThousandFilter(item.apply_amount)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Margin (Đòn bẩy)</view>
					<view style="color: #FFF;">{{item.ganggan}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Số tiền thanh toán</view>
					<view style="color: #FFF;">{{toThousandFilter(item.apply_num_amount/item.ganggan) }}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Thời gian mua</view>
					<view style="color: #FFF;">{{item.created_at}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Mã giao dịch</view>
					<view style="color: #FFF;">{{item.order_sn}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Trạng thái</view>
					<view style="color: #f6ab44;">{{item.message}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
			};
		},
		onShow() {
			this.shengou()
		},
		onLoad(option) {},
		methods: {
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// 申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}
</style>