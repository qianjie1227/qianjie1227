<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Mở tài khoản</view>
				<view class=""></view>
			</view>
			<view class="progress-bar">
				<u-steps current="-1" iconSize='30' style="margin-left: 0px;">
					<u-steps-item iconSize='30' title="Đăng ký"></u-steps-item>
					<u-steps-item iconSize='30' title="Chứng nhận"></u-steps-item>
					<u-steps-item iconSize='24' title="Nhập tiền"></u-steps-item>
					<u-steps-item iconSize='24' title="Giao dịch"></u-steps-item>
				</u-steps>
			</view>
		</view>


		<view class="kapi">
			<view>Gợi ý ấm áp</view>
			<view>1、Giờ mở tài khoản trực tuyến: Thứ Hai đến Thứ Sáu 08:00 - 18:00</view>
			<view>2、Mở tài khoản trực tuyến tạm thời chỉ áp dụng cho khách hàng cá nhân Trung Quốc đại lục từ 18 tuổi trở lên và có thẻ căn cước thế hệ thứ hai của cư dân nước Cộng hòa Nhân dân Trung Hoa trong thời hạn có hiệu lực。</view>
			<view>3、Vui lòng nhập tên thật và số chứng minh thư của bạn sau đó nhấp vào Gửi, hệ thống tự động kiểm tra。</view>
		</view>

		<view class="prepare">

			<u-divider text="请准备好"></u-divider>
		</view>
		<view class="preparation">
			<view class="please">
				<image src="../../../../static/kaihu/shengfengzheng.png" mode=""></image>
				<view class=""> Chứng minh thư</view>
			</view>
			<view class="please">
				<image src="../../../../static/kaihu/yinghangka.png" mode=""></image>
				<view class=""> Thẻ ngân hàng </view>
			</view>
			<view class="please">
				<image src="../../../../static/kaihu/wangluo.png" mode=""></image>
				<view class=""> Môi trường mạng</view>
			</view>
		</view>




		<view @tap="authentication()" class="purchase">
			Tiếp theo
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		onLoad() {
			uni.redirectTo({
				url:"/pages/marketQuotations/authentication"
			})
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			authentication() {
				uni.navigateTo({
					url: '/pages/marketQuotations/authentication'
				});
			}
		}
	}
</script>

<style lang="scss">
	page {
		background: #f0f0f0;
	}
	
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress-bar {
			margin: 80rpx 30rpx;

			/deep/.u-steps-item__wrapper {
				background-color: transparent;
			}

			/deep/.u-steps-item__wrapper__circle {
				background: #fff !important;
			}

			/deep/.u-text__value--content {
				color: #fff !important;
				margin-right: 20rpx;
			}
		}
	}

	.prepare {
		text-align: center;
		color: #333;
		font-size: 30rpx;
		font-weight: 800;
		text-align: center;
		margin: 60rpx 0;
	}

	.preparation {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 60rpx 30rpx;
		font-size: 26rpx;

		.please {
			width: 33%;
			text-align: center;
			font-size: 26rpx;

			image {
				width: 80rpx;
				height: 80rpx;
			}
		}


		.identity-no {
			font-size: 30rpx;
			margin: 10rpx 0;

			text {
				background: hsla(0, 0%, 100%, .2);
				border-radius: 10rpx;
				font-size: 12rpx;
				margin-left: 10rpx;
			}
		}

		.bank-no {
			font-size: 30rpx;
			margin: 10rpx 0;

			text {
				background: hsla(0, 0%, 100%, .2);
				border-radius: 10rpx;
				font-size: 12rpx;
				margin-left: 10rpx;
			}

		}

		.network-no {
			font-size: 30rpx;
			margin: 10rpx 0;

			text {
				background: hsla(0, 0%, 100%, .2);
				border-radius: 10rpx;
				font-size: 12rpx;
				margin-left: 10rpx;
			}
		}
	}

	.kapi {
		padding: 20rpx 40rpx;
		margin: 30rpx;
		background: #fff;
		border-radius: 10rpx;
		font-size: 26rpx;

		view {
			margin: 20rpx 0;
		}
	}

	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>