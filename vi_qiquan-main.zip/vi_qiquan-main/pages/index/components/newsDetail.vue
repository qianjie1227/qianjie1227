<!-- 学院 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Tin tức</view>
		</view>
		<view class="college-content">
			<rich-text :nodes="html"></rich-text>
			<!-- <view class="" v-html='html'> -->

		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: {},
				html: '',
				id: ""
			};
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			async gain_views(e) {
				let list = await this.$http.get('api/article/info', {
					id: e,
				})
				this.list = list.data.data
				this.html = list.data.data.content || ''
				// console.log(this.html)
			},
		},
		onLoad(option) {
			this.title = option.title
			this.gain_views(option.id)
			this.id = option.id
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		padding: 30rpx;
		color: #fff;

		.time {
			color: #aaa;
		}

		image {
			margin: 30rpx 0;
			width: 100% !important;
		}

		img {
			width: 100% !important;
			// margin-left: -60rpx;
		}


	}

	p {
		margin: 30rpx 0;
		text-align: left;
		color: #fff;
		// text-indent: 2em;
	}
</style>