<!-- 客服 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">SIERRA CSKH

			</view>
		</view>

		<view
			style="display: flex;align-items: center;justify-content: space-between;color: #fff;padding:12rpx 24rpx 24rpx 24rpx;">
			<view>
				<view>SIERRA CSKH</view>
				<view>Mọi thắc mắc xin vui lòng liên hệ chúng tôi.</view>
			</view>
			<view style="margin-left: auto;">
				<image src="/static/centet_service.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;"></image>
			</view>
		</view>

		<u-cell-group>
			<u-cell icon="/static/chuanggai/logo.png" title="SIERRA CSKH trực truyến" isLink
				url="/pages/componentsB/tag/tag" iconStyle="width:90rpx;height:90rpx;"
				titleStyle="margin-left:20rpx;color:#fff" @click="link(1)"></u-cell>
			<u-cell icon="/static/kefu/zalo1.png" title="ZALO CSKH trực truyến" isLink url="/pages/componentsB/tag/tag"
				iconStyle="width:90rpx;height:90rpx;" titleStyle="margin-left:20rpx;color:#fff"
				@click="handleModal()"></u-cell>
			<u-cell icon="/static/kefu/telegram.png" title="Telegram CSKH trực truyến" isLink
				url="/pages/componentsB/tag/tag" iconStyle="width:90rpx;height:90rpx;"
				titleStyle="margin-left:20rpx;color:#fff" @click="link(1)"></u-cell>
			<u-cell icon="/static/kefu/viber.png" title="Viber CSKH trực truyến" isLink url="/pages/componentsB/tag/tag"
				iconStyle="width:90rpx;height:90rpx;" titleStyle="margin-left:20rpx;color:#fff"
				@click="handleModal()"></u-cell>

			<!-- <u-cell icon="/static/kefu/email.png" title="alliancebernsteinivs@gmail.com " isLink
				rightIcon="/static/fuzhi.png" rightIconStyle="width:60rpx;height:60rpx" url="/pages/componentsB/tag/tag"
				iconStyle="width:100rpx;height:90rpx" titleStyle="margin-left:20rpx;color:#fff;"
				@click="fuzhi()"></u-cell> -->
		</u-cell-group>

		<view style="padding:24rpx;color: #AAA;">
			Nếu trong quá trình sử dụng quý khách gặp bất kỳ vấn đề nào liên quan đến sản phẩm và dịch vụ của chúng tôi.
			Quý khách có thể liên hệ với chúng tôi qua các cách trên.
		</view>

		<!-- zalo 二维码 -->



		<template v-if="isShow">
			<view class="mask" @click="handleClose()">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;"
					@click="handleClose()">
					<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<!-- <view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;">

					</view> -->
					<view style="display: flex;align-items: center;justify-content: center;margin-top: 3vh;"
						@click="saveImg()">
						<image :src="imgUrl" mode="aspectFit" style="width: 640rpx;height: 640rpx;"></image>
					</view>
				</view>
			</view>
		</template>

		<!-- 		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">客服</view>
			<view class=""></view>
		</view> -->

		<!-- <view class="college-content"> -->
		<!-- <web-view :fullscreen="full" class="webview" :style="webviewStyles" :webview-styles="webviewStyles"
				:src='list'></web-view> -->
		<!-- 	<web-view :style="webviewStyles" :webview-styles="webview" :fullscreen="full" :src='list'></web-view>
		</view> -->
		<!-- <template>
			<web-view :src="list"></web-view>
		</template> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgUrl: '/static/zalo_code.jpg', // 二维码地址
				isShow: false, // 二维码弹层
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
			};
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			handleModal() {
				this.isShow = true;
			},
			// 关闭中签提醒
			handleClose(val) {
				console.log(val);
				this.isShow = val;
			},

			saveImg() {
				var oA = document.createElement("a");
				oA.download = 'img'; // 设置下载的文件名，默认是'下载'
				oA.href = this.imgUrl;
				document.body.appendChild(oA);
				oA.click();
				oA.remove(); // 下载之后把创建的元素删除
			},
			fuzhi() {
				uni.setClipboardData({
					data: "alliancebernsteinivs@gmail.com",
					showToast: false,
					success: function() {
						//调用方法成功
						console.log('success');
						uni.showToast({
							title: "Sao chép thành công"
						})
					}
				})
			},
			link(i) {
				if (i == 1) {
					// location.href="https://www.baidu.com/"
					window.open('https://t.me/Alliancebernstein85', '_blank')
				} else {
					// window.open('https://zalo.me/0922169929', '_blank')
					// this.lookImage(0, ['https://api.downsxzj.xyz/upload/app/zalo.jpg']);

				}
			},
			/**
			 * 参数解析
			 * index: 当前内容下标
			 * data: 图片数组
			 */
			lookImage(index, data) {
				uni.previewImage({
					current: index,
					urls: data
				});
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async get_url() {
				let list = await this.$http.get('api/app/config', {})
				this.list = list.data.data[21].value
			},
		},
		mounted() {
			this.get_url()
		},
	}
</script>

<style lang="scss">
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}

	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	iframe {
		width: 600px !important;
	}

	.college-content {
		width: 100%;
		height: 100%;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>