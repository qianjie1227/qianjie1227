<template>

	<view class="page_body">
		<view class="padding-20 padding-top-20" style="display: flex;align-items: center; background-color: #363636;">
			<image src="/static/chuanggai/applogo.png" mode="scaleToFill"
				style="width: 48rpx;height: 48rpx;border-radius: 100%;border:1px solid #fff;" @click="linAccount()">
			</image>
			<view style="margin-left: auto;">
				<image src="/static/search.png" mode="aspectFit" style="width: 20px;height: 20px;padding-right: 24rpx;"
					@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
				<image src="/static/notify.png" mode="aspectFit" style="width: 20px;height: 20px;"
					@click="$u.route({url:'/pages/notify/index'});"></image>
			</view>
		</view>

		<template v-if="topList && topList.length>0">
			<view class="padding-10" style="margin:24rpx 0;background-image: url(/static/top_bg.png);
		background-repeat: no-repeat;background-position: 0 0;background-size: 100% 100%; ">
				<!-- <image src="/static/banner.jpg" style="width: 100%;border-radius: 10px;" mode="widthFix"></image> -->
				<scroll-view :scroll-x="true" style="white-space: nowrap;padding: 0 10px 0 10px;" @touchmove.stop>
					<block v-for="(item,index) in topList" :key="index">
						<view
							style="width: 240rpx;display: inline-block; padding:10px;margin-right: 20px;border-radius: 12rpx;background-color: #333333;">
							<view style="color:#fff;">{{item.name}}</view>
							<image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								style="width: 210rpx;height: 72rpx;"></image>
							<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.current_price}}
							</view>
							<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.rate_num}} ({{item.rate}}%)
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 16rpx;">
								<view style="border-radius: 12rpx;background-color: #FF606A;width: 30%;height: 6rpx;">
								</view>
								<view
									style="border-radius: 12rpx;background-color: #FDD355;width: 20%;height: 6rpx;margin:0 6rpx;">
								</view>
								<view style="border-radius: 12rpx;background-color: #1AC5A8;width: 50%;height: 6rpx;">
								</view>
							</view>
						</view>
					</block>
				</scroll-view>
			</view>
		</template>

		<!-- 	<view class="navBar flex flex-wrap">
			<view class="nav-item flex flex-column align-center" v-for="item,index in nav"
				@click="tiaozhuan(item.route)">
				<view class="">
					<u-image :showLoading="true" :src="item.icon" width="50px" height="50px" bgColor="#eee">
					</u-image>
				</view>
				<view class="text-center margin-top-10" style="color: #CBCBCF;font-size: 14px;">
					<span>{{item.title}}</span>
				</view>
			</view>
		</view> -->
		<!-- notify -->
		<!-- <view class="notify flex align-center padding-10">
			<u-notice-bar text="Hiển thị thông báo Marquee"  bgColor='#442f84'
				color='#ffb044'></u-notice-bar>
		</view> -->

		<view class="btn_bg" style="position: relative;">

			<view style="padding:4rpx 0 0 24rpx;color: #fff;font-size: 32rpx;font-weight: 500;">
				<view
					style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
					Giao dịch
					<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
						background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
					</view>
					<view
						style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
						Giao dịch</view>
				</view>
			</view>

			<view style="position: absolute;left: 40rpx;top:100rpx;width: 30%;"
				@click="tiaozhuan( '/pages/index/components/fund/fund')">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src='/static/btn_0.png' mode="aspectFit"
						style="width: 80rpx;height: 80rpx;padding-bottom: 24rpx;"></image>
					<view style="color: #fff;">ETF</view>
				</view>
			</view>

			<view style="position: absolute;right: 40rpx;top:100rpx;width: 30%;"
				@click="tiaozhuan('/pages/index/components/newShares/newShares?index=1')">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src='/static/btn_1.png' mode="aspectFit"
						style="width: 80rpx;height: 80rpx;padding-bottom: 24rpx;"></image>
					<view style="color: #fff;">Quyền mua</view>
				</view>
			</view>

			<view style="position: absolute;left: 50%;top:210rpx;width: 30%;transform: translateX(-50%);"
				@click="tiaozhuan(`/pages/position/position`)">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src='/static/btn_4.png' mode="aspectFit"
						style="width: 80rpx;height: 80rpx;padding-bottom: 24rpx;"></image>
					<view style="color: #fff;"> Sổ lệnh </view>
				</view>
			</view>

			<view style="position: absolute;left: 40rpx;bottom:60rpx;width: 30%;"
				@click="tiaozhuan('/pages/index/components/newShares/newShares?index=2')">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src='/static/btn_2.png' mode="aspectFit"
						style="width: 80rpx;height: 80rpx;padding-bottom: 24rpx;"></image>
					<view style="color: #fff;">Cổ phiếu mới</view>
				</view>
			</view>

			<view style="position: absolute;right: 40rpx;bottom:60rpx;width: 30%;"
				@click="tiaozhuan('/pages/index/components/openAccount/openAccount')">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src='/static/btn_3.png' mode="aspectFit"
						style="width: 80rpx;height: 80rpx;padding-bottom: 24rpx;"></image>
					<view style="color: #fff;">Danh tính</view>
				</view>
			</view>
		</view>

		<view class="flex padding-10">
			<view class="chongzhi" @click="home()">
				<image src="/static/center_left.png" mode="widthFix"
					style="width: 12px;margin-right: 10px;height: 12px;"></image>
				Nộp tiền
			</view>

			<view class="tixian" @click="home2()">
				<image src="/static/center_right.png" mode="widthFix"
					style="width: 12px;margin-right: 10px;height: 12px;"></image>
				Rút tiền
			</view>
		</view>

		<view class="hotspot">
			<view style="display: flex;align-items: center;">
				<view>
					<view
						style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;">
						Điểm tin thị trường
						<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
							background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
						</view>
						<view
							style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
							Điểm tin thị trường</view>
					</view>
				</view>
				<view style="margin-left: auto;" @click="linkNews()">
					<image src="/static/arrow_right.png" mode="aspectFit" style="width: 24rpx; height: 24rpx;"></image>
				</view>
			</view>

			<scroll-view :scroll-x="true" style="white-space: nowrap;padding: 0 10px 0 10px;" @touchmove.stop>
				<block v-for="(item,index) in news" :key="index">
					<view
						style="width: 340rpx;height: 220rpx; display: inline-block; padding:10px;margin-right: 20px;border-radius: 12rpx;background-color: #333333;"
						@click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
						<view style="display: flex;align-items: center;justify-content: center;margin-bottom: 12rpx;">
							<image :src="item.pic" style="width: 320rpx;height: 120rpx;"></image>
						</view>
						<view class="content" style="padding-top: 12rpx;">
							<view class="title" style="font-size: 28rpx; color: #fff;">
								{{setText(item.title)}}
							</view>
							<view class="summary" style="font-size: 24rpx; color: #999;padding-top: 12rpx;">
								{{setText(item.content)}}
							</view>
						</view>
					</view>
				</block>
			</scroll-view>
		</view>
		
		<view>
			<view
				style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;margin-left: 24rpx;">
				hợp đồng tương lai
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					hợp đồng tương lai</view>
			</view>
			<block v-for="(item,index) in qihuo" :key="index">
				<view class="padding-20 margin-10 radius10 flex flex-b" style="background-color: #333333;"
					@tap="detailed(item.gid)">
					<view class="flex">
						<view class="color-white bold">{{item.name}}</view>
					</view>
					<view class="flex gap20">
						<view :style="$theme.setStockRiseFall(item.rate>0)">{{toThousandFilter(item.current_price)}}
						</view>
						<view :style="$theme.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
					</view>
				</view>
			</block>
		</view>
		
		
		<view>
			<view
				style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;margin-left: 24rpx;">
				Danh sách cổ phiếu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Danh sách cổ phiếu</view>
			</view>
			<block v-for="(item,index) in stockList" :key="index">
				<view class="padding-20 margin-10 radius10 flex flex-b" style="background-color: #333333;"
					@tap="detailed(item.name)">
					<view class="flex">
						<view class="color-white bold">{{item.name}}</view>
					</view>
					<view class="flex gap20">
						<view :style="$theme.setStockRiseFall(item.rate>0)">{{toThousandFilter(item.current_price)}}
						</view>
						<view :style="$theme.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
					</view>
				</view>
			</block>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				statusBarHeight: 0,
				topList: [],

				banner: [
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/15153347/nghe-moi-gioi-chung-khoan.jpg',
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/12164644/tai-san-rong-la-gi.jpg',
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/11093813/vi-sao-can-quan-ly-danh-muc-dau-tu.jpg',
				],
				bannerLoding: true,

				index: [{
						name: 'BMP',
						value: '36817.65'
					},
					{
						name: 'TIP',
						value: '36817.65'
					},
					{
						name: 'VGC',
						value: '36817.65'
					}
				],
				// 新闻最新列表 适当条数
				headlines: [{
						tag: 'HOT',
						content: 'conversational AI system that listens,conversational AI system that listens,'
					},
					{
						tag: 'NEW',
						content: 'conversational AI'
					},
					{
						tag: 'HOT',
						content: 'conversational AI system that listens,conversational AI system that listens,'
					},
					{
						tag: 'NEW',
						content: 'conversational AI'
					}
				],
				// 
				headlines_banner: [{
						title: 'thông tin độc quyền',
						summary: 'Nắm bắt các điểm nóng của ngành và hành động ngay lập tức'
					},
					{
						title: 'Tập trung vào các điểm nóng của ngành',
						summary: 'Tin tức mới, tất cả đều có trong đó'
					},
				],
				//
				headlines_market: [{
						title: 'Khuyến nghị phổ biến',
						icon: "../../static/index/hong@2x.png",
						background: "#FFF3F5"
					},
					{
						title: 'cổ phiếu chính',
						icon: "../../static/index/huang@2x.png",
						background: "#FFFDF2"
					},
					{
						title: 'Xếp hạng lãi và lỗ',
						icon: "../../static/index/jiantou@2x.png",
						background: "#F8F7FF"
					},
				],
				// 
				hotspot: [],
				// 加载更多
				page: 1,
				loadmore_status: 'loadmore',
				news: [],
				stockList: [],
				qihuo:[]
			}
		},
		computed: {

		},
		onLoad() {
			this.getSystemInfo();
			this.getBanner();
			// bannerLoding is false
			setTimeout(() => {
				this.bannerLoding = false;
			}, 1500)
			this.gain_views()
			this.getTopList();
		},
		onShow() {
			this.getStockList();
		},
		onReachBottom() {
			// TODO 触底虚拟获取数据
			this.loadmore_status = 'loading';

			setTimeout(() => {
				this.loadmore_status = 'nomore';
				// if (this.page >= 5) return this.loadmore_status = 'nomore';
				// this.page++;
				// this.hotspot.push({
				// 	cover: '../../static/index/tock-chart.jpg',
				// 	title: 'Tiêu đề tin tức chỉ hiển thị một dòng',
				// 	summary: 'Tóm tắt nội dung tin tức hiển thị hai dòng văn bản màu xám. Tóm tắt nội dung tin tức hiển thị hai dòng văn bản màu xám.'
				// });
				// if (this.page >= 5)
				// 	this.loadmore_status = 'nomore';
				// else
				// 	this.loadmore_status = 'loading';
			}, 2000)
		},
		methods: {
			// 跳转到新闻页面
			linkNews() {
				uni.navigateTo({
					url: `/pages/newsList`
				})
			},

			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 26 ? val : val.slice(0, 26) + '...'
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			async getStockList() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 10,
				})
				// console.log(`getStockList:`, list);
				if (list.statusCode == 200) {
					if (list.data && list.data.goods) {
						this.stockList = Object.values(list.data.goods);
					}
					this.topList = list.data.zhishu
				}
				// console.log(`getStockList:`, this.stockList);
			},

			async getTopList() {
				let list = await this.$http.get('api/product/list_type', {
					type: 4
				})
				
				console.log(7777,list);
				this.qihuo=list.data.data
				//上证指数
				
			},

			linAccount() {
				uni.switchTab({
					url: `/pages/my/my`
				})
			},

			tiaozhuan(url) {
				if (url == "/pages/marketQuotations/marketQuotations") {
					uni.switchTab({
						url: url
					})
				} else if (url == "/pages/position/position") {
					uni.switchTab({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					});
				}
				console.log(url);


			},
			home() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/silver'
				});
			},
			home2() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove'
				});
			},



			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			to_skip(url, type, title, id) {
				if (type == 1) {
					uni.navigateTo({
						url: url + `?title=${title}&id=${id}`
					});
				} else if (type == 2) {
					uni.switchTab({
						url: url
					});
				}
			},

			getBanner() {
				// 示例请求

			},
			//新闻
			async gain_views() {
				let list = await this.$http.get('api/article/list', {
					type: 11,
				})
				// console.log(this.list1[index].type, '新闻列表')
				this.news = list.data.data
				// uni.hideLoading();
				// uni.stopPullDownRefresh();

			},
			/** 
			 * 获取设备系统信息
			 */
			getSystemInfo() {
				uni.getSystemInfo({
					success: (res) => {
						this.statusBarHeight = res.statusBarHeight || 0;
					},
					fail: (err) => {
						console.error('Failed to obtain system information:', err);
					},
				});
			},
		}
	}
</script>

<style lang="less" scoped>
	page {
		width: 100%;
		font-family: Arial;
	}

	.chongzhi {
		display: flex;
		align-items: center;
		flex: 1 1 auto;
		justify-content: center;
		margin: 3px 6px;
		border-radius: 8px;
		color: #3E6EB2;
		font-size: 15px;
		line-height: 2.4;
		text-align: center;
		border: 2px solid #3E6EB2;
	}

	.tixian {
		display: flex;
		align-items: center;
		justify-content: center;
		flex: 1 1 auto;
		margin: 3px 6px;
		border-radius: 8px;
		color: #FFFFFF;
		font-size: 15px;
		line-height: 2.4;
		text-align: center;
		background-image: linear-gradient(90deg, #3E6EB2, #26397B);
	}


	.head {
		width: 100%;
		overflow: hidden;

		.arc {
			width: 140%;
			height: 260rpx;
			background: #27285E;
			border-radius: 50%;
			border-radius: 0 0 50% 50%;
			margin-left: -20%;

			.fun {
				width: 66%;

				.logo {
					flex: 1;
				}

				.site-title {
					flex: 1;
				}

				.menu {
					flex: 1;
				}
			}
		}
	}

	.banner {
		margin-top: -50rpx;
		height: 200rpx;
		padding: 0 24rpx;
	}

	.navBar {
		width: 100%;
		margin-top: 60rpx;

		.nav-item {
			width: 25%;
			min-height: 180rpx;
			color: #35353A;

			& ._title {
				width: 90%;
				word-wrap: break-word;
				overflow-wrap: break-word;
			}
		}
	}

	.notify {
		// padding: 14rpx;

		// padding: 24rpx;
		// background: #F8F7FF;

		& ._content {
			color: #35353A;
			margin-left: 26rpx;
		}
	}

	.navBar-block {
		padding: 15rpx 24rpx;

		.block-item-1 {
			line-height: 45rpx;
			padding: 24rpx;
			width: 43%;
			background-image: url('@/static/index/block-bg-1-1.png'), url('@/static/index/block-bg-1-2.png');
			background-position: left top, center;
			background-repeat: no-repeat, no-repeat;
			background-size: 50% 100%, 100%;
			position: relative;
			// border: 1px solid red;
		}

		.block-item-2 {
			line-height: 45rpx;
			padding: 24rpx;
			width: 43%;
			background-image: url('@/static/index/block-bg-2-1.png'), url('@/static/index/block-bg-2-2.png');
			background-position: left top, center;
			background-repeat: no-repeat, no-repeat;
			background-size: 50% 100%, 100%;
			position: relative;
			// border: 1px solid red;
		}

		.title {}

		.title-sm {
			font-size: 26rpx;
		}

		.icon {
			position: absolute;
			bottom: 15rpx;
			right: 15rpx;
		}
	}

	.index {
		margin-top: 30rpx;
		padding: 0 24rpx;

		.index-bx {
			background: #F5FFFB;
			border-radius: 40rpx;
			box-shadow: 0px 3px 0px 0px #C3EDDD;
			padding: 24rpx;
			background-image: url('@/static/index/tuoyuan@2x.png');
			background-size: 33% 100%;
			background-position: right;
			background-repeat: no-repeat;

			.index-item {
				flex: 1;

				.name {
					color: #35353A;
					font-size: 24rpx;
				}

				.separation {
					width: 100%;
					height: 1px;
					margin: 20rpx 0;
					background: #E1EAE7;
				}

				.value {
					color: #35353A;
					font-size: 30rpx;
				}
			}
		}

	}

	.headlines {
		padding: 24rpx;

		& ._title {
			padding: 30rpx 0;
		}



		.item {
			margin-bottom: 30rpx;

			.tag {
				width: 70rpx;
				height: 40rpx;
				padding: 2px 20rpx;
			}

			// item tag
			.NEW {
				color: #27285E;
				font-size: 24rpx;
				background: #F8F7FF;
				border-radius: 6rpx;
			}

			.HOT {
				color: #9E2224;
				font-size: 24rpx;
				background: #FFF3F5;
				border-radius: 6rpx;
			}

			.summary {
				width: 690rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				margin-left: 30rpx;
				color: #35353A;
				font-size: 26rpx;
			}
		}

		.headlines-banner {
			.swiper {
				width: 100%;
				height: 170rpx;
				background: #F7F7F7;
				background-image: url('@/static/index/beijing@2x.png');
				background-size: 100%;
				background-position: center;
				background-repeat: no-repeat;
				border-radius: 40rpx;
				overflow: hidden;

				swiper-item {
					.swiper-item {
						width: 100%;
						padding: 30rpx;
						display: flex;
						flex-direction: column;

						.title {
							width: 100%;
							font-size: 24rpx;
							font-weight: bold;
							color: #9E2224;
							margin-bottom: 20rpx;
						}

						.summary {
							font-size: 30rpx;
							color: #35353A;
						}
					}

				}
			}
		}
	}

	.market {
		margin-top: 30rpx;
		width: 100%;

		.market-item {
			width: 25%;
			min-height: 90rpx;
			position: relative;
			padding: 24rpx;
			border-radius: 40rpx;

			.title {
				text-align: center;
				line-height: 40rpx;
				font-size: 24rpx;
				color: #35353A;
				width: 90%;
				white-space: pre-line;
			}

			.icon {
				position: absolute;
				right: 24rpx;
				bottom: 24rpx;
			}
		}
	}

	.hotspot {
		padding: 24rpx;

		& ._title {
			padding: 30rpx 0;
			margin-bottom: 15rpx;
		}

		.item {
			margin-bottom: 60rpx;

			.content {
				width: 442rpx;

				.title {
					font-size: 28rpx;
					color: #35353A;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					margin-bottom: 40rpx;
				}

				.summary {
					font-size: 24rpx;
					line-height: 40rpx;
					color: #858587;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
				}
			}
		}
	}
</style>