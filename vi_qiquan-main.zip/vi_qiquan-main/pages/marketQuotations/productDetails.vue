<template>
	<view style="padding-bottom: 100rpx;min-height: 100vh;">
		<!-- 头部 -->
		<header style="padding:48rpx 24rpx 10rpx 24rpx;display: flex;align-items: center;">
			<view style="margin-right: auto;" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;">
				</image>
			</view>
			<view style="flex:1;">
				<template v-if="detail">
					<view style="padding-left: 60rpx;">
						<view style="color: #fff;font-size: 16px;font-weight: 700;text-transform:uppercase;">
							{{detail.name}}
						</view>
						<view :style="$theme.setStockRiseFall(detail.rate>0)">
							<text>{{detail.price}}</text>
							<text style="padding-left: 48rpx;">{{detail.rateNum}}</text>
							<text style="padding-left: 48rpx;">({{detail.rate}}%)</text>
						</view>
					</view>
				</template>
			</view>
			<template v-if="detail">
				<view style="margin-left: auto;" @click="handleClickDelProduct()">
					<image :src="detail.is_collected !=1?'/static/stock_unfollow.png':'/static/stock_follow.png'"
						mode="widthFix" style="width: 20px;height: 20px;"></image>
				</view>
			</template>
		</header>

		<template v-if="detail">
			<view
				style="display: flex;align-items: flex-start;border-top: 1px solid #333;padding:0 24rpx;line-height: 1.8;margin-top: 24rpx;border-bottom: 1px solid #333;" >
				<view style="flex:0 0 40%;border-right: 1px solid #333;padding: 12rpx 12rpx 0 0;">
					<view style="display: flex;align-items: center;justify-content: space-between;" v-if="detail.project_type_id!=4">
						<view class="hui" style="font-size: 12px;">Trần</view>
						<view style="color: #aa3bde;">{{toThousandFilter(detail.high)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Tham chiếu</view>
						<view style="color: #dfea48;">{{toThousandFilter(detail.price)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;" v-if="detail.project_type_id!=4">
						<view class="hui" style="font-size: 12px;">Sàn</view>
						<view style="color: aqua;">{{toThousandFilter(detail.low)}}</view>
					</view>
				</view>
				<view style="flex:1;padding: 12rpx 0 0 12rpx;">
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Tổng KL</view>
						<view style="color: #FFF;">{{toThousandFilter(detail.volume)}}</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Sức mua</view>
						<template v-if="userInfo">
							<view style="color: #FFF;">{{toThousandFilter(userInfo.money)}}</view>
						</template>
					</view>
				</view>
			</view>

			<!-- 
			<view style="border-top:1px solid #333333;border-bottom: 1px solid #333333;">
				<view
					style="background-color: #333333;padding:24rpx;line-height: 1.6;border-radius: 20rpx;margin:24rpx;"> -->
			<!-- <view class="flex flex-b color-white font-size-14">
						<view class="hui" style="font-size: 12px;">Tham chiếu</view>
						<view>{{toThousandFilter(detail.open)}}</view>
					</view>
					<view class="flex flex-b color-white font-size-14">
						<view class="hui" style="font-size: 12px;">Trần</view>
						<view>{{toThousandFilter(detail.high)}}</view>
					</view> -->
			<!--  -->
			<!-- <view class="flex flex-b color-white font-size-14">
						<view class="hui" style="font-size: 12px;">Sàn</view>
						<view>{{toThousandFilter(detail.low)}}</view>
					</view> -->
			<!-- <view class="flex flex-b color-white font-size-14">
						<view class="hui" style="font-size: 12px;">Tổng KL</view>
						<view>{{toThousandFilter(detail.volume)}}</view>
					</view>
					<view class="flex flex-b color-white font-size-14">
						<view class="hui" style="font-size: 12px;">Tham chiếu </view>
						<view>{{toThousandFilter(detail.close)}}</view>
					</view> -->
			<!-- 	</view>

			</view> -->
			
		</template>
		<view >
			<view style="display: flex;align-items: center;justify-content:space-around;padding:12rpx 48rpx;">
				<block v-for="(v,k) in times" :key="k">
					<view style="border-bottom:3px solid #333333;color:#FFF;"
						:style="{borderColor:k==curTime?'#FFF':'#000' }" @click="changeTab(k)">
						{{v.label}}
					</view>
				</block>
			</view>
		
			<view class="KLineDiagram" id="kline-stock"></view>
			<template v-if="detail">
				<view class="flex color-white font-size-12 gap10" v-if="detail.project_type_id!=4">
					<view class="flex-1">
						<view class="flex flex-b text-center">
							<view class="flex-1">Giá bán</view>
							<view class="flex-1">KL</view>
						</view>
						<view class="flex flex-b text-center" v-for="(item,index) in buyList" :key="index" v-if="index<3">
							<view class="flex-1" style="color: #f33431;font-weight: 700;">
								{{toThousandFilter(item.price)}}
							</view>
							<view class="flex-1">{{toThousandFilter(item.num)}}</view>
						</view>
					</view>
					<view class="flex-1">
						<view class="flex flex-b text-center">
							<view class="flex-1">Giá mua</view>
							<view class="flex-1">KL</view>
						</view>
						<view class="flex flex-b text-center" v-for="(item,index) in buyList" :key="index" v-if="index<3">
							<view class="flex-1" style="color: green;font-weight: 700;">{{toThousandFilter(item.price)}}
							</view>
							<view class="flex-1">{{toThousandFilter(item.num)}}</view>
						</view>
					</view>
				</view>
			</template>
		</view>
		

		<!-- <u-tabs lineColor="#121327" :list="list1" @click="time_click" :activeStyle="{color: '#121327',}"></u-tabs> -->
		<!-- K线 -->
		<view class="padding-10 margin-10 radius10">

		</view>

		<view style="display: flex;align-items: center;margin-top: 80rpx;justify-content: center;">
			<view style="color: white;background-color:#17A85B;padding:16rpx 0;text-align: center;
					width:80%;border-radius: 12rpx;margin-right: 24rpx;" @click="handleTrade()">
				Mua</view>
			<!-- 卖出 -->
			<!-- <view style="color: white;background-color: #EA393F;padding:16rpx 0;text-align: center;
				width: 40%;border-radius: 12rpx;margin-left: 24rpx;" @click="handleTrade(1)">
				Bán</view> -->
		</view>

		<!-- <view v-show="today.current_price>0" @tap="purchase(productDetails)" class="btn_common"
			style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;">
			Mua
		</view> -->

	</view>
</template>

<script>
	import {
		init,
		dispose
	} from 'klinecharts';
	// import KLineDiagram from "../../components/kLine/KLineDiagram/KLineDiagram.vue";
	// import { init } from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {},
		data() {
			return {
				gid: '', // url带入参
				detail: null, // 详情
				buyList: [], // 买入最新交易
				sellList: [], // 卖出最新交易
				curTime: 0, // 当前选中时间线
				indicator: null, // 技术指标
				// socket: null, // websocket
				// isConnected: false, // 是否链接socket
				kLineChart: null,
				userInfo: null,
				usd_vnd:1
			};

		},
		computed: {
			times() {
				return [{
					key: 1,
					label: `1M`
				}, {
					key: 3,
					label: `3M`
				}, {
					key: 10,
					label: `10M`
				}, {
					key: 30,
					label: `30M`
				}]
			}
		},
		onLoad(opt) {
			this.gid = opt.gid || this.gid;
		},
		onShow() {
			// if (this.socket) this.disconnect();
			this.getDetail();
			this.getUserInfo();
		},
		onHide() {
			// if (this.socket) this.disconnect();
			dispose("kline-stock");
			this.clearData();
		},
		deactivated() {
			// if (this.socket) this.disconnect();
			dispose("kline-stock");
			this.clearData();
		},
		methods: {
			clearData() {
				if (this.indicator) {
					this.kLineChart.removeIndicator(this.indicator);
					this.indicator = null;
				}
			},
			async getUserInfo() {
				const result = await this.$http.get('api/user/fastInfo', {});
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					this.actions = result.data.data.ganggan;
				}
			},


			// 切换时间线
			changeTab(val) {
				this.curTime = val;
				this.clearData();
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});
				this.getDetail();
			},

			// 产品详情
			async getDetail() {
				const result = await this.$http.post('api/product/info', {
					gid: this.gid,
					time_index: this.curTime
				})
				console.log(`result:`, result);
				if (result.data.code == 0) {
					const temp = result.data.data;
					console.log(11111,temp[0]);

					
					if(temp[0].project_type_id!=4){
						this.detail = {
							gid: temp[0].gid,
							name: temp[0].name + ` / ` + temp[0].code.split(':')[0],
							price: temp[0].current_price * 1,
							rate: temp[0].rate * 1,
							rateNum: temp[0].rate_num * 1,
							is_collected: temp[0].is_collected,
							project_type_id:temp[0].project_type_id,
							pid:temp[0].pid,
							// 
							close: temp[1].yesterday.close,
							open: temp[1].today.open,
							high: temp[1].today.high,
							low: temp[1].yesterday.low,
							volume: temp[1].today.volume,
						};
						this.usd_vnd=temp[4]
						this.socket(1);
					}else{
						this.detail = {
							gid: temp[0].gid,
							name: temp[0].name + ` / ` + temp[0].code.split(':')[0],
							price: temp[0].current_price * 1,
							rate: temp[0].rate * 1,
							rateNum: temp[0].rate_num * 1,
							is_collected: temp[0].is_collected,
							project_type_id:temp[0].project_type_id,
							pid:temp[0].pid,
						};
						this.usd_vnd=temp[4]
						this.socket(4);
					}
					console.log(`detail:`, this.detail);
					if (temp[3] && temp[3].buy_sell) {
						// 最近买卖
						this.buyList = temp[3].buy_sell[0];
						this.sellList = temp[3].buy_sell[1];
					}

					// kline
					if (!this.kLineChart) {
						this.kLineChart = init('kline-stock');
					}
					this.setStyleOptions()
					this.kLineChart.clearData()
					this.kLineChart.applyNewData(temp[2])
				}

				// // if (!this.socket) this.connect(this.productDetails.name);
			},

			handleTrade() {
				uni.navigateTo({
					url: `/pages/marketQuotations/purchase?gid=${this.gid}`
				});
			},

			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},


			socket(type) {
				var that = this;
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});
				if(type==4){
					var wsurl=this.$http.WsZonghe
				}else{
					var wsurl=this.$http.WsUrl
				}
				uni.connectSocket({
					url: wsurl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes", this.detail)
				uni.onSocketOpen(function(res) {
					console.log('WebSocket连接已打开！');
					console.log(8888,that.detail);

					uni.sendSocketMessage({
						data: that.detail.name.split('/')[0],
					});

				});
				uni.onSocketMessage(function(res) {
					// console.log('收到服务器内容：' + );
					var arr = JSON.parse(res.data);
					if (that.detail.pid == arr['pid']&&type==4) {
						console.log(arr);
						// console.log('收到服务器内容：' + arr);
						// console.log('goods：' + arr[53]);
						that.detail.price = arr['last']*that.usd_vnd
						that.detail.rate = arr['pcp']
						that.detail.rateNum = arr['pc']*that.usd_vnd
						
					}else if(type==1){
						that.detail.price = arr[41]
						that.detail.rate = arr[52]
					}
				});
				uni.onSocketError(function(res) {
					console.log('WebSocket连接打开失败，请检查！');
					uni.showToast({
						icon: 'none',
						title: 'Mạng chậm'
					})
				});
			},
			setStyleOptions() {
				this.kLineChart.setStyles({
					grid: {
						show: true,
						horizontal: {
							show: true,
							size: 1,
							color: '#302F316A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						},
						vertical: {
							show: true,
							size: 1,
							color: '#302F316A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						}
					},
					"candle": {
						"type": "area", // candle_solid
						"tooltip": {
							"showRule": "none",
						},
						bar: {
							upColor: '#17A85B',
							downColor: '#F92855',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#17A85B',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#17A85B',
							downWickColor: '#F92855',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				// this.kLineChart.createIndicator('VOL', false);
				// 显示技术指标
				if (!this.indicator) {
					this.indicator = this.kLineChart.createIndicator('VOL');
				}
			},

			//删除
			async handleClickDelProduct() {
				const result = await this.$http.post('api/user/collect_edit', {
					gid: this.detail.gid,
				});
				if (result.data.code == 0) {
					this.clearData();
					uni.onSocketClose(function(res) {
						console.log('WebSocket 已关闭！');
					});
					this.getDetail();
				}
			},
		},
	}
</script>

<style lang="scss">
	.kLine {
		margin: 20rpx 0 0;
		background: #fff;
	}

	.KLineDiagram {
		background: transparent;
		height: 600rpx;
		color: #fff;
	}
</style>