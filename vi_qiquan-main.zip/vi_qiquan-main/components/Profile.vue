<!-- 用户基本信息 -->
<template>
	<view>
		<view
			:style="$theme.btnCommon(true,{width:'240rpx', height:'240rpx',borderRadius:'100px',padding:'0',margin:'auto',})">
			<image style="border-radius: 100px;" mode="scaleToFill" :src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.setImageSize(240)"></image>
		</view>

		<view style="display: flex;align-items: center;justify-content: center; padding:20rpx;" @click="handleLink()">
			<view style="font-size: 36rpx;text-align: left;color:#FFFFFF;padding-right: 30rpx;">
				{{info.real_name}}
			</view>
			<view class="arrow rotate_45" style="border-color: #CBCBCF;" :style="$util.setImageSize(12)"></view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center; padding:20rpx;">
			<view style="font-size: 32rpx;text-align: left;color:#CBCBCF;padding-right: 30rpx;">
				{{info.p_mobile}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_AVATAR
	} from '@/common/paths.js';
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入信息修改页面
			handleLink() {
				uni.navigateTo({
					url: ACCOUNT_AVATAR,
				})
			},
		}
	}
</script>

<style>

</style>