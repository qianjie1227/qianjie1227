<template>
	<!-- 新股抢筹 -->
	<view>
		<view class="white-background">
			<!-- 		<view class="take-notes">
				<view class="" style="text-align: center;margin: 60rpx 0; font-size: 28rpx;padding-bottom: 60rpx;">
					如需此项服务请联系您的客户经理
				</view>
			</view> -->
			<view class="take-notes">
				<view class="purchase" @tap="ration()">
					<image src="/static/shengou.png" mode=""></image>
					<view class="">配售记录</view>
				</view>
				<!-- 	<view class="purchase" @tap="luckyNumber()">
					<image src="/static/shengou.png" mode=""></image>
					<view class="">
						中签记录
					</view>
				</view> -->
			</view>

			<view class="science" v-for="(item,index) in funding" :key="index">
				<view class="display" style="margin: 20rpx 0;">
					<view class="">
						<view class="corporation">{{item.goods.name}}</view>
						<view class="area" v-if="item.goods.locate=='深'">
							<view class="deep">{{item.goods.locate}}</view>
							<view class="deep-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='北'">
							<view class="north">{{item.goods.locate}}</view>
							<view class="north-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='沪'">
							<view class="shanghai">{{item.goods.locate}}</view>
							<view class="shanghai-number">{{item.goods.code}}</view>
						</view>

					</view>
					<view class="purchase" @tap="purchase(item.id,item.peishou_price)">
						申购
					</view>
				</view>

				<view class="display">
					<view class="display find">
						<view class="">发行价格</view>
						<view class="">{{item.price}}/股</view>
					</view>
					<view class="display ration">
						<view class="">配售价格</view>
						<view class="">{{item.peishou_price}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				funding: ''
			}
		},
		methods: {
			// 配售记录
			ration() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/ration'
				});
			},
			// 中签记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.funding = list.data.data
				// console.log(this.funding, '99999999');
			},
		},
		mounted() {
			this.scramble()
		}
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: space-around;
			align-items: center;
			text-align: center;
			padding: 60rpx 60rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;

			.purchase {
				font-size: 28rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}

		.science {
			margin: 30rpx;
			padding-bottom: 30rpx;
			border-bottom: 0.037037rem solid #e0e0e0;

			.corporation {
				font-size: 30rpx;
				font-weight: 600;
				color: #333;

			}

			.purchase {
						background-image: linear-gradient(to right, #FFB044, #FF2D30);
				color: #fff;
				border-radius: 40rpx;
				padding: 6rpx 40rpx;
				font-size: 26rpx
			}

			.find {
				width: 42%;
				font-size: 28rpx;

				view:nth-child(2) {
					color: #121327;
				}
			}

			.ration {
				width: 42%;
				font-size: 28rpx;

				view:nth-child(2) {
					color: #121327;
				}
			}
		}
	}
</style>
