<template>
	<view class="">
		<view class="Rboy-box">
			<view class="front-certificate">Tải lên mặt trước Căn cước công dân</view>
			<view class="Rboy-obverse">
				<image class="obverseimg" :src="obverseUrl ? obverseUrl : '/static/purchase/zhengmian.png'" @click="obverse_btn" mode=""></image>
				<image class="del_btn" :src="del" mode="" v-if="obverseUrl" @click="del_btn('obverse')"></image>
			</view>
			<view class="Rboy-reverse">
				<view class="reverse-certificate">Tải lên mặt sau Căn cước công dân</view>
				<image class="reverseimg" :src="reverseUrl ? reverseUrl : '/static/purchase/fanmian1.png'" @click="reverse_btn" mode=""></image>
				<image class="del_btn" :src="del" mode="" v-if="reverseUrl" @click="del_btn('reverse')"></image>
			</view>
		</view>
	</view>
</template>

<script>
	import Compressor from 'compressorjs';
	import file from './file.js';
	// import Blob from 'blob';

	// Rest of your code...

	export default {
		name: 'Rboy-upload-sfz',
		props: {
			obverseUrl: {
				type: String,
				default: ''
			},
			reverseUrl: {
				type: String,
				default: ''
			},
			sourceType: {
				type: Array || Object,
				default: () => {
					return ['album', 'camera'];
				}
			}
		},
		data() {
			return {
				obverse: file.obverse,
				reverse: file.reverse,
				del: file.del
			};
		},
		created() {},
		methods: {
			obverse_btn() {
				if (this.obverseUrl) {

					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast('Thêm vào');
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast('Thêm vào');
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB
						console.log(imageFile.size, '压缩之前大小');
						console.log(maxSizeInBytes, '上面这个数大于200kb就会压缩');
						if (imageFile.size > maxSizeInBytes) {
							// 如果图片超过最大大小，则进行压缩
							const options = {
								maxWidth: 800, // 根据需要调整
								maxHeight: 800, // 根据需要调整
								quality: 0.2, // 调整压缩质量（0.8表示80%的质量）
								success: compressedFile => {
									const imageUrl = URL.createObjectURL(compressedFile);
									this.$emit('selectChange', {
										msg: `${name}Image:ok`,
										name,
										tempFilePath: imageUrl, // 使用对象URL作为路径
										tempFile: compressedFile, //1
									});
									// console.log(imageUrl, '压缩后的图片路径');
									console.log(compressedFile.size, '压缩之后的大小');

								},
								error: error => {
									console.error('图片压缩失败:', error);
									this.$emit('selectChange', {
										msg: `${name}Image:fail`,
										name,
										error
									});
									uni.$u.toast('Thêm vào');
								}
							};
							new Compressor(imageFile, options);
						} else {
							// 如果图片已经在大小限制内，则使用原始图片
							this.$emit('selectChange', {
								msg: `${name}Image:ok`,
								name,
								tempFilePath: imageFile.path,
								tempFile: imageFile
							});
							// console.log(imageFile, '原始图片路径');
						}
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],

				});
			},
			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			}
		}
	};
</script>



<style scoped lang="less">
	@imgWidth: 400rpx;
	@imgheight: 240rpx;
	@boxheight: 300rpx;

	.Rboy-box {
		.front-certificate {
			font-size: 30rpx;
			font-weight: 700;
			text-align: center;
			margin: 30rpx 0;
		}

		.reverse-certificate {
			font-size: 30rpx;
			font-weight: 700;
			text-align: center;
			margin: 30rpx 0;
		}

		.Rboy-obverse {
			width: @imgWidth;
			height: @boxheight;
			overflow: hidden;
			display: flex;
			flex-direction: column;
			position: relative;

			.obverseimg {
				width: @imgWidth;
				height: @imgheight;
			}

			.del_btn {
				position: absolute;
				top: 5rpx;
				right: 5rpx;
				width: 50rpx;
				height: 50rpx;
				border-radius: 50%;
				z-index: 20;
			}
		}

		.Rboy-reverse {
			width: @imgWidth;
			height: 330rpx !important;
			overflow: hidden;
			display: flex;
			flex-direction: column;
			position: relative;

			.reverseimg {
				width: @imgWidth;
				height: 300rpx;
			}

			.del_btn {
				position: absolute;
				top: 100rpx;
				right: 5rpx;
				width: 50rpx;
				height: 50rpx;
				border-radius: 50%;
				z-index: 20;
			}
		}
	}
</style>