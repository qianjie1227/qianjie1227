import App from './App'

// #ifndef VUE3
import Vue from 'vue'
// import uView from '@/uni_modules/uview-ui'
import VueI18n from 'vue-i18n'
import messages from './locale/index'

import uView from "@/node_modules/uview-ui";
Vue.use(uView);

import 'utils/icon.css';


let i18nConfig = {
  locale: "en",
  messages
}
Vue.use(VueI18n)

const i18n = new VueI18n(i18nConfig)

Vue.config.productionTip = false

import BaseUrl from '@/utils/api.js'
Vue.prototype.$BaseUrl = BaseUrl.BaseUrl
Vue.prototype.$wsbiUrl = BaseUrl.wsbiUrl
Vue.prototype.$wsstockUrl = BaseUrl.wsstockUrl


App.mpType = 'app'
const app = new Vue({
	i18n, // 将i18n实例注入到Vue实例中
	...App
})
app.$mount()
// #endif

// 引入封装的请求
import request from "./utils/api.js";
Vue.prototype.$http = request;

import md5 from 'js-md5';
Vue.prototype.$md5 = md5;


Vue.prototype.$requests = "https://www.baidu.com/"


// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif