<template>
	<view>
		<view class="line-box">
			<view class="flex flex-b top">
				<view class="t">{{$t('index.gszk')}}</view>
				<!-- <view class="t1">기준 2023.09.26 14:32:50</view> -->
			</view>
			<view class="flex flex-b pdd">
				<div class="nav-boxs flex">
					<div class="nav-items" :class="current1==0?'active':''" @click='qiehuan(0)'>{{$t('index.grd')}}</div>
					<div class="nav-items" :class="current1==1?'active':''" @click='qiehuan(1)'>{{$t('index.mg')}}</div>
					<div class="nav-items" :class="current1==2?'active':''" @click='qiehuan(2)'>{{$t('index.xnhb')}}</div>
				</div>
			</view>
			<view class="nums flex flex-b">
				<view class="nums-item" v-for="(item,index) in top1">
					<view class="name" v-if="index==17470">{{$t('index.hgzhzs')}}</view>
					<view class="name" v-if="index==255">{{$t('index.hgzhzs')}} 200</view>
					<view class="name" v-if="index==141">{{$t('index.ksdk')}} </view>


					<view class="name" v-if="index==157">{{$t('index.dow')}}</view>
					<view class="name" v-if="index==155">{{$t('index.ptprzs')}}</view>
					<view class="name" v-if="index==144">{{$t('index.nsdk')}}</view>

					<view class="name" v-if="index==16709">{{$t('index.btb')}}</view>
					<view class="name" v-if="index==16710">{{$t('index.ytf')}}</view>
					<view class="name" v-if="index==16714">{{$t('index.bw')}}</view>

					<view class="icon zl " :class="item.rate>0?'':'dl'"></view>
					<view class="t num-font" :class="item.rate>0?'':'die'">{{item.close}}</view>
					<view class="t1 " :class="item.rate>0?'':'die'">{{(item.rate)}}%</view>
				</view>
			</view>
			<view class="chart" id="chart-type-k-line" style="width: 100%;height: 300rpx;">
			</view>
		</view>
		<view>
			<view class="list">
				<view class="tt">{{$t('index.zdxw')}}</view>
				<view class="flex flex-b pdd">
					<view class="item" v-for="(item,index) in article" v-if="index<=1" @click="open(item.url)">
						<view>
							<image :src="item.pic"></image>
						</view>
						<view class="t show">{{item.title}}</view>
						<view class="t1">{{item.created_at}}
						</view>
					</view>
				</view>
				<view class="items" v-for="(item,index) in article" v-if="index>1">
					<view class="t" style="font-weight: 500;">{{item.title}}</view>
					<view class="t1">{{item.created_at}}</view>
				</view>

				<view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=3'});">
					{{$t('index.ckgdzdxw')}}
					<view class="icon jtr"></view>
				</view>
			</view>
		</view>
		<view>
			<view class="list">
				<view class="tt">
					<view class="flex flex-b">
						<view class="t">{{$t('index.tssp')}}</view>
						<!-- <view class="t1">기준 2023.09.26</view> -->
					</view>
					<view class="cot">
						<view class="flex tab">
							<view class="tab-item" :class="current2==0?'active':''" @click='qiehuan2(0)'>{{$t('index.ssl')}}</view>
							<view class="tab-item" :class="current2==1?'active':''" @click='qiehuan2(1)'>{{$t('index.xjl')}}</view>
							<view class="tab-item" :class="current2==2?'active':''" @click='qiehuan2(2)'>{{$t('index.bgjg')}}</view>
							<view class="tab-item" :class="current2==3?'active':''" @click='qiehuan2(3)'>{{$t('index.jyl')}}</view>
						</view>
					</view>
				</view>
				<view class="lists">
					<view class="item flex flex-b" v-for="(item,index) in top2"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
						<view class="flex flex-3">
							<view class="t">{{index+1}}</view>
							<view>
								<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
							</view>
							<view style="margin-left: 20px;">
								<view class="name">{{item.ko_name}}</view>
								<span style="font-weight: 700;font-size: 13px;"
									:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
								</span>
								<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
									:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">
									{{(item.returns*1).toFixed(2)}}%</span>
							</view>
						</view>
						<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
							<!-- <u-icon name="photo" ></u-icon> -->
							<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
							<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
						</view>
					</view>
				</view>
				<view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">특징종목 더보기<view class="icon jtr">
					</view>
				</view>
			</view>
		</view>
		<view>
			<view class="list">
				<view class="tt">
					<view class="flex flex-b">
						<view class="t">{{$t('index.asthfdjxse')}}</view>
						<!-- <view class="t1">기준 2023-09-25</view> -->
					</view>
					<view class="flex flex-b">
						<view class="cot flex-2">
							<view class="flex tab">
								<view class="tab-item" :class="current3==0?'active':''" @click='qiehuan3(0)'>{{$t('index.wgr')}}</view>
								<view class="tab-item" :class="current3==1?'active':''" @click='qiehuan3(1)'>{{$t('index.jg')}}</view>
								<view class="tab-item" :class="current3==2?'active':''" @click='qiehuan3(2)'>{{$t('index.gr')}}</view>
							</view>
						</view>
						<view class="flex-1 flex flex-b tb">
							<view class="it" :class="current33==0?'active':''" @click='qiehuan33(0)'>{{$t('index.jgm')}}</view>
							<view class="it" :class="current33==1?'active':''" @click='qiehuan33(1)'>{{$t('index.jxs')}}</view>
						</view>
					</view>
				</view>
				<view class="lists">
					<view class="item flex flex-b" v-for="(item,index) in top3" @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
						<view class="flex flex-3">
							<view class="t">{{index+1}}</view>
							<view>
								<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
							</view>
							<view style="margin-left: 20px;">
								<view class="name">{{item.ko_name}}</view>
								<span style="font-weight: 700;font-size: 13px;"
									:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
								</span>
								<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
									:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">
									{{(item.returns*1).toFixed(2)}}%</span>
							</view>
						</view>
						<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
							<!-- <u-icon name="photo" ></u-icon> -->
							<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
							<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
						</view>
					</view>
				</view>
				<view class="flex flex-c more"	@click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">{{$t('index.ckgdasthfdjxse')}}<view data-v-5b7bb11c="" class="icon jtr"></view>
				</view>
			</view>
		</view>
		<view>
			<view class="top1">
				<view class="t">{{$t('index.hyxz')}}</view>
				<view class="flex flex-b t1">
					<view class="flex-1">{{$t('index.hymc')}}</view>
					<view class=" t-c">{{$t('index.bdt')}}</view>
					<view class="flex-1 t-r">{{$t('index.bdl')}}</view>
				</view>
			</view>
			<view class="list">
				<view class="item flex flex-b" v-for="(item,index) in bottom">
					<view class="flex-1">{{item.name}}</view>
					<view class="ct">
						<view class="bg flex">
							<view class="flex-1 flex flex-e" >
								<view class="b-bg" :style="{width:item.avg_returns*-20+'%'}"
									v-if="item.avg_returns*1<=0"></view>
							</view>
							<view class="flex-1 ">
								<view class="r-bg" :style="'width: '+(20*item.avg_returns)+'%;'"
									v-if="item.avg_returns*1>0"></view>
							</view>
						</view>
					</view>
					<view class="red flex-1  t-r die">{{item.avg_returns}}%</view>
				</view>

			</view>
		</view>
	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	import uCharts from '@/uni_modules/qiun-data-charts/js_sdk/u-charts/u-charts.js';
	var uChartsInstance = {};
	export default {
		name:'TabOne',
		components: {},
		props: {},
		data() {
			
			return {
				tablist: [{
					name: this.$t('index.sczj')
				}, {
					name: this.$t('index.tssp')
				}, {
					name: this.$t('index.sczb')
				}, {
					name: this.$t('index.scwt')
				}],
				current: 0,
				top1: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: []
			}
		},
		
		methods: {
			open(url){
				// window.open(url)
				window.location.href=url
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
					this.top_three()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			qiehuan33(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan3(current) {
				this.current3 = current;
				this.top_three()
			},
			qiehuan2(current) {
				this.current2 = current;
				this.top_two()
			},
			qiehuan(current1) {
				this.current1 = current1;
				this.top_one()
			},
			async top_one() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1

				})

				this.top1 = list.data.data.top1
				this.kline = list.data.data.kline
				this.article = list.data.data.article
				this.bottom = list.data.data.bottom

				this.kLineChart.applyNewData(list.data.data.kline)
				// uni.hideLoading()
				this.$forceUpdate()
			},
			async top_two() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			async top_three() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top3', {
					current: this.current3,
					current33: this.current33
				})
				this.top3 = list.data.data
				// uni.hideLoading()
			},
			
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.top_one()
					this.top_two()
					this.top_three()
					// this.dataUpdate()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);


			},
		},

		mounted() {
			
			
			this.kLineChart = init('chart-type-k-line')

			this.kLineChart.setStyles({
				"candle": {
					"type": "area",
					"tooltip": {
						"showRule": "none",
					}
				},

			});
			this.top_one()
			this.top_two()
			this.top_three()
			this.startTimer()
			
			
		},
		
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}

	.charts {
		width: 100%;
		height: 200px;
	}

	.header {
		padding: 0 15px;
		width: 100vw;
		height: 50px;
		line-height: 50px;
		background: #014b8d;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.title {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
		}
	}



	.flex.flex-b {
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.flex {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
	}

	.line-box {
		padding: 0 5px;

		.top {
			padding: 16px 10px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}
		}
	}

	.pdd {
		padding: 0 5px;
	}

	.nav-boxs {
		height: 32px;
		line-height: 32px;

		.nav-items {
			font-size: 17px;
			font-weight: 700;
			color: #999;
			background: #f1f2f4;
			border-radius: 5px;
			padding: 0 10px;
			margin-right: 10px;
		}

		.active {
			color: #014b8d;
			background: #e0e3eb;
		}

	}

	.line-box .nums {
		background: #f0f3fa;
		border-radius: 10px;
		padding: 5px;
		text-align: center;
		margin: 16px 0;

		.nums-item {
			width: 32%;
			background: #fff;
			border-radius: 8px;
			padding: 16px 0;

			.name {
				color: #014b8d;
			}

			.icon {
				margin: 5px auto;
			}

			.t {
				font-size: 17px;
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}

			.t.die {
				color: #014b8d;
			}

			.t1 {
				font-size: 17px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}

			.t1.die {
				color: #014b8d;
			}

		}
	}

	.line-box .last {
		padding: 10px;

		view {
			font-size: 12px;
			color: #333;
		}

		span {
			font-size: 12px;
			color: red;
			margin-left: 5px;
		}
	}

	.list {
		padding: 16px 0;
		// border-top: 5px solid #f5f5f5;
		border-bottom: 5px solid #f5f5f5;
		margin-top: 10px;

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

		}

		.pdd {
			padding: 0 10px 16px;
			border-bottom: 1px solid #ccc;

			.item {
				width: 49%;

				uni-image {
					width: 100%;
					height: 117px;
					border-radius: 5px;
					margin-bottom: 10px;
				}
			}

		}

		.items {
			padding: 16px 10px;
			border-bottom: 1px solid #ccc;
		}

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}

			.cot .tab {
				padding: 16px 0 0;

				.tab-item {
					background: #f1f2f4;
					border-radius: 5px;
					color: #999;
					height: 32px;
					line-height: 32px;
					text-align: center;
					min-width: 20%;
					margin-right: 10px;
				}

				.tab-item.active {
					background: #e7f1f9;
					color: #014b8d;
				}
			}
		}
	}

	.show {
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		font-weight: 500;
	}

	.more {
		padding: 16px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}

	.flex.flex-c {
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
	}

	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}

	.tb {
		height: 32px;
		background: #f1f2f4;
		border-radius: 5px;
		padding: 0 5px;
		margin-top: 16px;

		.it {
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;
			text-align: center;
			height: 26px;
			border-radius: 3px;
			color: #014b8d;
			line-height: 26px;
		}

		.it.active {
			background: #fff;
		}
	}

	.top1 {
		border-bottom: 1px solid #ccc;
		padding: 16px 10px;

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			margin-top: 16px;
		}
	}

	.list {
		padding: 16px 10px;

		.item {

			margin-bottom: 16px;

			.red {
				font-weight: 600;
				color: #ff3636;
			}

			.red.die {
				color: #014b8d;
			}
		}
	}

	.ct {
		width: 149px;

		.bg {
			background: #e7f1f9;
			border-radius: 5px;
			overflow: hidden;

			.b-bg {
				height: 21px;
				background: #014b8d;
			}

			.r-bg {
				height: 21px;
				background: red;
			}
		}
	}
</style>