import en from './en.json'
import ala from './ala.json'

export default {
	en,
	ala
}
