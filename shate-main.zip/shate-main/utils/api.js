// http.js
// 通常可以吧 baseUrl 单独放在一个 js 文件了
// const BaseUrl = 'http://47.242.30.5/'
import md5 from 'js-md5'

let yuming = "api.jpmdapp.top";
let BaseUrl = 'https://' + yuming
let DappUrl = 'https://auth.jpmdapp.top'

let Login = DappUrl + "/#/pages/index/login"

let wsbiUrl = 'wss://' + yuming + '/ws'
let wsstockUrl = 'wss://' + yuming + '/stock'
let wsMeiguUrl = 'wss://' + yuming + '/meigu'

let usd = 3.75

let Request = "Qwd3N5yp"
const baseUrl = async () => {
	if (!BaseUrl) {
		const res = await uni.request({
			url: BaseUrl,
			method: 'GET',
		})
		BaseUrl = res[1].data
		const str = BaseUrl.substring(0, BaseUrl.length - 1);
		uni.setStorageSync("url", str)
	}
}
const request = async (options = {}) => {
	// 在这里可以对请求头进行一些设置
	let token;
	let is_if = uni.getStorageSync("token") || ''
	if (is_if) {
		token = "Bearer " + uni.getStorageSync("token")
	} else {
		token = ''
	}
	options.header = {
		"Content-Type": "application/x-www-form-urlencoded",
		"Authorization": token,
		"language": 'ja',
	}
	if (!BaseUrl) await baseUrl()

	const setHearderIndex = (data) => {
		options.header = data
	}
	return new Promise((resolve, reject) => {

		let lang = uni.getLocale()
		let time = parseInt(new Date().getTime() / 1000)
		let str_url = ("/" + options.url).toLowerCase()


		let mdd = md5("XPFXMedS" + Request + str_url + time)
		// console.log(mdd+"=="+options.url+"=="+str_url+"=="+time);

		options.data.lang = lang
		uni.request({
			url: BaseUrl + "/" + options.url + "?sign=" + mdd + "&t=" + time,
			method: options.type || 'GET',
			data: options.data || {},
			header: options.header || {},

		}).then(data => {
			let [err, res] = data;
			if (err) {
				reject(err)
			} else {
				console.log(res);

				if (res.data.code === 999) {
					try {
						uni.clearStorageSync();
						uni.$u.toast(res.data.message);
						setTimeout(() => {
							// window.location.href = DappUrl + "/#/pages/index/kaihu"
							uni.navigateTo({
								url:"/pages/logon/logon/logon"
							})
						}, 1000)

					} catch (e) {
						//TODO handle the exception
					}
				}
				resolve(res);
			}

		}).catch(error => {
			// console.log(error)
			reject(error)

		})
	});
}

const get = (url, data, options = {}) => {
	options.type = 'GET';
	options.data = data;
	options.url = url;
	return request(options)
}

const post = (url, data, options = {}) => {
	options.type = 'POST';
	options.data = data;
	options.url = url;
	return request(options)
}

const goBack = () => {
	let canNavBack = getCurrentPages();
	if (canNavBack && canNavBack.length > 1) {
		uni.navigateBack({
			delta: 1
		});
	} else {
		history.back();
	}
}




export default {
	request,
	get,
	post,
	BaseUrl,
	wsbiUrl,
	wsstockUrl,
	DappUrl,
	wsMeiguUrl,
	usd,
	goBack
}