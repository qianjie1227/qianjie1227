<!-- 下单 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
			<view class="college-text">
				{{$t('index.zhuwen')}}
				<view class="" style="font-size: 24rpx;">{{$t('index.xianzhi')}}:{{detailedData.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
			</view>
			<view class=""></view>
		</view>
		<view>
			<view class="flex flex-b padding-10 ziti margin-10" >
				<view>{{$t('index.quyill')}}</view>
				<view style="padding:5px 8px;background-color: #f57d80;color: #fff;font-size: 14px;">{{$t('index.maidj')}}</view>
			</view>
			<view class="flex flex-b padding-10 ziti margin-10" >
				<view class="flex-1">{{$t('index.afes')}}</view>
				<view>
					<u-input :placeholder= "$t('index.qazd')" v-model="price"></u-input>
					<view class="font-size-10 hui1 text-right">{{$t('index.wfadf')}}</view>
				</view>
				
			</view>
			<view class="flex flex-b padding-10 ziti margin-10" >
				<view class="flex-1">{{$t('index.dsfv')}}</view>
				<u-input :placeholder="$t('index.crre')" v-model="num"></u-input>
			</view>
			<view class="padding-left-10 hui1">
				{{$t('index.gdfgd')}}
			</view>
		</view>
		
		


		<view v-if="list.is_check!=1" @tap="authentication()" class="purchase">
			{{$t('index.qjcndzsxm')}}
		</view>
		<view v-if="list.is_check==1" class="purchase" @click="show=true">
			{{$t('index.ck')}}
		</view>
			
		<u-modal :show="show"  :content="getcontent()" @confirm="placeOrder" :showCancelButton="true" @cancel="show=false" :cancelText="$t('index.xc')" :confirmText="$t('index.ck')"></u-modal>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '',
				detailedData: "",
				code:'',
				time_index:0,
				new_price:0,
				price:"",
				num:""
		
			};
		},
		methods: {
			getcontent(){
				
				return this.$t('index.ck')+this.detailedData.name+this.$t('index.qwee')+this.price+this.$t('index.dsas')+this.num+this.$t('index.wszx');
				
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/marketQuotations/authentication'
				});
			},
			//购买
			async placeOrder(detailedData) {
				if(!this.price){
					return uni.$u.toast(this.$t('index.qazd'));
				}
				if(!this.num){
					return uni.$u.toast(this.$t('index.crre'));
				}
				this.show=false
				let list = await this.$http.post('api/product/guadan', {
					num: this.num,
					gid: this.detailedData.gid,
					price: this.price,
					// double: this.title
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: this.$t('index.wzzgmqsd'),
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/position/position',
						});
						uni.hideLoading();
					}, 3000)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
			},
			// 产品세부
			async product() {
				let list = await this.$http.get('api/product/info', {
					code: this.code,
					time_index: this.time_index
				})
				this.detailedData = list.data.data[0]
				console.log(this.detailedData)
				// let new_price=this.detailedData.data.TDD_CLSPRC.replace(',', "");
				// let rate_num=this.detailedData.rate_num
				
				// console.log(new_price)
				// this.zuoshou=(new_price*1-rate_num*1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0)
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.code=option.code
		},
		onShow() {
			this.product()
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 0 16px;
		height: 53px;
		// background-image: linear-gradient(to right, #1a73e8, #eb333b);
		background-color: #eb333b;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.ziti{
		border-bottom: 1px #b6b6b6 solid;
		view{
			font-size: 15px;
		}
	}

	//买入
	.purchase {
		background-image: linear-gradient(to right, #eb333b, #eb333b);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 28rpx;
	}
</style>
