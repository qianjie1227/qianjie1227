<template>
	<view class="wrapper">
		<view class="status_bar"></view>
		<view class="mx-30 py-30 d-flex-between-center">
			<u-subsection1 :list="navs" :current="currentNav" style="flex:1"  @change="navrateFunc"></u-subsection1>
			<!-- <u-icon name="search" size="40" color="#000" class="ml-30" @click="$utils.jump('/pages/market/search')"></u-icon> -->
		</view>
		<view class="m-30 market text-white">
			<view class="mt-22" v-show="currentNav == 0">
				<view class="stockList">
					<view class="box">
						<view class="top flex flex-b">
							<view class="flex-1">{{$t('index.Stock/Code')}}</view>
							<view class="flex-1 t-r">{{$t('index.recent')}}</view>
							<view class="flex-1 t-r">{{$t('index.fluctuation_rate')}}</view>
						</view>
						<view class="box-item flex flex-b" v-for="(item,index) in shate"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
							<view class="list-name flex-1">
								<view class="list-name-txt ">{{item.name}}<view class="txt">{{item.code}}</view>
								</view>
							</view>
							<view class="flex-1 t-r num-font " :class="item.rate>0?'green':'red'">{{item.close}}</view>
							<view class="per flex-1 t-r " :class="item.rate>0?'green':'red'">{{item.rate}}%</view>
						</view>
					</view>
				</view>
			</view>
			<view class="mt-22" v-show="currentNav == 2">
				<view class="stockList">
					<view class="box">
						<view class="top flex flex-b">
							<view class="flex-1">{{$t('index.Stock/Code')}}</view>
							<view class="flex-1 t-r">{{$t('index.recent')}}</view>
							<view class="flex-1 t-r">{{$t('index.fluctuation_rate')}}</view>
						</view>
						<view class="box-item flex flex-b" v-for="(item,index) in meigu"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
							<view class="list-name flex-1">
								<view class="list-name-txt ">{{item.name}}<view class="txt">{{item.code}}</view>
								</view>
							</view>
							<view class="flex-1 t-r num-font " :class="item.rate>0?'green':'red'">{{item.close}}</view>
							<view class="per flex-1 t-r " :class="item.rate>0?'green':'red'">{{item.rate}}%</view>
						</view>
					</view>
				</view>
			</view>
			<view class="mt-22" v-show="currentNav == 1">
				<view class="title d-grid" style="grid-template-columns:1.1fr 1fr 1fr;">
					<view class="d-flex align-items-center text-warning font-weight-bold"
						v-for="(item,index) in quotationNav" @click="sort(index)" :class="item.align">
						<text>{{item.name}}</text>
					</view>
				</view>
				<navigator class="market-item" v-for="item in quotation" open-type="reLaunch"
					:url="`/pages/marketQuotations/biinfo?code=${item.code}`">
					<view class="left">
						<text class="d-block">
							<text class="font-size-32 font-weight-bold">{{item.name}}</text>
							<text class="font-size-22 opacity-50">/{{item.legal_name}}</text>
						</text>
						<text class="d-block font-size-22 opacity-50">24H: {{Number(item.vol).toFixed(0)}}</text>
					</view>
					<view class="text-center">
						<text class="d-block font-size-32 font-weight-bold"
							:style="{color:getColor(item.rate)}">{{Number(item.price)}}</text>
						<!-- <text class="d-block font-size-22" v-if="$store.state.fiat.currency_legal_name != 'USD'">
							{{(item.price * $store.state.fiat.rate)  | setPrecision(item.precision_length) }} {{$store.state.fiat.currency_legal_name}}
						</text> -->
					</view>
					<view class="">
						<view class="right" :style="{backgroundColor:getColor(item.rate)}">
							{{item.rate + '%'}}
						</view>
					</view>
				</navigator>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				currentNav: 1,

				quotation: [],

				quotationNav: [{
						name: this.$t('index.Trading_Pair'),
						align: ''
					},
					{
						name: this.$t('index.Latest_Price'),
						align: 'justify-content-center'
					},
					{
						name: this.$t('index.Today_rate'),
						align: 'justify-content-end'
					}
				],

				quotationOriginal: [],
				socket: null,
				optionalList: [], //添加自选
				shate:'',
				meigu:""
			};
		},
		onLoad(op) {
			console.log(op);

			if(op.index){
				// console.log(op);
				this.currentNav=op.index
			}
			const _this = this
			uni.setNavigationBarTitle({
				title: _this.$t("home.market")
			})

		},
		onShow() {
			uni.showTabBar()
			this.shuaxin()
			// this.getQuotation()
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh()
			this.shuaxin()
		},
		methods: {
			shuaxin(){
				uni.closeSocket({
					success: () => {
						console.info(this.$t('index.tuichud'))
					},
				})
				if(this.currentNav==0){
					this.shate_list()
					this.shate_sockets()
				}else if(this.currentNav==1){
					this.getQuotation()
					this.sockets()
				}else{
					this.meigu_list()
					this.meigu_sockets()
				}
			},
			shate_sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: this.$wsstockUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
					
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {

					var data=JSON.parse(res.data);
					this.shate.forEach(item => {
					    if (item.stock_id === data.pid) {
					        item.close = data.last;
							let rate=data.pcp.replace("+",'')
							rate=rate.replace("%",'')
							item.rate = rate;
							item.rate_num = data.pc;
					    }
					});
					// console.log(data.pid);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			meigu_sockets(txt){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: this.$http.wsMeiguUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
					uni.sendSocketMessage({
					  data: txt
					});
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {

					var data=JSON.parse(res.data);
					this.meigu.forEach(item => {
						// console.log(item.stock_id,data.pid);
					    if (item.stock_id == data.pid) {
							// console.log(data);

					        item.close = data.last;
							let rate=data.pcp.replace("+",'')
							rate=rate.replace("%",'')
							item.rate = rate;
							item.rate_num = data.pc;
					    }
					});
				});
			},
			async meigu_list() {
				
				let list = await this.$http.post('api/goods/meigu', {
					current: this.current2,
					limit:50
				})
				this.meigu = list.data.data.meigu
				uni.hideLoading()
				this.meigu_sockets(list.data.data.str)
			},
			async shate_list() {
				
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2,
					limit:50
				})
				this.shate = list.data.data
				uni.hideLoading()
			},
			
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$http.wsbiUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);

					// console.log(data);
					that.quotation[data.market].price = data.lastPrice
					that.quotation[data.market].rate = data.rate
				});
			},

			getColor(num) {
				if (num > 0) {
					return "#1f928c"
				} else {
					return "#cf285d"
				}
			},
			navrateFunc(val) {
				this.currentNav = val
				this.shuaxin()
			},
			// 获取行情
			async getQuotation() {
				let list = await this.$http.post('api/bi/list', {

				})
				this.quotation = list.data.data
			},

		},
		computed: {
			i18n() {
				return this.$t("transaction")
			},
			navs: [],
			navs() {
				const i18n = this.$t("transaction")
				return [{
						name: "Saudi"
					},
					{
						name: "Coin"
					}, {
						name: "US"
					}
				]
			},
			quotationNav() {
				const i18n = this.$t("transaction")
				return [{
						name: i18n.tradingPair,
						align: ''
					},
					{
						name: i18n.lastPrice,
						align: 'justify-content-center'
					},
					{
						name: i18n.todayrate,
						align: 'justify-content-end'
					}
				]
			},
		},
		onHide() {
			uni.closeSocket({
				success: () => {
					console.info(this.$t('index.tuichud'))
				},
			})

		},
		onUnload() {
			uni.closeSocket({
				success: () => {
					console.info(this.$t('index.tuichud'))
				},
			})

		}

	}
</script>

<style lang="scss">
	page {
		color: #000
	}

	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.wrapper {
		position: relative;
		z-index: 10;

		&::after {
			content: "";
			position: absolute;
			left: 0;
			right: 0;
			top: 0;
			bottom: 0;
			// background-image: url('@/static/chuanggai/market-bg.png');
			background-size: contain;
			background-position: center 30vh;
			background-repeat: no-repeat;
			background-attachment: fixed;
			z-index: -1;
		}
	}

	.m-30 {
		margin: 15px !important;
	}

	.text-white {
		color: #000 !important;
	}

	.mt-22 {
		margin-top: 11px !important;
	}

	.font-weight-bold {
		font-weight: bold;
	}

	.text-warning {
		color: #000;
	}

	.d-flex {
		display: flex;
	}

	.justify-content-end {
		justify-content: flex-end;
	}

	.justify-content-center {
		justify-content: center;
	}

	.align-items-center {
		align-items: center;
	}

	.d-block {
		display: block;
	}

	.font-size-32,
	.input,
	.login-input-group .login-input,
	.article uni-text {
		font-size: 16px !important;
	}

	.font-size-22,
	.input-item .get-code {
		font-size: 11px !important;
	}

	.d-grid {
		display: grid;
	}

	.opacity-50 {
		opacity: 0.50;
	}

	.u-line-12 {
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	.status_bar {
		height: 0px;
		width: 100%;
	}

	.d-flex-between-center {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.py-30 {
		padding-top: 15px !important;
		padding-bottom: 15px !important;
	}

	.mx-30 {
		margin-left: 15px !important;
		margin-right: 15px !important;
	}

	.text-center {
		text-align: center;
	}

	.market {
		.market-item {
			overflow: hidden;
			padding: 32rpx 0;
			border-bottom: 1px solid rgba(255, 255, 255, .1);
			align-items: center;
			display: grid;
			grid-template-columns: 1.1fr 1fr 1fr;

			.right {
				margin-left: auto;
				width: 150rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;
				border-radius: 10rpx;
				background-color: #15be97;
				color: #fff;
				font-size: 30rpx;
			}
		}
	}
	.stockList{
	    background: #fff;
	    border-radius: 18px 18px 0px 0px;
	    margin-top: 15px;
	}
	.box {
		.top {
		    padding: 10px 15px;
			uni-view {
			    color: #91a2b1;
			}
		}
		.box-item {
		    padding: 10px 0;
		    margin: 0 15px;
		    border-bottom: 1px solid #f1f1f1;
		    font-size: 19px;
			.list-name-txt {
			    font-size: 17px;
			    color: #333;
				.txt{
				    font-size: 12px;
				    color: #5f6671;
				}
			}
			.red {
			    font-family: Roboto;
			    font-weight: 700;
			    color: #eb333b;
			}
			.per {
			    font-weight: 700;
			    padding: 5px 0;
			}
			
		}
	}
</style>