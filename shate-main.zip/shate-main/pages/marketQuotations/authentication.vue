<template>
	<view class="page">
		<view class="header flex flex-b">
			<view class="icon jiantou" @click="$u.route({type:'switchTab',url:'/pages/index/index'});"></view>
			<view class="header-center flex-1">{{$t('index.search')}}</view>
			<view class="header-right"></view><!---->
		</view>
		<view class="info-box">
			<view class="icon sm-bg"></view>
			<view class="input-list">
				<u--input :placeholder="$t('index.Enter_your_name')" border="surround" v-model="value1"></u--input>
			</view>
			<view class="input-list">
				<u--input :placeholder="$t('index.Enter_your_ID_number')" border="surround" v-model="value2"></u--input>
			</view>
			<view v-if="userinfo.is_check!=1">
				<image :src="formData.obverseUrl" style="width: 90%;margin-left: 5%;height: 180px;margin-top: 20px;" v-if="formData.obverseUrl" @click="obverse_btn"></image>
				<image :src="formData.reverseUrl" style="width: 90%;margin-left: 5%;height: 180px;margin-top: 20px;" v-if="formData.reverseUrl" @click="reverse_btn"></image>
				
				<view class="idCardUpdate-box" @click="obverse_btn" v-if="!formData.obverseUrl">
					<img src="/static/purchase/upload.png"  class="img">
					<span>{{$t('index.front_of_ID_card')}}</span>
				</view>
				<view class="idCardUpdate-box" @click="reverse_btn" v-if="!formData.reverseUrl">
					<img src="/static/purchase/upload.png" class="img">
					<span>{{$t('index.back_of_ID_card')}}</span>
				</view>
				<view class="btn" @click="gain_aouonym()">
					<view class="b-btn">{{$t('index.Verify_now')}}</view>
				</view>
			</view>
			
		</view><!---->
	</view>
</template>


<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'

	export default {
		components: {
		},
		data() {
			return {
				obverseUrl:'',
				reverseUrl:'',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {
			//倒计时
			// uni.showLoading({
			// 	title: '正在检测真人身份证中....',
			// });
			// this.timer = setInterval(() => {
			// 	// 判断如秒数大于0继续执行，反之则清除定时器
			// 	if (this.second > 0) {
			// 		uni.showToast({
			// 			title: `${this.second}秒后`,
			// 			icon: 'loading',
			// 			duration: this.second * 1000,
			// 			//显示透明蒙层，防止触摸穿透
			// 			mask: true
			// 		})
			// 		this.second--
			// 	} else {
			// 		clearInterval(this.timer)
			// 	}
			// }, 1000)
		},
		methods: {
			obverse_btn() {
				if (this.obverseUrl) {
			
					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast(this.$t('index.Click_on_front_to_add'));
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast(this.$t('index.I_added_it_by_clicking_on_the_back'));
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB
						
						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},
			
			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],
			
				});
			},
			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			},
			home() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: this.$t('index.Submitting_Please_wait_a_moment'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				if (list.data.code == 0) {
	

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
					// if (this.real_name == '') {
					// 	uni.$u.toast('姓名不能为空');
					// 	console.log(this.real_name);
					// } else if (this.idno == '') {
					// 	uni.$u.toast('身份证号不能为空');
					// } else if (this.front_image == '') {
					// 	uni.$u.toast('身份证正面不能为空');
					// } else if (this.back_image == '') {
					// 	uni.$u.toast('两次密身份证反面不能为空码不一致');
					// }
				}
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.value1 = list.data.data.real_name
				this.value2 = list.data.data.idno
				this.userinfo = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},

			async upimg(type,tempFilePath){
				uni.showLoading({
					title:"ただ今アップロード中、暫くお待ちください"
				})
				let Request ="Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url=("/api/app/upload").toLowerCase()
				
					
				let mdd=md5("XPFXMedS"+Request+str_url+time)
				
				uni.uploadFile({
					url: this.$http.BaseUrl+'/api/app/upload?t='+time+"&sign="+mdd, 
					filePath: tempFilePath,
					name: 'file',
					success: (res) => {
						uni.hideLoading()
						var data= JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111,data)
						if(type==1){
							this.formData.obverseUrl = data[0].url;
						}else{
							this.formData.reverseUrl = data[0].url;
							
						}
						
					},
					error :(res) => {
						uni.hideLoading()
						console.log(3333,res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222,e)
				var that=this;
				if (e.name == "obverse") {
					this.upimg(1,e.tempFilePath)
			
				} else if (e.name == "reverse") {
					this.upimg(2,e.tempFilePath)
			
				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
		mounted() {
			this.userInfo()
		}
	};
</script>

<style lang="scss">
	.page {
		padding: 50px 0 0;
	}

	.page {
		background: #fff;
		min-height: 100vh;
	}

	view,
	uni-text {
		box-sizing: border-box;
	}

	.header {
		height: 50px;
		background: #1c4199;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 9px;
			height: 16px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}
	}

	.info-box {
		background: #fff;
		min-height: 100vh;
	}

	.input-list {
		margin-top: 21px;
		padding: 0 16px;
	}
	.idCardUpdate-box {
	    height: 200px;
	    background: url(/static/purchase/card.png);
	    background-repeat: no-repeat;
	    background-size: 100% 100%;
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    align-items: center;
	    -webkit-box-pack: center;
	    -webkit-justify-content: center;
	    justify-content: center;
	    -webkit-box-orient: vertical;
	    -webkit-box-direction: normal;
	    -webkit-flex-direction: column;
	    flex-direction: column;
		.img {
		    width: 59px;
		    height: 59px;
		}
	}
	.btn{
	    padding: 0 16px;
		margin-bottom: 20px;
	}
	.b-btn {
	    width: 100%;
	    height: 46px;
	    line-height: 46px;
	    background: #014b8d;
	    border-radius: 10px;
	    text-align: center;
	    font-size: 17px;
	    font-weight: 500;
	    color: #fff;
		margin-bottom: 20px;
	    margin: 16px 0;
		
	}
</style>