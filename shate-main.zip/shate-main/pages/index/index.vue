<template>
	<view><!---->
		<view style="background: linear-gradient(to bottom, #1c4199, #F8F8F8);height: 150px;padding: 30px 20px;">
			<view  class="flex align-center flex-b">
				<view class="flex">
					<image src="/static/logo.png" mode="widthFix" style="width: 30px;margin-top: -5px;"></image>
					<view class="color-white bold margin-left-10 font-size-20">JPM</view>
				</view>
				<view class="flex gap20">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 25px;" @tap="aboutUs()"></image>
					<image src="/static/lang.png" mode="widthFix" style="width: 25px;;" @click="lang_show=true"></image>
				</view>
			</view>
			
			<view style="margin-top: 30px;">
				<view class="banner">
					<view  style="padding:50px 20px;">
						<view style="color:#1c4199;" class="bold font-size-16">Professional and efficient</view>
						<view style="color:#1c4199;margin-top: 10px;" class="font-size-13">cross-asset derivatives trading platform</view>
					</view>
				</view>
			</view>
		</view>
	
		<view class="list flex flex-b" style="margin-top: 50px;">
			<!-- <view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations')">
				<view class="icon hla"></view>
				<view class="t">{{$t('index.AI Smart Trading')}}</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/index/components/fund/fund')">
				<view class="icon gd"></view>
				<view class="t">{{$t('index.Asmart deal')}}</view>
			</view> -->
			<view class="list-item" @click="$u.route({url:'/pages/index/components/newShares/newShares'});">
				<view class="icon sg"></view>
				<view class="t">{{$t('index.Buy_new_stocks')}}</view>
			</view>
			<view class="list-item" @click="$u.route({url:'/pages/bi/newbi'});">
				<view class="icon hl"></view>
				<view class="t">{{$t('index.bulk_transaction')}}</view>
			</view>
			<view class="list-item" @click="$u.route({url:'/pages/index/bigzong'});">
				<view class="icon hlg"></view>
				<view class="t">{{$t('index.xbsg')}}</view>
			</view>
			<view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations?index=0')">
				<view class="icon zx"></view>
				<view class="t">{{$t('index.stocks_of_interest')}}</view>
			</view>
			<!-- <view class="list-item" @click="link(2,'/pages/index/components/fund/fund')">
				<view class="icon gd"></view>
				<view class="t">스마트 거래</view>
			</view> -->
			<!-- <view class="list-item" @click="$u.route({url:'/pages/index/components/newShares/newShares'});">
				<view class="icon sg"></view>
				<view class="t">신규 주식 구매</view>
			</view> -->
			<!-- <view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations')">
				<view class="icon hla"></view>
				<view class="t">AI 스마트 거래</view>
			</view> -->
			<!-- <view class="list-item" @click="link(2,'/pages/marketQuotations/authentication')">
				<view class="icon sm"></view>
				<view class="t">본인 인증</view>
			</view> -->
			<view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations?index=2')">
				<view class="icon cza"></view>
				<view class="t">{{$t('index.us')}}</view>
			</view>
			<!-- <view class="list-item" @click="$u.route({url:'/pages/index/rinei'});">
				<view class="icon hlg"></view>
				<view class="t">일중 거래</view>
			</view> -->
			<view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations?index=1')">
				<view class="icon txa"></view>
				<view class="t">Coin</view>
			</view>
			<view class="list-item" @click="link(5,$http.DappUrl+'/#/pages/index/kaihu')">
				<view class="icon sm"></view>
				<view class="t">{{$t('index.Identity_verification')}}</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/marketQuotations/productDetails?code=XAU')">
				<!-- <view class="icon jl"></view> -->
				<image class="icon flex" src="/static/gold.png" style="width: 30px;height: 30px;justify-content: center;"></image>
				<view class="t">XAU</view>
			</view>
		</view>
		<view style="margin-top: 10px;" class="padding-10">
			<view class="bold font-size-16 flex flex-b" style="margin: 0px 15px;">
				<view>Quotes</view>
				<view @click="link(1,'/pages/marketQuotations/marketQuotations')">More</view>
			</view>
			<view>
				<scroll-view class="uni-swiper-tab" scroll-x >
					<view class="radius20 padding-10 bg-white margin-top-10" v-for="(item,index) in quotation" v-if="index=='btcusdt'||index=='ethusdt'||index=='dotusdt'||index=='xrpusdt'" @click="$u.route('/pages/marketQuotations/biinfo',{code:item.code});">
						<view class="flex flex-b">
							<view>
								<view class="flex gap10">
									<image :src="'https://admin.jpmdapp.com/uploads/'+item.logo" style="border-radius: 50%;width: 30px;height: 30px;" ></image>
									<view>{{item.name}}/USD</view>
								</view>
								<view class="font-size-12 margin-top-10">
									24H:{{item.vol}}
								</view>
							</view>
							
							<view>
								<view class="flex gap5 justify-center">
									<image :src="item.rate>0?'/static/icon/up.png':'/static/icon/down.png'" style="width: 15px;;" mode="widthFix"></image>
									<view :style="item.rate>0?'color:#14CF76':'color:#FF533B'" class="bold">{{item.rate}}%</view>
								</view>
								<view class="font-size-18 margin-top-10">
									{{item.price}}
								</view>
								
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
		
	
		<view class="stockList">
			<u-tabs :list="top_list" @click="click"></u-tabs>
		
			
			<view class="box">
				<view class="top flex flex-b">
					<view class="flex-1">{{$t('index.Stock/Code')}}</view>
					<view class="flex-1 t-r">{{$t('index.recent')}}</view>
					<view class="flex-1 t-r">{{$t('index.fluctuation_rate')}}</view>
				</view>
				<view class="box-item flex flex-b" v-for="(item,index) in top2"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
					<view class="list-name flex-1">
						<view class="list-name-txt ">{{item.name}}<view class="txt">{{item.code}}</view>
						</view>
					</view>
					<view class="flex-1 t-r num-font " :class="item.rate>0?'green':'red'">{{item.close}}</view>
					<view class="per flex-1 t-r " :class="item.rate>0?'green':'red'">{{item.rate}}%</view>
				</view>
			</view>
		</view>
		
		<u-picker :show="lang_show" :columns="columns" :cancelText="$t('index.qx')" :confirmText="$t('index.qr')"  @confirm="confirm" @cancel="lang_show=false"></u-picker>
	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {

		data() {
			return {
				lang_show:false,
				userinfo: [],
				show_money: true,
				page: 1,
				list: [],
				columns: [
					['English', 'عربي']
				],
				top_list:[{
                    name: 'Stock',
                }, {
                    // name: this.$t('index.Featured_items'),
                }],
				current2:0,
				top2:'',
				quotation:''
			}
		},

		methods: {
			shate_sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: this.$wsstockUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件1", res)
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data=JSON.parse(res.data);
					this.top2.forEach(item => {
					    if (item.stock_id === data.pid) {
					        item.close = data.last;
							let rate=data.pcp.replace("+",'')
							rate=rate.replace("%",'')
							item.rate = rate;
							item.rate_num = data.pc;
					    }
					});
					// console.log(data.pid);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			
			delbai(change) {
			  return change.replace('%', '') * 1;
			},
			skip(url){
				uni.navigateTo({
					url:url
				})
			},
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/searchFor/searchFor'
				});
			},
			confirm(e) {
				console.log('confirm', e)
				if(e.indexs==0){
					uni.setLocale("en");
					this.$i18n.locale = 'en';
				}else{
					uni.setLocale("ala");
					this.$i18n.locale = 'ala';
				}
				this.lang_show = false
			},
			click(item) {
			    console.log('item', item);
				this.current2=item.index
				this.good_list()
			},
			getshi(item){
				let close=item.close.replace(",","");
				let zf=item.rate*0.01*close;
				let fh=''
				if(zf>0){
					fh="+";
				}
				
				return fh+zf.toFixed(0);
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				}else if (type == 5) {
					window.location.href=url
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			async top_one() {
				let list = await this.$http.post('api/bi/list', {
							
				})
				this.quotation=list.data.data
				
			},
			// 银转证
			silver(money, bank_card_info, idno) {
					window.location.href=this.$http.DappUrl+"/#/pages/index/index?uid="+this.userinfo.uid
				

			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					// this.good_list()
					// this.top_one()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},

			async good_list() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2,
					limit:50
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: this.$t('index.Please_log_in_first'),
						duration: 1000,
					})
					setTimeout(() => {
						// window.location.href=this.$http.DappUrl+"/#/pages/index/kaihu"
						uni.navigateTo({
							url:"/pages/logon/logon/logon"
						})
					}, 1000)
				} else {

				}
			},
			sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: this.$http.wsbiUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件2", res)
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data=JSON.parse(res.data);
					if(that.quotation[data.market]){
						that.quotation[data.market].price=data.lastPrice
						that.quotation[data.market].rate=data.rate
					}
					// console.log(data);
					
				});
			},
			//登录
			async gain_login(username,password) {
				let list = await this.$http.post('api/app/login', {
					username: username,
					password: password,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					
				} else {
					// window.location.href=this.$http.DappUrl+"/#/pages/index/kaihu"
					uni.navigateTo({
						url:"/pages/logon/logon/logon"
					})
				}
			},

		},
		
		onUnload() {
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
				},
			})
		},
		onHide() {
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
				},
			})
		},
		onLoad(op) {
			console.log(op);

			if(op.address&&op.pwd){
				this.gain_login(op.address,op.pwd)
			}
		},
		async onShow() {
			this.page = 1;
			// this.is_token()
			// this.gaint_info()
			this.good_list()
			// this.startTimer()
			this.top_one()
			this.shate_sockets()
			this.sockets()
			console.log(this.$t('index.xinwen'));

		},
		

	}
</script>

<style lang="scss">
	page{
		background-color: #F8F8F8;
	}
	.banner{
		background-image: url('/static/home/banner.png');
		// background-size: cover;
		background-size: 100% 100%;
		height: 150px;
		width: 100%;
	}
	.topSearch {
	    height: 50px;
	    width: 100%;
	    background: -webkit-linear-gradient(302deg,#ffeed4,#ffe0bb);
	    background: linear-gradient(148deg,#ffeed4,#ffe0bb);
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 500;
		.search{
		    height: 31px;
		    border-radius: 15px;
		    background: hsla(0,0%,100%,.5);
		    display: -webkit-box;
		    display: -webkit-flex;
		    display: flex;
		    -webkit-box-align: center;
		    -webkit-align-items: center;
		    align-items: center;
		    padding: 0 10px;
		    margin: 0 15px;
		    font-size: 12px;
		    font-family: PingFangSC-Regular,PingFang SC;
		    font-weight: 400;
		    color: #999;
			img {
			    width: 14px;
			    height: 14px;
			    margin-right: 10px;
			}
		}
		uni-image {
		    width: 17px;
		    margin-right: 15px;
		}
	}
	.list {
		background-color: #fff;
	    padding: 10px 0 20px 0;
		margin: 20px 10px;
		border-radius: 20px;
	    -webkit-flex-wrap: wrap;
	    flex-wrap: wrap;
	    font-size: 12px;
	    font-weight: 400;
	    position: relative;
		.list-item{
		    width: 25%;
		    margin: 10px 0;
		    -webkit-align-self: flex-start;
		    align-self: flex-start;
		    position: relative;
		    z-index: 200;
			.icon {
			    margin: 0 auto 10px;
			}
			.t {
			    color: #5c6772;
			    text-align: center;
			}
		}
	}
	
	.zhishuList {
	    background: #fff;
	    border-radius: 0px 0px 18px 18px;
	    padding: 10px;
	    padding-top: 0;
	    margin-bottom: 15px;
		.item {
		    width: 49%;
		    border-radius: 10px;
		    padding-bottom: 10px;
			
			
			.name {
			    padding: 10px 0 5px 0;
			    font-size: 13px;
			    color: #333;
			}
			.price {
			    font-size: 16px;
			    font-weight: 600;
			}
			uni-image {
			    width: 100px;
			    height: 26px;
			}
			.per {
			    font-size: 10px;
			}
		}
		
	}
	.item.green {
	    background:  #d8efff;
	    color: #1677ff;
	}
	.item.red{
	    background: linear-gradient(180deg,rgba(253,67,49,.06),rgba(255,120,95,.06));
	    color: #fd4331;
	}
	
	
	.stockList{
	    background: #fff;
	    border-radius: 18px 18px 0px 0px;
	    margin-top: 15px;
	}
	.box {
		.top {
		    padding: 10px 15px;
			uni-view {
			    color: #91a2b1;
			}
		}
		.box-item {
		    padding: 10px 0;
		    margin: 0 15px;
		    border-bottom: 1px solid #f1f1f1;
		    font-size: 19px;
			.list-name-txt {
			    font-size: 17px;
			    color: #333;
				.txt{
				    font-size: 12px;
				    color: #5f6671;
				}
			}
			.red {
			    font-family: Roboto;
			    font-weight: 700;
			    color: #eb333b;
			}
			.per {
			    font-weight: 700;
			    padding: 5px 0;
			}
			
		}
	}
	
</style>