<!-- 주주들은 지분을 줄인다记录 -->
<template>
	<view>
		
		<view>
			<view class="header flex flex-b" >
				<view class="icon jiantou" @click="$http.goBack()"></view>
				<view class="header-center flex-1"></view><!---->
				<view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view>
			</view>
		</view>
		<view class="" v-for="(item,index) in list" :key="index">
			<view style="margin: 30rpx; word-wrap:break-word;">
				<view class="display">
					<view class="">
						<view class="did-not">
							
							{{item.goods.name}}
							<text>{{$t('index.purchased')}}</text>
						</view>
						
					</view>
					<view class="did-not">{{$t('index.price')}} <text>{{item.price}}</text>
					</view>
				</view>
				<u-divider></u-divider>
				<view class="quantity">
					<view class="display flex-b">
						<view class="">{{$t('index.Quantity')}}</view>
						<view class="red-mark">{{item.num}}</view>
					</view>
					<view class="display">
						<view class="">{{$t('index.amount')}}</view>
						<view class="red-mark">{{item.amount}}</view>
					</view>
				</view>
				<view class="quantity">
					<!-- <view class="display">
						<view class="">申购型号</view>
						<view class="" style="width: 50%;">{{item.order_sn}}</view>
					</view> -->
					<view class="display">
						<view class="">{{$t('index.time')}}</view>
						<view class="">{{item.created_at}}</view>
					</view>
				</view>
			</view>
			<view style="height: 4rpx;width: 100%;background: #f5f5f5;"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: '',
			};
		},
		methods: {
			
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-log', {
					// language: this.$i18n.locale
				})
				this.list = list.data
				// console.log(list.data.data)
			},

		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}
	.header{
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
	}
	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;
		
		.display {
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>
