<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
			<view class="college-text">{{$t('index.Dragon_and_tiger_list')}}</view>
			<view class=""></view>
		</view>
		<view class="ulto">
			<view class="">{{$t('index.name')}}</view>
			<view class="">{{$t('index.Listing_date')}}</view>
			<view class="">{{$t('index.Translate')}}</view>
		</view>
		<view class="lis" v-for="(item,index) in dragon" :key="index">
			<view class="">
				<view class="name" style="margin-bottom: 6rpx;">{{item.secu_abbr}}</view>
				<view class="area" v-if="item.locate==$t('index.deep')">
					<view class="deep">{{item.locate}}</view>
					<view class="deep-number">{{item.secu_code}}</view>
				</view>
				<view class="area" v-if="item.locate==$t('index.North')">
					<view class="north">{{item.locate}}</view>
					<view class="north-number">{{item.secu_code}}</view>
				</view>
				<view class="area" v-if="item.locate==$t('index.Shanghai')">
					<view class="shanghai">{{item.locate}}</view>
					<view class="shanghai-number">{{item.secu_code}}</view>
				</view>
			</view>
			<view class="trading_day">
				{{item.trading_day}}
			</view>
			<view class="detailed-information" @click="detail(item)">{{$t('index.Details')}}</view>
		</view>


		<!-- 弹窗 -->
		<u-popup class="popup" :show="show" :round="20" mode="center" @close="close" @open="open">
			<view class="" v-for="(item,index) in detailed" :key="index">
				<view class="popupContent">
					<view class="content">
						<view class="amount">{{$t('index.Total_amount')}}</view>
						<view class="money">{{item.business_balance }}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.number_of_transactions')}}</view>
						<view class="money">{{item.business_amount}}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.Ratio_of_purchases_to_total')}}</view>
						<view class="money">{{item.buy_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.Ratio_of_total_sales_to_total_sales')}} </view>
						<view class="money">{{item.sale_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.purchase_amount')}}</view>
						<view class="money">{{item.buy_balance}}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.sale_price')}} </view>
						<view class="money">{{item.sale_balance }}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.Net_purchase_amount')}}</view>
						<view class="money">{{item.net_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">{{$t('index.sales_rate')}}</view>
						<view class="money">{{item.sale_balance}}</view>
					</view>
				</view>
				<view class="account">{{$t('index.Why_it_s_on_the_list')}}:{{item.abnormal_type}}</view>
			</view>

		</u-popup>


	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				dragon: '',
				detailed: ''
			};
		},
		methods: {
			detail(item) {
				this.show = true
				this.popNotification(item)
			},
			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			},

			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/index'
				});
			},
			// 列表 
			async tigerList() {
				let list = await this.$http.get('api/stock-api/BaseDragonTiger', {})
				this.dragon = list.data.data
			},
			// 弹窗详情 
			async popNotification(item) {
				let list = await this.$http.get('api/stock-api/BaseDragonTigerInfo', {
					secu_code: item.secu_code
				})
				this.detailed = list.data.data
			},
		},
		mounted() {
			this.tigerList()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 20rpx;
		height: 100rpx;
		background-image: linear-gradient(to bottom, #1c4199, #40a2db);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	.ulto {
		border-bottom: 2rpx solid #e0e0e0;
		display: flex;
		justify-content: space-between;
		margin-top: -20rpx;
		background: #fff;
		border-radius: 30rpx 30rpx 0 0;
		padding: 20rpx 30rpx;
		color: #666;
	}

	.lis {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx;
		font-size: 30rpx;
		border-bottom: 2rpx solid #e0e0e0;

		.name {
			font-size: 30rpx;
			color: #1a1a1a;
		}

		.secu_code {
			color: #666;
			font-size: 26rpx;
		}

		.trading_day {
			font-size: 28rpx;
			color: #1a1a1a;
		}

		.detailed-information {
			background-image: linear-gradient(to right, #1a73e8, #014b8d);
			border-radius: 30rpx;
			text-align: center;
			color: #fff;
			padding: 6rpx 36rpx;
			font-size: 28rpx;
		}
	}

	//弹窗
	/deep/.u-popup__content {
		width: 90%;
	}

	.popupContent {
		padding: 10rpx 30rpx;
		text-align: center;
		font-size: 28rpx;
		text-align: left;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;

		.content {
			width: 50%;
		}

	}


	.amount {
		margin: 30rpx 0;
	}

	.money {
		margin: 30rpx 0;
		color: #dd362b;
		font-weight: 600;
		font-family: "\82F9\65B9";
	}

	.account {
		text-align: center;
		color: #333;
		font-size: 24rpx;
		margin: 0 0 30rpx;
	}
</style>
