<!-- 学院 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
			<view class="college-text">{{$t('index.News_Details')}}</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<rich-text :nodes="html"></rich-text>
			<!-- <view class="" v-html='html'> -->

		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: {},
				html: '',
				id: ""
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async gain_views(e) {
				let list = await this.$http.get('api/article/info', {
					id: e,
				})
				this.list = list.data.data
				this.html = list.data.data.content || ''
				// console.log(this.html)
			},
		},
		onLoad(option) {
			this.title = option.title
			this.gain_views(option.id)
			this.id = option.id
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-image: linear-gradient(to bottom, #1c4199, #40a2db);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 30rpx;

		.time {
			color: #aaa;
		}

		image {
			margin: 30rpx 0;
			width: 100% !important;
		}

		img {
			width: 100% !important;
			// margin-left: -60rpx;
		}


	}

	p {
		margin: 30rpx 0;
		text-align: left;
		color: #2e2e2e;
		// text-indent: 2em;
	}
</style>
