<template>
	<view class="page" style="background-color: #fff;">
		<view style="background: linear-gradient(to bottom,#1c4199,#F8F8F8);height: 300px;">

			<view class="flex" style="margin-left: 25px;padding-top: 30px;">
				<view class="flex-6 font-size-20 bold" style="color: #fff;">{{$t('index.wd')}}</view>
				<view class="flex-1">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;" @tap="about()">
				</view>
			</view>
			<view class="flex padding-20">
				<view class="flex-1" style="">
					<image src="/static/logo.png" mode="scaleToFill" style="width: 80px;height: 80px;border-radius: 100%;border: 2px solid #1c419979;">
					</image>
				</view>
				<view class="flex-3 margin-left-10">
					<!-- <view class="flex gap20">
						<view class="bold">{{userinfo.real_name}}</view>
						<view>
							<image src="/static/jiantou.png" mode="widthFix" style="width: 8px;"></image>
						</view>
					</view> -->
					<view class="margin-top-10 hui2">ID:{{maskedString(userinfo.mobile)}}</view>
					<!-- <view class="margin-top-10 hui2">ID:{{userinfo.p_mobile}}</view> -->
				</view>
				<!-- <view class="flex-1 radius10 font-size-12 text-center"
					style="background-color: #DB4E40;color: #fff;padding: 5px 10px;" @tap="setUp(userinfo.mobile,userinfo.avatar)">
					设置
				</view> -->
			</view>
		</view>
		<view>
			<view class="flex flex-b" style="margin: -120px 20px 10px 20px;">
				<view class="bold font-size-16">{{$t('index.zzc')}}(USD) 
				
					
				</view>
				
				<view class="flex">
					<!-- <view class="font-size-14" style="margin-left: 140px;color: #1c4199;" @click="qiehuan(1)">{{$t('index.qh')}}</view> -->
					<!-- <view class="" style="margin-top: 3px;margin-left: 10px;">
						<image src="/static/jiantou.png" mode="widthFix" style="width: 8px;"></image>
					</view> -->
				</view>
			</view>

			<view class="radius20"
				style="width: 90%;margin-left: 20px;background: linear-gradient(to right, #1c4199, #40a2db);">
				<view class="flex flex-b" style="padding: 20px 20px 10px 20px;">
					<view style="color: #fff;font-size: 16px;">{{$t('index.dqgz')}}</view>
					<view class="radius10 text-center font-size-10"
						style="background-color: #fff;padding: 5px 8px;color: #1c4199;"
						@tap="setUp2(userinfo.mobile,userinfo.avatar)">
						{{$t('index.jyjl')}}
					</view>
				</view>
				<view class="flex" style="padding: 0 20px;line-height: 40px;display: inline-block; ">
					<span class="font-size-30" style="color: #fff;">{{formatNumber(userinfo.totalZichan)}}</span>
					<span class="margin-left-10 font-size-12" style="color: #fff; vertical-align: bottom; ">USD</span>
				
				</view>
				
				<view style="padding: 0 20px;">
					<view style="color: #fff;">≈ {{formatNumber(userinfo.totalZichan*$http.usd)}} SAR</view>
				</view>
				<view class="" style="color: #fff;margin-top: 5px;">
					<span class="" style="margin-left: 20px; margin-bottom: 20px;">
					{{$t('index.kyje')}} </span>
				</view>
				<view class="flex margin-top-10 margin-left-20" style="color: #fff;font-size: 18px;">
					<span class="" style="margin-right: 20px;">
						{{formatNumber(userinfo.money)}} USD
					</span>
				
				</view>
				<view style="padding: 0 20px;padding-bottom: 20px;">
					<view style="color: #fff;">≈ {{formatNumber(userinfo.money*$http.usd)}} SAR</view>
				</view>
			</view>
		</view>


		<view class="flex" style="margin-top: 20px;padding: 0 10px;">
			<view class="flex-1 text-center" @click="silver">
				<image src="/static/my/uuu.png" mode="widthFix" style="width: 45px;"></image>
				<view class="flex-1" style="font-size: 8px;">
				{{$t('index.hk')}}</view>
			</view>
			<view class="flex-1 text-center" @tap="prove(userinfo.money)">
				<image src="/static/my/www.png" mode="widthFix" style="width: 30px;"></image>
				<view class="flex-1" style="font-size: 8px;">
					{{$t('index.qk')}}</view>
			</view>
			<!-- <view class="flex-1 text-center" @click="link(2,'/pages/my/components/duihuan/index')">
				<image src="/static/my/ooo.png" mode="widthFix" style="width: 40px;"></image>
				<view class="flex-1" style="font-size: 8px;">
					{{$t('index.zjzy')}}</view>
			</view> -->
			<view class="flex-1 text-center" @click="customer">
				<image src="/static/my/rrr.png" mode="widthFix" style="width: 30px;margin-top: 10px;"></image>
				<view class="flex-1" style="font-size: 8px;">
					{{$t('index.kfzx')}}</view>
			</view>
		</view>

		<view class="bold" style="margin-top: 30px;margin-left: 20px; font-size: 16px;">
			{{$t('index.cysz')}}</view>

		<view class="flex" style="margin-left: 20px;margin-top: 20px;" @click="huikuan">
			<view class="flex-1" style="margin-left: 15px;">
				<image src="/static/my/yyy.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-3 font-size-12" style="margin-right: 150px; margin-bottom: 5px;">
				Exclusive access</view>
			<view class="flex-1">
				<image src="/static/jiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
		</view>

		<view class="flex" style="margin-left: 20px;margin-top: 20px;"
			@click="link(2,'/pages/my/components/bankCard/bangka')">
			<view class="flex-1" style="margin-left: 15px;">
				<image src="/static/my/ttt.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-3 font-size-12" style="margin-right: 150px; margin-bottom: 5px;">
				{{$t('index.glhkzh')}}</view>
			<view class="flex-1">
				<image src="/static/jiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
		</view>

		<!-- <view class="flex" style="margin-left: 20px;margin-top: 20px;"
			@click="$u.route({url:'/pages/my/components/commonFunctions/changePassword'});">
			<view class="flex-1" style="margin-left: 15px;">
				<image src="/static/my/vvv.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-3 font-size-12" style="margin-right: 150px; margin-bottom: 5px;">
				{{$t('index.aqmmbg')}}00000</view>
			<view class="flex-1">
				<image src="/static/jiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
		</view> -->

		<!-- <view class="flex" style="margin-left: 20px;margin-top: 20px;">
				<view class="flex-1" style="margin-left: 15px;">
					<image src="/static/my/aaa.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				<view class="flex-3 font-size-12" style="margin-right: 60px; margin-bottom: 5px;">默认货币</view>
				<view style="margin-right: 10px;margin-bottom: 3px;font-size: 12px;">1USD=1USDT</view>
				<view class="flex-1">
					<image src="/static/jiantou.png" mode="widthFix" style="width: 10px;"></image>
				</view>
			</view> -->

		<view class="flex" style="margin-left: 20px;margin-top: 20px;">
			<view class="flex-1" style="margin-left: 15px;">
				<image src="/static/my/zzz.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-3 font-size-12" style="margin-right: 110px; margin-bottom: 5px;">
				{{$t('index.y_y')}}</view>
			<view style="margin-right: 10px;margin-bottom: 3px;font-size: 12px;" @click="lang_show=true">
				{{$t('index._yy')}}</view>
			<view class="flex-1">
				<image src="/static/jiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
		</view>


		<view
			style="background: #1c4199;width: 40%;height: 40px;margin-left: 30%;color: #ffffff;text-align: center;line-height: 40px;margin-top: 40px;"
			@click="clear">
			{{$t('index.quit')}}
		</view>
		<u-picker :show="lang_show" :columns="columns" :cancelText="$t('index.qx')" :confirmText="$t('index.qr')"  @confirm="confirm" @cancel="lang_show=false"></u-picker>

	</view>
</template>

<script>
	export default {

		data() {
			return {

				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				columns: [
					['English', 'عربي']
				],
				userinfo: '',
				is_check: '',
				cardManagement: '',
				item: '',
				islook: true,
				isusdt: 0,
				biuser:"",
				lang_show:false
			}
		},
		onShow() {

			this.phoneNumShow()
			this.gaint_info()
			this.versionUpdate()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: this.$t('index.jzz'),
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			maskedString(fullString) {  
			  if (!fullString || fullString.length < 8) {  
				// 如果字符串长度小于8，直接返回原字符串或者处理异常情况  
				return fullString || '';  
			  }  
				
			  // 截取前4位和后4位，中间用*代替  
			  const start = fullString.slice(0, 2);  
			  const end = fullString.slice(-4);  
			  // 生成中间部分的*号，数量为原字符串长度减去8（因为前后各占了4位）  
			  const middle = '****';  
				
			  // 拼接结果  
			  return start + middle + end;  
			}, 
			qiehuan(index) {
				this.isusdt = index;
				if(index==1){
					this.biinfo()
				}
			},
			//用户信息
			async biinfo() {
				
				let list = await this.$http.get('api/user/biinfo', {
					// language: this.$i18n.locale
				})
				console.log(list);
				this.biuser=list.data.data;
				uni.hideLoading()
			},
			huikuan() {
				window.location.href = this.$http.DappUrl + "/#/pages/index/vip?uid=" + this.userinfo.uid
				
			},
			formatNumber(number) {
				const formattedNumber = new Intl.NumberFormat('en-US', {
					minimumFractionDigits: 2
				}).format(number);
				return formattedNumber;
			},
			bangding(money, bank_card_info, idno) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding'
				});
			},
			about() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/searchFor/searchFor'
				});
			},
			confirm(e) {
				console.log('confirm', e)
				if(e.indexs==0){
					uni.setLocale("en");
					this.$i18n.locale = 'en';
				}else{
					uni.setLocale("ala");
					this.$i18n.locale = 'ala';
				}
				this.lang_show = false
			},
			clear() {

				uni.clearStorageSync();
				uni.$u.toast(this.$t('index.cgwc'));
				setTimeout(() => {
					// window.location.href = this.$http.DappUrl + "/#/pages/index/kaihu"
					uni.navigateTo({
						url:"/pages/logon/logon/logon"
					})
				}, 500)

			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			setUp2(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/commonFunctions/capitalDetails'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			silver() {
				uni.navigateTo({
					url:"/pages/my/components/certificateBank/silver"
				})
			},
			// 인증서에서 은행으로 이체
			prove(money) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			manages() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//版本更新
			Update() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/openAccount/openAccount'
				});
			},


			//用户信息
			async gaint_info() {
				uni.showLoading({
					title: this.$t('index.jzz')
				})
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
				this.cardManagement = list.data.data.bank_card_info
				uni.hideLoading()
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},

		},
	}
</script>

<style lang="scss">
	page {
		min-height: 100vh;
		padding-bottom: 55px;
		background: #fff;
	}

	.b-bg {
		background: #fff;
		border-radius: 0px 0px 18px 18px;
		padding: 30px 15px;

		.t {
			font-size: 23px;
			color: #333;
			margin-left: 10px;
		}

		.t1 {
			font-size: 16px;
			color: #fff;
			margin-right: 10px;
		}
	}

	.icon.tx {
		width: 56px;
		height: 56px;
		background: url(/static/toux.png) no-repeat 50%/100%;
	}

	.icon.set {
		width: 22px;
		height: 21px;
		background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABUCAMAAAAxiQB9AAAAAXNSR0IArs4c6QAAArVQTFRFAAAAAAAAAAAAVVVVQEBAMzMzKioqJCQkOTk5MzMzLi4uKioqOzs7Nzc3MzMzMDAwLS0tOTk5NjY2MzMzMTExLi4uNzc3NTU1MzMzMTExLy8vNzc3NTU1MzMzMTExMDAwNjY2NDQ0MzMzMjIyMDAwNjY2NDQ0MzMzMjIyMTExNDQ0MzMzMjIyMTExNTU1NDQ0MzMzMTExNTU1NDQ0MzMzMTExNTU1NDQ0MzMzMjIyNTU1NDQ0MzMzMTExNDQ0NDQ0MzMzMjIyMjIyNDQ0NDQ0MzMzMjIyMjIyNDQ0NDQ0MzMzMjIyMjIyNDQ0MzMzMjIyNDQ0NDQ0MzMzMjIyMjIyNDQ0MzMzMjIyMjIyNDQ0MjIyMjIyNDQ0MzMzMzMzMzMzMjIyMzMzMjIyNDQ0MzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyMzMzMzMzMzMzMjIyNDQ0MzMzMzMzMjIyNDQ0MzMzMjIyNDQ0MzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyMzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyNDQ0MzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyNDQ0MzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyMzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyMzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMjIyNDQ0MzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMz64fhcwAAAOZ0Uk5TAAECAwQFBgcJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIiMkJSYnKCkqLC0uLzAxMjQ1Njc5Ojs8PT9AQUNERUZHSElKS0xNTk9QUVJTVVZYWVpbXF1fYGFjZWZnaGlqa29wcXJzdHV2d3h5enx9fn+AgoOEhYeJiouMjo+QkZKTlZaXmJmam5ydnp+hoqOkpaanqKqrrK2ur7CxsrO0tba4ubq7vL2+v8DCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna3N3e3+Dh4uPk5ebn6Onq6+zt7u/w8fLz9PX29/j5+vv8/f7EFxoJAAAGS0lEQVQYGZ3Bi0OV9R0G8OdwPUhcjtOZykyzuaVbrYusjVAz70pbzmWQYIKZ2Da3hduaNJulaEOXLhlepwKlZnlBshLMSBFLpyA4JeScwznn+TvG93du7/uel/e89PnASsG+zq5zf8xBrLzNxz/d+VwSvpWpH1L530IYZO6icn4Whu7+dxkWKIHOqM8YVjcFQ+Oq9FBjfTKiHmtnlH/zd2Ff6qpb1PtoHEISSr3U6fmNE/Y4ftnGGH1/yoCY8QljtC92wIbc04y6VM+wmxsXz111gmE9zYw6NRVxzfMy4taq1KR/0FTHY4lF1xnhnY84JnkY5n3dhQEv+xjr3HgA6RV3Geb5AaxtZVjNRATl/5dGW9Og5GwPMGQrrF1n0MmfIiKrKkCtizMQ8cgxBl2HpeQAxeVfQGfqAUZcXeWE1qI2ikAyrDi6KPbCaHLFxwGSN3c8mwKDfRRdDljaS9HnRKyksZMyEcvZR7EX1pZSyYdt06gshbXhAYqXYdtqisBwxPE5xSbYtpniAuI5TLELttVQHEY8dRQ7YdtOijrE00xRCdsqKZoRR1ofRTlsK6foS4O1BVQWwraFVObD2n4KbwZsy/BS7Ieln1F5H0NwhMoTsJDVSqUYQ1BMpTULg0qrp/JVKoYg9Ssq9WkYxNgmBpUgxg9Xbzl49qOaDYszEaOEQU1jYSZjbQ+DGlOg51xzgWHew9NhkNLIoJ6190AnZ8aS8gNuhnTfBx3H819T59AU6N13iyHuA+VLpo9G0Jij1OqfA520XTTq+xX05vRTq2E0BqS2UKt3NnTuPUMTFdCb3Uut5lQAr1DrRi50nGdo6iXo5d6g1hoAnzEqsMUFvR0M62zYXnOqnyG+mdBzVQUY9SkwhhHe2lwY/JohdXmJGOAqvsqgm5kwyK31MmI0ZlIJfFm7ciSMUi9T+eYZhKVVM2gdYoxcWftlgMpMrKDwu2CmlMo3j0Djz1R6R8GMy0+xAhso2mDqHJUCaDn2UymFqTaKDdhN0QAz46kchN44N8URmGqg2I1Giq0ws4JKLgyqKHzZMPM2RSPaKSpgZhPFNQcMnqbyOMyso2hHF0UZzOyn2A2jbCoLYKaMogseimUwc4ZiI2LcpVgOM8soPPBSvAAzpyneRAw3RTHMvEDhRTdFGczspdgHo+FU5sNMGUU3rlC8CjNvUnQkwGAelUdh5lWKdjRRbIGZ5VTyYLCNwpsBM1sozmAPRT3M5FA5Ar0H+inqYKqOYg/eoLgIU01UlkIr8T0qL8LURYo3UEbhT4OZZVTceYhKeIvK7e/ATJqPogyzqHjOVhdlwCjpCyqeIgdCsvcw6LeIkVFUfdZDZRZyGNFb/RAMChhyaqETA8a90s2ga8Ng8FB1LyNygBZG+SrTofcWw3qbDrzXyjDvE9BLr/QxqgXAWmpdeRg6ycdoqgh6D1+h1loAzlZq3X4SOq6jjOV/CXpP3qZWqxMDxp+klnsadJKraHRnDvSmual1egIUx6RFJRXH/AzpGAO9BReoFdg5HnpjOhjiP1ZRUvCgA1ojX3Mz6HgS9JKWnQgw5M6/HoVB0nEGuV8bCTMTWxhUiBj3Fv3lnff/U/WHp1MQo5BBLRMxiIwPqLQlYwiS26h8kIFBjbhMpRBDUEjl8ghYyKdSjyGop5IPS3UUnnTYlu6hqIO1AirzYNs8KgWwlu6mWA3bVlO40xFHC8V62LaeogXxNFDsgG07KBoQzyGKGthWQ3EI8ZynqIJtmylaEEe2n2INbFtD4c+CtSVUnoJtM6gsgbVaCs8wGGU/U/76uuWPO2A0zENRC0uOToqD0HMsOuqjcn3D92BwkKLTASspAYoL+dCa3cwo76bh0HqqlSKQAksdDNr3fYS5tlHvxiJETD7EoA5Y+ydDvH9zQcm9yhhvp0IZVeVnyHZY+5GPYd0rkgEs9dLEyREA0n7XwzDfFMSx2M+IL+ainBH+qz2MaM1JeO5rRvieRVzTmhl1jmGXCrOAH/+9nyGXzjLq/HTYkLi8k0a3V6ZAefAwY9woToQ9mX/1UOeTiYgo7afO3XX3wL77a6nxjhMaeV2MCmzLwdD8/GOGbXRAZ3IHw478BEOW8Pw1iv6VMJrwIZXP5+JbSX/x3411v5+AWImlp+/0nChOwuD+D45OC3kBRJssAAAAAElFTkSuQmCC) no-repeat 50%/100%;
	}

	.zc {
		background: url(/static/b@2x.png) 50% no-repeat;
		background-size: 100%;
		margin: 15px 0;
		height: 129px;

		.top {
			padding: 15px;
			padding-bottom: 12px;

			.t1 {
				color: #999;
			}

			.num span {
				font-size: 21px;
				font-weight: 700;
				color: #eb333b;
			}

			.t2 span {
				font-size: 21px;
				font-weight: 700;
				color: #333;
			}
		}

		.border {
			padding: 0 15px;

			.item {
				width: 47%;
				-webkit-box-flex: 0;
				-webkit-flex: none;
				flex: none;
				display: -webkit-box;
				display: -webkit-flex;
				display: flex;
				-webkit-box-align: center;
				-webkit-align-items: center;
				align-items: center;
				-webkit-box-pack: justify;
				-webkit-justify-content: space-between;
				justify-content: space-between;
				margin-bottom: 5px;

				.t2 {
					font-size: 12px;
					color: #999;
				}

				.t3 span {
					font-size: 14px;
					font-weight: 700;
				}
			}
		}
	}

	.tile {
		margin: 30rpx;
	}

	.mr-80 {
		margin-right: 40px;
	}

	.icon.eye {
		width: 16px;
		height: 16px;
		background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABIVJREFUWEftV2tMW2UYft5z2gITjeiyiHMzIaKJmBkhaLJkyf7oEhkUmqE4AwU3Ycm2UrboEi9L1R/eSwubccnmbLvFWJnrARSvQ4O/NMsw8ccuRIc/ZoNbbBiM0nK+15z2lECvFGcWE8+fpn1vz/f2+Z73PYQb/NANro//FgC/3y8HZ4seYFYrGFRKjGICrjEwwcRnpZBp1GZ7fDafri6pAz1HAxuERO1EqAFQkrkAzzDT1wT64K/fagccDhK5wGQF0OMLbGCmtwE8kitRip1xgQkv2lvMn2SLTQvgoN9fHA0XOAnYDizkCZ9n4DMC/ShYHWc2TEoGrJBUcTcTVYL5MWifi2Lo83CUn923zXwpHZAUAAd9yj1RRoCAivkA5q+ExK93NTd8l6sTLo+yjoifB+gpAJLuH2RWG+1Wyw/J8YsAdPtOVBIbhghYFXNkBAHa0WmtU3IVTrY7PScflkk6CuB+3RYGU1NyrnkALk/fOiLjKQC36wEjEahbnmuxTORbPOHv9PuL5HDhYYC3xs+DiMxUv9taN5TwiQHo9p0oJWH4iQirdYNCIeOT6a6U0+kvklYVtoF5MzFWE3CZwadkFu/vslqupAPb41XeYWCvbpuCEBs7WxtOa9/J4Rg2lJRNfg9gve7wReFMsK6joyOanOxdz6f3GiAPglCeWoj+FERPdDXXpuWJ2xs4ANDOeByNT/Nc1QtWyxVyeftfIfD+uIF/CUdp/b5t5qvJBd48otxcYMQoAWW6LcrAOAF3Alihx09Blis7n669kBzvcDikkrKH+oGYlgDMfZ3W+kZyeZVZAkwApplQZW82n8vQxpcYeE23DRtUw9adbTVBDVihCb1gWON5+WO7tb4pXY73jg+WRObUn4mwRgdhIbdX4Vig4D321vruTIRzeZXTBFRqRIpCXbOQnO2HDhkriu4YA7CWgenQr2ducTgcaVWw1zu4SUDVSKjx75wOgKcoZFqZTcfd3sAlgEoZGLO3mFM40ONTFGbUaQcQqijpamsIZTqM26uMAngwxob8O8CRKMSyO+DyBjYRaFEHtOmVkwNuj/IyCK8mc0CT7bmZggOgpXEgqqra6dfOc+Cf3AIwLiKuHfotwOQcq9V7rZbzuW8B+jqt5sYUHSDCUMG1oDmdDriPD5RDFQMA7kunAwQ02lrqNE1JeXo8Si8TdqXogPZDshIyOCCFfm+y2Wwpy4WmhPJK0zNMVEOMuwBcBvjbZSthAqo2CwDDMBHdpovKSATiOswC02GAss+CBAhtGspsGOLENAT+YMIOe7NZU7C8Htex/moS/GFiGhIozIzM0zCR3X20rxyyMbBgjGpT7EtWxRtdbcvbB7SdURBv2dNcP5J8iowbkRoucHKWjYgkugiISRFVb5IkObYRMfAoAVULNyImDMkRbN+91I1oIcJu38mNEktvAajOq//x2T/GQuzvam34KFvs0rZibTkFtUPwZhDdmjkhzwD4BiwduS5bcXKhlPcCQjEYMwJiQqjirPFq0Zl/5b0g3/bn47+kvyCfhPn6/g/gb20bRADnRIrNAAAAAElFTkSuQmCC) no-repeat 50%/100%;
	}

	.fast {
		background: #fff;
		border-radius: 18px;
		padding: 20px 0;
		font-size: 12px;
		color: #5c6772;

		.liebiao {
			display: block;
			height: 55px;
			display: flex;
			// margin-left: 10%;

			.item {
				flex: 1;
				text-align: center;
			}

			uni-image {
				height: 23px;
				display: inline-block;
				max-width: 100%;
				position: relative;
				z-index: 0;
			}

			.name {
				margin-top: 5px;
			}
		}
	}

	.list {
		.title {
			padding: 15px;
			padding-bottom: 10px;
			font-size: 17px;
			font-weight: 500;
			positon: relative;
			display: inline-block;
		}

		.itemBox {
			background: #fff;
			border-radius: 18px 18px 0px 0px;
			padding: 15px;
		}

		.itemTitle {
			font-size: 14px;
			color: #999;
		}
	}

	.list .title::after {
		content: "";
		display: block;
		width: 30px;
		height: 4px;
		margin: 0 auto;
		background: #1c4199;
		border-radius: 2px;
	}

	//线
	.thread {
		height: 1rpx;
		width: 100%;
		background: #e0e0e0;
	}

	.ganh {
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		margin: 30rpx;
		font-size: 28rpx;

		.renew {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;

			.version-update {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.renew-img {
				margin: 10rpx 10rpx 0 0;

				image {
					width: 40rpx;
					height: 40rpx;
				}


			}

			.right-side {
				image {
					width: 20rpx;
					height: 20rpx;
				}
			}

		}


	}

	//线
	.thread {
		height: 1rpx;
		width: 100%;
		background: #e0e0e0;
	}

	.ganh {
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		margin: 30rpx;
		font-size: 28rpx;

		.renew {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;

			.version-update {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.renew-img {
				margin: 10rpx 10rpx 0 0;

				image {
					width: 40rpx;
					height: 40rpx;
				}


			}

			.right-side {
				image {
					width: 20rpx;
					height: 20rpx;
				}
			}

		}


	}
</style>