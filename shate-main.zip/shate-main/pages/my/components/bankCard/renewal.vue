<!-- 绑定银行卡 -->
<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" >
				<view class="icon jiantou" @click="$http.goBack()"></view>
				<view class="header-center flex-1">
					{{$t('index.tjskdz')}} </view>
				<view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view>
			</view>
		</view>
		<view class="bankInfo-box margin-top-20" >
			<view class="bold font-size-16">
				{{$t('index.xzhb')}} </view>
			<view class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" @click="show=true">
				<view class="font-size-16">{{huobi}}</view>
				<image src="/static/xiajiantou.png" mode="widthFix" style="width: 15px;"></image>
			</view>
		</view>
		
		<view  style="padding: 10px 20px;" v-if="type==2">
			<view class="bold font-size-16">
				{{$t('index.qbdz')}} </view>
			<input :placeholder="$t('index.srdz')" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="address"/>
		</view>
		<view v-if="type==1">
			<view  style="padding: 10px 20px;">
				<view class="bold font-size-16">
					Bank Card account </view>
				<input placeholder="Please add bank card account" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="address"/>
			</view>
			
			<view  style="padding: 10px 20px;">
				<view class="bold font-size-16">
					{{$t('index.yhmc')}} </view>
				<input :placeholder="$t('index.sryhmc')" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;"  v-model="bank_name"/>
			</view>
			
			<view  style="padding: 10px 20px;">
				<view class="bold font-size-16">
					{{$t('index.yhdm')}} </view>
				<input :placeholder="$t('index.sryhdm')" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="bank_code"/>
			</view>
			
			<!-- <view  style="padding: 10px 20px;">
				<view class="bold font-size-16">银行地址</view>
				<input placeholder="请输入银行代码" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="bank_sub_name_address"/>
			</view> -->
			
			<view  style="padding: 10px 20px;">
				<view class="bold font-size-16">
					{{$t('index.skrxm_')}} </view>
				<input :placeholder="$t('index.srskrxm')" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="realname"/>
			</view>
		</view>
		
		
		
		
		<view class="purchase" @click="replaceBank()">
			{{$t('index.jcbd')}}
		</view>

		<u-picker :show="show" :columns="columns"  @confirm="confirm" @cancel="show=false" :cancelText="$t('index.qx')" :confirmText="$t('index.qr')"></u-picker>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				type:1,
				huobi:"Card",
				columns: [
					['ERC20-USDT', 'TRC20-USDT', 'Card']
				],
				realname:"",
				address:"",
				bank_name:"",
				bank_code:"",
				card_sn:"",
				bank_sub_name_address:""
			};
		},
		methods: {
			confirm(e) {
				console.log('confirm', e)
				this.show = false
				this.huobi=e.value[0]
				if(e.indexs[0]==2){
					this.type=1
				}else{
					this.type=2
				}
				
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.realname,
					bank_name: this.bank_name,
					bank_sub_name_address: this.bank_sub_name_address,
					// card_sn: this.card_sn,
					bank_code:this.bank_code,
					address:this.address,
					type:this.type,
					huobi:this.huobi
				})
				if (list.data.code == 0) {
					uni.$u.toast(this.$t('index.yhkcgtj'));
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    padding: 50px 0 0;
	}
	.header{
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
	}
	.bankInfo-box {
	    padding: 16px;
	    background: #fff;
	}
	.list{
	    padding: 0 22px;
	    margin-bottom: 16px;
	    height: 48px;
	    background: #f6f6f6;
	    border-radius: 24px;
	}
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #1c4199;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 0 22px;
			margin-bottom: 16px;
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;
			view {
				width: 22%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #1c4199;
		margin: 100rpx 30rpx;
		border-radius: 24px;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
</style>