<template>
	<view class="box">
		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
			<view class="college-text">{{$t('index.hj')}}</view>
			<view class=""></view>
		</view>
		<view class="box_con">
			<view class="sculpture">
				<view class="">
					{{$t('index.touxiang')}}:
				</view>
				<view style="margin-left: 50rpx; ">
					<u-upload @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1" width="250"
						height="150">
						<!-- <image src="https://cdn.uviewui.com/uview/demo/upload/positive.png" mode="widthFix"
							style="width: 250px;height: 150px;"></image> -->
						<u-avatar :src="src"></u-avatar>
					</u-upload>
				</view>
			</view>
			<view class="name">
				<view>{{$t('index.nc')}}:</view>
				<u-input :placeholder="$t('index.xgnc')" color="#646464" border="bottom" v-model='nick_name'>
				</u-input>
			</view>
		</view>
		<view class="box_but" @click="submit_list">
			{{$t('index.jcgx')}}
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '../../../../utils/js_sdk.js'
	export default {
		data() {
			return {
				fileList6: [],
				is_url: "",
				src: '',
				nick_name: "",
			}
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			async submit_list() {
				let list = await this.$http.post('api/user/updateAvatar', {
					avatar: this.is_url,
					nickname: this.nick_name,

				})
				if (list.data.code == 0) {
					uni.$u.toast(this.$t('index.ygg'));
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						// 登录成功之后强制刷新页面
						this.$router.go(0)
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// 回调参数为包含columnIndex、value、values
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {

				})
				this.src = list.data.data.avatar
				// this.nick_name = list.data.data.nick_name
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
			},
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,

					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
				this.src = this.fileList6[0].thumb
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
		},
		mounted() {
			this.userInfo()
		}
	}
</script>

<style lang="less" scoped>
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color:  #1c4199;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	/deep/.uni-input-placeholder {
		font-size: 28rpx;
	}

	.box_but {
		// font-weight: bold;
		// width: 100%;
		// margin: 0 auto;
		// margin: 100rpx 30rpx;
		border-radius: 10rpx;
		background:  #1c4199;
		color: #fff;
		text-align: center;
		padding: 20rpx 0;
		position: fixed;
		width: 90%;
		left: 5%;
		right: 5%;
		bottom: 100rpx;

	}

	.box_con {
		padding: 40rpx 40rpx;
		background-color: #fff;
		margin-bottom: 30rpx;
		// color: #000;
		font-weight: bold;
		border-radius: 30rpx;
		margin: 20rpx;
		box-shadow: 1px 1px 1px 1px #f1f1f1;
		font-size: 28rpx;

		.sculpture {
			display: flex;
			align-items: center;
		}

		.name {
			display: flex;
			align-items: center;
			margin: 60rpx 0 0;

			input {
				margin-left: 30rpx;
				font-size: 28rpx;
			}
		}
	}
</style>