<!-- 인증서에서 은행으로 이체 -->
<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/jiant.png" mode="widthFix" style="width: 15px;" @tap="$http.goBack()"></image>
				<view class="college-text">{{$t('index.zjzy')}}</view>
				<view class=""></view>
			</view>
		</view>
		<view class="flex margin-top-20 margin-left-20"
			style="background-color: #f5f5f5;height: 50px; width: 90%;border-radius: 5px;" @click="show=true">
			<view class="flex-1 margin-left-20" style="font-size: 14px;">{{$t('index.hbxz')}}</view>
			<!-- <view class="flex margin-right-5" style="font-size: 14px; color: #ca5010;" @click="show=true">USDT</view> -->
			<view class="font-size-16 margin-right-5">{{huobi}}</view>
			<!-- <image src="/static/xiajiantou.png" mode="widthFix" style="width: 15px;"></image> -->
			<view class="margin-right-20">
				<image src="/static/jiantou.png" mode="widthFix" style="width: 6px;height: 10px;"></image>
			</view>
		</view>

		<view class="margin-20 font-size-16 bold">{{type==0?$t('index.dz'):$t('index.kh')}}</view>

		<view class="flex margin-top-20 margin-left-20"
			style="background-color: #f5f5f5;height: 50px; width: 90%;border-radius: 5px;">
			<view class="flex-1 margin-left-20" style="width: 70%;word-wrap: break-word;" @click="add_address">{{dizhi}}</view>
		</view>
		<view class="flex margin-left-20 margin-top-10">
			<!-- <view class="flex">Available funds</view>
		<view class="flex margin-left-10" style="color: #ca5010;"> {{formatNumber(userinfo.money)}} </view> -->
		</view>

		<view class="margin-20 font-size-16 bold">{{$t('index.zzje')}}</view>
		<view class="flex">
			<view class="flex-1">
				<input :placeholder="$t('index.srqkje')"
					style="background-color: #f5f5f5;width: 100%;margin-left: 20px;height: 50px;border-radius: 5px;text-indent: 20px;font-size: 14px;"
					v-model="value1"></input>
			</view>
			<view class="flex padding-10"
				style="background-color: #f5f5f5;height: 30px;margin-right: 20px;border-radius: 5px;">
				{{type==2?'USD':'SAR'}}
			</view>
		</view>


		<view class="flex" style="margin: 10px 20px;">
			<view>Available funds</view>
			<view class="margin-left-10" style="color: #ca5010;">{{type==2?userinfo.money:userinfo.money*$http.usd}}</view>
			<view class="margin-left-5" style="color: #ca5010;">{{type==2?'USD':"SAR"}}</view>
		</view>


		<button
			style="background: linear-gradient(to bottom, #1c4199, #40a2db);width: 70%;height: 40px;border-radius: 30px;color: #fff;font-size: 16px;margin-top: 20px;"
			@click="to_withdraw">{{$t('index.qr')}}</button>

		<u-picker :show="show" :columns="columns" keyName="val" :cancelText="$t('index.qx')" :confirmText="$t('index.qr')"
			@confirm="confirm" @cancel="show=false"></u-picker>

	</view>
	</view>



	</view>

</template>

<script>
	// import {
	// 	Value
	// } from '/sass';
	export default {
		data() {
			return {
				show: false,
				type: "",
				huobi: this.$t('index.qxz'),
				columns: [
					['ERC20-USDT', 'TRC20-USDT', 'Card']
				],
				value1: '',
				value2: '',
				value3: "",
				userinfo: '',
				dizhi: "",
				bank_cards: ""
			};
		},
		methods: {
			add_address() {
				uni.navigateTo({
					url: "/pages/my/components/bankCard/bangka"
				})
			},
			confirm(e) {
				console.log('confirm', e)
				this.show = false
				this.huobi = e.value[0]
				this.dizhi = this.$t('index.qxtj')
				
				for (var i = 0; i < this.bank_cards.length; i++) {
					// console.log(bank_card[i].address);
					if (this.bank_cards[i].huobi == e.value[0]) {
						if (this.bank_cards[i].address) {
							this.dizhi = this.bank_cards[i].address
						} else {
							uni.$u.toast(this.$t('index.qxtj'));
						}
					}
				}
				if (e.indexs[0] == 2) {
					this.type = 1
				} else {
					this.type = 2
				}
			},
			async to_withdraw() {
				if (!this.value1) {
					uni.$u.toast(this.$t('index.srzzje'));
					return
				}
				if (!this.type) {
					uni.$u.toast(this.$t('index.xzhb'));
					return
				}

				uni.showLoading({
					title: this.$t('index.tkjxz'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});

				let list = await this.$http.post('api/app/withdraw', {
					type: this.type,
					huobi: this.huobi,
					total: this.value1
				})

				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			formatNumber(number) {
				const formattedNumber = new Intl.NumberFormat('en-US', {
					minimumFractionDigits: 2
				}).format(number);
				return formattedNumber;
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
				let info = this.gaint_info()
			},
			//用户信息
			async gaint_info() {



				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				let bank_card = list.data.data.bank_card_info
				this.bank_cards = bank_card
				// i++    i+=1    i=i+1
				// for (var i = 0; i < bank_card.length; i++) {
				// 	// console.log(bank_card[i].address);
				// 	if(bank_card[i].huobi=="ERC20-USDT"){
				// 		console.log(i);
				// 		this.dizhi=bank_card[i].address
				// 	}
				// }
				// this.dizhi = list.data.data.bank_card_info[0].address
				// console.log(list.data.data.bank_card_info,'95555');
				this.userinfo = list.data.data



			},


		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {

		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 70rpx;
		background-color: #f5f5f5;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #000;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #ffffff;
			font-size: 26rpx;
		}
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		background: #fff;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>