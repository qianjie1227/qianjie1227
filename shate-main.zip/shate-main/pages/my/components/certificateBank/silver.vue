<template>
	<view>
		<view class="background-white flex flex-b padding-10" >
			<image src="/static/zjt.png" mode="widthFix" style="width: 10px;margin: 10px;"  @click="$http.goBack()"></image>
			<view class="text-center" style="margin: 0 auto;">Recharge</view>
		</view>
		<view class="margin-top-10 padding-10">
			<view class="bg-white padding-20 radius20">
				<view class="flex gap10">
					<view class="flex-1">
						<image src="/static/ERC20.png" mode="widthFix" style="width: 40px;" ></image>
					</view>
					<view class="flex-5" style="box-sizing: border-box;max-width: 60%; ">
						<view class="bold">USDT (ERC20)</view>
						
						<view style="word-wrap: break-word;white-space: normal;overflow-wrap: break-word;flex-shrink: 0;box-sizing: border-box;">
							<view class="font-size-12 hui1" >
								{{erc_address}}
							</view>
						</view>
						
					</view>
					<view class="font-size-12 padding-10 radius10 flex-1 text-center" style="background-color: #f5dbd9;color: #DB4E40;" @click="copy(erc_address)">Copy</view>
				</view>
			</view>
			<view class="bg-white padding-20 radius20 margin-top-20">
				<view class="flex gap10">
					<view class="flex-1">
						<image src="/static/TRC20.png" mode="widthFix" style="width: 40px;" ></image>
					</view>
					<view class="flex-5" style="box-sizing: border-box;max-width: 60%; ">
						<view class="bold">USDT (TRC20)</view>
						
						<view style="word-wrap: break-word;white-space: normal;overflow-wrap: break-word;flex-shrink: 0;box-sizing: border-box;">
							<view class="font-size-12 hui1" >
								{{trc_address}}
							</view>
						</view>
						
					</view>
					<view class="font-size-12 padding-10 radius10 flex-1 text-center" style="background-color: #f5dbd9;color: #DB4E40;" @click="copy(trc_address)">Copy</view>
				</view>
			</view>
			
			<view class="flex flex-b bg-white padding-20 radius20 margin-top-20" @click="bank()">
				<view class="flex gap10">
					<!-- <image src="/static/ERC20.png" mode="widthFix" style="width: 40px;"></image> -->
					<view class="bold">Bank Transfer</view>
				</view>
				<view class="font-size-12 padding-10 radius10" style="background-color: #f5dbd9;color: #DB4E40;" @click="customer">Contact</view>
			</view>
		</view>
	
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
			
				trc_address:'',
				erc_address:"",
				kefu:""
			};
		},
		methods: {
			
			async getconfigs() {
				let list = await this.$http.post('api/qianbao/getconfigs', {})
				console.log(1111,list);

				this.trc_address = list.data.data.trc_address
				this.erc_address = list.data.data.erc_address
				this.kefu = list.data.data.CustomerLink
				// this.list = list.data.data[8].value
				
			},
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast(this.$t('index.qxjcmm'));
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: this.$t('index.fzcg'),
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			
		},

		onLoad(option) {
			this.getconfigs()
		},
		
	}
</script>

<style lang="scss">
	page{
		background-color: #F8F8F8;
	}
</style>