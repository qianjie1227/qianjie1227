<!-- 인증서에서 은행으로 이체 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
				<view class="college-text">{{$t('index.zszzdyh')}}</view>
				<view class=""></view>
			</view>
			<view class="progress"> {{userInformation.money}}</view>
			<view class="vacancies">{{$t('index.dqkyye')}}</view>
		</view>
		
		<view class="cash-withdrawal" v-if="userInformation">
			<view class="withdrawal">{{$t('index.tkzh')}}</view>
			<view class="money">
				<input  v-model="userInformation.bank_card_info.realname" disabled=""></input>
			
			</view>
		</view>
		
		<view class="cash-withdrawal">
			<view class="withdrawal">{{$t('index.tkje')}}</view>
			<view class="money">
				<input :placeholder="$t('index.jinlia')" v-model="value1"></input>
				<view class="" @click="whole(userInformation.money)">
					{{$t('index.every')}}
				</view>
			</view>
		</view>
		<view class="cash-withdrawal">
			<view class="withdrawal">{{$t('index.zjmm')}}</view>
			<view class="money">
				<input :placeholder="$t('index.qsrmm')" type="password" v-model="value2"></input>
			</view>
		</view>
		<view class="cash-withdrawal">
			<view class="withdrawal">{{$t('index.yhm')}}</view>
			<view class="money">
				<input :placeholder="$t('index.yhm')" style="width: 90%;"  wtype="text" v-model="value3"></input>
			</view>
		</view>
		<view class="purchase" @click="to_withdraw()">
			{{$t('index.qrtx')}}
		</view>

		<view class="point-out">
			<view>{{$t('index.wufatixian')}}</view>
			<!-- <view>{{$t('index.tongguoshiming')}}</view> -->
			<view>{{$t('index.tikuanshijian')}}</view>
			<view>{{$t('index.meicizuidi')}}</view>
			<view><text>{{$t('index.zuiwandaozhang')}}</text>
			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		methods: {
			async to_withdraw() {
				uni.showLoading({
					title: this.$t('index.tkjxz'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3
					
				})
				// console.log(list.data.code, 'code');
				
			
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				if (!list.data.data.bank_card_info) {
					console.log(1111)
					uni.navigateTo({
						url:'/pages/my/components/bankCard/binding'
					})
					
				}
				this.userInformation = list.data.data
				
				
				
			},
			

		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {
			
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #ffffff;
			font-size: 26rpx;
		}
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		background: #fff;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>