<!-- 用户协议 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="$http.goBack()"></image>
			<view class="college-text">{{agreement.title}}</view>
			<view class=""></view>
		</view>
		<view class="college-content">

			<view class="" v-html="agreement.content"></view>


			<u-divider></u-divider>



		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				agreement: ''
			};
		},
		methods: {
			
			async agreeOn() {
				let list = await this.$http.get('api/article/user-agree', {
					// language: this.$i18n.locale
				})
				this.agreement = list.data.data
			},
		},
		mounted() {
			this.agreeOn()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #1c4199;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

	}
</style>
