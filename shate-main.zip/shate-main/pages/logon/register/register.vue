<template>
	<view class="page lg-bg">
		<view class="lg"><!---->
			<view class="flex flex-c">
				<view class="icon logo">
					<image src="/static/logo.png"></image>
				</view>
			</view>
		</view>
		<view class="form">
			<view class="item">
				<view class="ipt flex flex-b">
					<uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input  
							      maxlength="9"  
							      step="0.000000000000000001"  
							      enterkeyhint="done"  
							      autocomplete="off"  
							      type="number"  
							      class="uni-input-input"  
							      :placeholder="$t('index.Please_ente_ your_phone_number')"  
							      v-model="value1"  
							    />
						</div>
					</uni-input>

				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" :placeholder="$t('index.qsrmm')" type="password" class="uni-input-input" v-if="showPassword" v-model="value2">
							
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" :placeholder="$t('index.qsrmm')" type="text" class="uni-input-input" v-if="!showPassword" v-model="value2">
						</div>
					</uni-input>
					<view class="icon" :class="showPassword?'e':'e1'" @click="showPassWord"></view>
				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" :placeholder="$t('index.verify_password')" type="password" class="uni-input-input" v-if="showPassword" v-model="value3">
							
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" :placeholder="$t('index.verify_password')" type="text" class="uni-input-input" v-if="!showPassword" v-model="value3">

						</div>
					</uni-input>
					<view class="icon" :class="showPassword?'e':'e1'" @click="showPassWord"></view>
				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" :placeholder="$t('index.Enter_invitation_code')" type="password" class="uni-input-input" v-model="code">
							
						</div>
					</uni-input><!----></view>
			</view>
			<view class="btns flex flex-b">
				<view class="login-btn flex-1 flex flex-c" @click="gain_register">
				{{$t('index.registration')}}</view>
			</view>
			<view class="btns flex flex-b">
				<view class="login-btn1 flex-1 flex flex-c" @click="dapp">
				Dapp {{$t('index.registration')}}</view>
			</view>
		</view>
		<view>
			<view class="flex flex-c lg-btn" @tap="signIn()">
				<view>{{$t('index.log_in_now')}}</view>
				<view class="icon jt"></view>
			</view>
		<!-- 	<view class="kefu flex flex-c">
				<view class="img flex flex-c">
					<image src="/static/kefu.png" style="width: 24px;height: 24px;"></image>
				</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				checkboxValue1: [],
				showPassword: true
			};
		},
		watch: {  
		    value1(val) {  
		      // 使用正则表达式验证输入是否为11位数字  
		      // const regex = /^[0-9]{9}$/;  
		      // if (!regex.test(val)) {  
		      //   this.value1 = ''; // 如果不是11位数字，清空输入框  
		      // }  
		    },  
		  },
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					url:"/pages/logon/logon/logon"
				})
			},
			dapp(){
				window.location.href=this.$http.DappUrl+"/#/pages/index/kaihu"
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast(this.$t('index.Please_ente_ your_phone_number_1'));
				} else if (this.value2 == '') {
					uni.$u.toast(this.$t('index.qsrmm'));
				} else if (this.value3 == '') {
					uni.$u.toast(this.$t('index.qsrmm'));
				} else if (this.value3 != this.value2) {
					uni.$u.toast(this.$t('index.Two_passwords_do_not_match'));
				} else if (!this.code) {
					uni.$u.toast(this.$t('index.qsryqm'));
				}
				// else if (this.checkboxValue1.length == 0) {
				// 	uni.$u.toast('請閱讀協議後,在勾選');
				// } 
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						nick_name: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast(this.$t('index.Registration_has_been_completed_Please_log_in'));
						setTimeout(() => {
							uni.navigateTo({
								url:"/pages/logon/logon/logon"
							})
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
		async mounted() {
			await this.login_liufu()
		}
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
	}

	.lg-bg {
		width: 100%;
		height: 100%;
		background: url(/static/lg-bg.png) no-repeat top/100%;
	}

	.lg {
		padding: 55px 0;
		text-align: center;
	}

	.icon.logo {
		width: 99px;
		height: 99px;
		border-radius: 50%;
		overflow: hidden;

		uni-image {
			width: 100%;
			height: 100%;
		}
	}

	.form {
		background: #fff;
		padding: 0 16px;
		font-size: 14px;

		.item .ipt {
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;
			padding: 0 11px;
			margin-bottom: 16px;

			uni-input {
				background: transparent;
				padding-left: 11px;
			}
		}

		.btns {
			padding-top: 11px;
			padding-bottom: 11px;

			.login-btn {
				height: 48px;
				background-image: linear-gradient(to bottom, #1c4199, #40a2db);
				border-radius: 24px;
				font-size: 17px;
				font-weight: 700;
				color: #fff;
			}
			.login-btn1 {
				height: 48px;
				background: #fd483c;
				border-radius: 24px;
				font-size: 17px;
				font-weight: 700;
				color: #fff;
			}
		}
	}

	.lg-btn {
		width: 50%;
		height: 44px;
		line-height: 44px;
		background: #fff;
		border-radius: 11px;
		margin: 11px auto;

		uni-view {
			font-size: 17px;
			font-weight: 700;
			color: #1c4199;
		}

		.icon {
			margin-left: 5px;
		}
	}

	.kefu {
		border-top: 1px solid #dedede;
		width: 50%;
		margin: 11px auto;
		padding-top: 22px;

		.img {
			width: 49px;
			height: 49px;
			background: #f6f6f6;
			border-radius: 50%;
		}
	}
</style>