<template>
	<view class="page lg-bg">
		<view class="lg flex flex-c"><!---->
			<view class="flex flex-c">
				<view class="icon logo">
					<image src="/static/logo.png"></image>
				</view>
			</view>
		</view>
		<view class="form">
			<view class="item">
				<view class="ipt flex flex-b">
					<input maxlength="9" :placeholder="$t('index.Please_ente_ your_phone_number')" type="number"
						v-model="value1" class="uni-input-input" />

				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b">
					<input maxlength="18" type="password" :placeholder="$t('index.qsrmm')" enterkeyhint="done"
						autocomplete="off" v-model="value2" class="uni-input-input" v-if="showPassword" />

					<input maxlength="18" type="text" :placeholder="$t('index.qsrmm')" enterkeyhint="done"
						autocomplete="off" v-model="value2" class="uni-input-input" v-if="!showPassword" />

					<view class="icon" :class="showPassword?'e':'e1'" @click="showPassWord"></view>
				</view>
			</view>
			<view class="btns" @click="gain_login">
				<view class="login-btn flex flex-c">{{$t('index.log_in')}}</view>
			</view>
			
			<view class="btns" @click="dapp" >
				<view class="login-btn1 flex flex-c">Dapp {{$t('index.log_in')}}</view>
			</view>
			
			<!-- <view class="flex">
				<u-checkbox-group v-model="checked">
					<u-checkbox  activeColor="red" :label="$t('index.Save password')"></u-checkbox>
				</u-checkbox-group>
			</view> -->
		</view>
		<view>
			<view class="flex flex-c lg-btn" @tap="register()">
				<view>{{$t('index.Register_now')}}</view>
				<view class="icon jt"></view>
			</view>
			<!-- 	<view class="kefu flex flex-c">
				<view class="img flex flex-c">
					<image src="/static/kefu.png" style="width: 24px;height: 24px;"></image>
				</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				value1: "",
				value2: '',
				showPassword: true,
				checked: false
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//忘记密码
			forget() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/forgot/forgot'
				});
			},
			// 跳转到注册
			register() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/register/register'
				});
			},
			dapp(){
				window.location.href=this.$http.DappUrl+"/#/pages/index/kaihu"
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$t('index.successful_login'));
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// //数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },

		},

		async mounted() {
			// await this.login_liufu()

		}

	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
	}

	.lg-bg {
		width: 100%;
		height: 100%;
		background: url(/static/lg-bg.png) no-repeat top/100%;
	}

	.lg {
		padding: 55px 0;
		text-align: center;

		.logo uni-image {
			width: 100%;
			height: 100%;
		}
	}

	.icon.logo {
		width: 99px;
		height: 99px;
		border-radius: 50%;
		overflow: hidden;
	}

	.form {
		background: #fff;
		padding: 0 16px;
		font-size: 14px;

		.item .ipt {
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;
			padding: 0 11px;
			margin-bottom: 16px;

			uni-input {
				background: transparent;
				padding-left: 11px;
			}
		}

		.btns {
			padding-top: 11px;
			padding-bottom: 11px;

			.login-btn {
				height: 48px;
				background-image: linear-gradient(to bottom, #1c4199, #40a2db);
				border-radius: 24px;
				font-size: 17px;
				font-weight: 700;
				color: #fff;
			}
			.login-btn1 {
				height: 48px;
				background: #fd483c;
				border-radius: 24px;
				font-size: 17px;
				font-weight: 700;
				color: #fff;
			}
		}
	}

	.lg-btn {
		width: 50%;
		height: 44px;
		line-height: 44px;
		background: #fff;
		border-radius: 11px;
		margin: 11px auto;

		uni-view {
			font-size: 17px;
			font-weight: 700;
			color: #1c4199;
		}

		.icon {
			margin-left: 5px;
		}
	}

	.kefu {
		border-top: 1px solid #dedede;
		width: 50%;
		margin: 11px auto;
		padding-top: 22px;

		.img {
			width: 49px;
			height: 49px;
			background: #f6f6f6;
			border-radius: 50%;
		}
	}
</style>