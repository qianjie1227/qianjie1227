<template>
	<view class="page">
		<view class="header flex flex-b" @click="$http.goBack()">
			<!-- <img class="header-left icon jiantou"> -->
			<view class="header-center flex-1">{{$t('index.My_stock')}}</view>
			<view class="header-right"></view>
		</view>

		<!-- 切换股票 -->
		<view class="toubu">
			<u-tabs :activeStyle="{
		    color: '#fff',
		    fontWeight: 'bold',
			fontSize:'32rpx'
		}" :inactiveStyle="{
		    color: '#fff',
			fontSize:'32rpx'
		}" lineColor="#1c4199" :list="gp_select" :current="gp_index" @click="gp_select_click"></u-tabs>

		</view>

		<view class="dabokl">
			<view class="available-balance">
				<view class="" v-if="gp_index==0">
					<view class="available">{{$t('index.Balance')}}</view>
					<view class="balance">{{userinfo.money}} USD</view>
				</view>
				<view class="" v-if="gp_index==1">
					<view class="available">USD</view>
					<view class="balance">{{userinfo.money}}</view>
				</view>
				<!-- <view>
					<view class="change" @click="silver">{{$t('index.deposit')}}</view>
					<view class="change" @click="duihuan"
						style="margin-top: 20rpx;background-color:#40a2db ;text-align: center;">{{$t('index.exchange')}}
					</view>
				</view> -->

			</view>

			<view class="funding-situation" v-if="gp_index==0">
				<view class="situation">
					<view class="">{{$t('index.amount')}}</view>
					<view class="">{{userinfo.frozen}}</view>
				</view>
				<view class="xian"></view>
				<view class="situation">
					<view class="">{{$t('index.total')}}</view>
					<view class="">{{userinfo.holdYingli}}</view>
				</view>
			</view>

			<view class="funding-situation" v-if="gp_index==1">
				<view class="situation">
					<view class="">{{$t('index.amount')}}</view>
					<view class="">{{userinfo.frozen1}}</view>
				</view>
				<view class="xian"></view>
				<view class="situation">
					<view class="">{{$t('index.total')}}</view>
					<view class="">{{userinfo.holdYingli1}}</view>
				</view>
			</view>

			<view class="sert">
				<view class="inv-h-w">
					<!-- 切换持仓历史 -->
					<block v-for="(item,index) in items" :key="index">
						<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="qiehuan(index)">{{item}}</view>
					</block>
				</view>

				<view v-if="Inv == 0&&gp_index==0" class="up-and-down-range">
					<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
						v-for="(item,index) in storehouse" :key="index">
						<view class="display" style="margin:0 30rpx ;">

							<view class="share-certificate flex" @tap="productDetails(item.goods_info.number_code)">
								<view>{{$t('index.wwww')}} : </view>
								<h6 style="margin-left: 10px;color: #666666;">{{item.goods_info.name}} </h6>
							</view>
						
							<view>
								<button
									style="margin-top: 10px;border-radius: 10px;height: 30px;background-color: #40a2db;color: #fff;font-size: 14px;"
									@tap="sell(item)">{{$t('index.ppp')}}</button>
							</view>

							<!-- <view v-if="gp_index==0"> X{{item.order_buy.double}}</view> -->


						</view>
						<view class="flex" style="margin-left: 15px;">
							<view class="flex">Direction :</view>
							<view class="flex">{{item.order_buy.direct==1?'Buy high':'Buy low'}}</view>
						</view>
						
						<view class="flex margin-top-15" style="margin-left: 15px;">
							<view class="flex ">{{$t('index.rrrr')}} ：</view>
							<view class="flex ">{{item.goods_info.number_code}}</view>
						</view>
						<view class="margin-left-15 margin-top-15">
							<view class="flex">
								<view class="flex">{{$t('index.ffff')}} :</view>
								<view class="flex" style="margin-left: 10px;" :style="item.order_buy.yingkui>0?'color:#34a339':'color:#e0343b'">{{item.order_buy.yingkui>0?'+':''}}{{item.order_buy.yingkui}}
								</view>
							</view>
							<view class="flex " style="margin-top: 15px;">
								<view class="flex">{{$t('index.jjjj')}} :</view>
								<view class="flex margin-left-10">{{item.order_sn}}</view>
							</view>

						</view>
						<u-picker :show="gp_show" :columns="gp_select" :cancelText="$t('index.qx')" :confirmText="$t('index.qr')"
							:closeOnClickOverlay="true" @close="gp_show=false" @cancel="gp_show=false"
							@confirm="gp_changes"></u-picker>

						<view class="overlay" v-if="item_show" @click="item_show=false"></view>
						<view
							style="position: fixed;left: 0;right: 0; width:100%;border-radius: 20px 20px 0 0;background-color: #f5f5f5;bottom: 0;z-index: 9999;padding-bottom: 30px;padding:20px;"
							v-if="item_show">
							<view class="padding-10 flex ">
								<view class="text-center justify-center width100 font-size-18 bold"
									style="margin-bottom: 10px;">{{$t('index.oooo')}}</view>

								<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
							</view>
							<view class="margin-bottom-30 " style="margin-left: 40px;">
								<view class="flex">
									<view class="flex">{{$t('index.rrrr')}} :</view>
									<view class="flex margin-left-10">{{info.goods_info.number_code}}</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.wwww')}} :</view>
									<view class="flex margin-left-10">{{info.goods_info.name}}</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">Direction :</view>
									<view class="flex margin-left-10">{{info.order_buy.direct==1?'Buy high':'Buy low'}}</view>
								</view>
								
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.qqqq')}} :</view>
									<view class="flex margin-left-10" style="color: #34a339;">{{info.order_buy.price}}
									</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.eeee')}} :</view>
									<view class="flex margin-left-10">{{info.order_buy.num}}</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.mmmm')}} :</view>
									<view class="flex" style="color: #34a339;">
										{{(info.order_buy.num*info.order_buy.price)}}
									</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.cccc')}} :</view>
									<view class="flex margin-left-10" style="color: #34a339;">
										{{((info.goods_info.current_price*info.order_buy.num*1).toFixed(2))}}
									</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.ffff')}} :</view>
									<view class="flex margin-left-10" :style="info.order_buy.yingkui>0?'color:green':'color:red'">{{info.order_buy.yingkui>0?'+':''}}{{info.order_buy.yingkui}}
									</view>
								</view>
								<view class="flex margin-top-10">
									<view class="flex">Profit and loss percentage:</view>
									<view class="flex margin-left-10" :style="info.order_buy.yingkui>0?'color:green':'color:red'">{{info.order_buy.yingkui>0?'+':''}}{{((info.goods_info.current_price-info.order_buy.price)/info.order_buy.price*100).toFixed(2)}}%
									</view>
								</view>
								
								<view class="flex margin-top-10">
									<view class="flex">{{$t('index.yyyy')}} :</view>
									<view class="flex margin-left-10">{{info.created_at}}</view>
								</view>
							</view>
							<view class="flex">
								<view class="flex-1">
									<button
										style="width: 50%;height: 30px;font-size: 14px;background-color: #1e50dc;color: #fff;"
										@tap="productDetails(info.goods_info.number_code)">{{$t('index.kkkk')}}</button>
								</view>
								<view class="flex-1">
									<button
										style="width: 50%;height: 30px;font-size: 14px; background-color: #e0343b;color: #fff;"
										@tap="position(info.id)">{{$t('index.iiii')}}</button>
								</view>
							</view>


						</view>
					</view>
				</view>

				<view class="up-and-down-range" v-if="Inv == 0&&gp_index==1">
					<view class="" v-for="(item,index) in storehouse" :key="index">
						<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
							<view class="up-date">{{$t('index.price')}}:<text>{{item.goods_info.price}}</text></view>
							<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
							<view class="time">{{$t('index.time')}}:{{item.created_at}}</view>
						</view>
						
						<view class="shadow">
							<view class="display">
								<view class="">Name:</view>
								<view class="quantity">{{item.goods_info.name}}</view>
							</view>
							<view class="display">
								<view class="">Code:</view>
								<view class="quantity" >{{item.goods_info.code}}</view>
							</view>
						</view>
						
						<view class="shadows">
							<view class="display">
								<view class="">{{$t('index.dqsy')}}:</view>
								<view class="quantity">{{item.float_yingkui}}</view>
							</view>
							<view class="display">
								<view class="">{{$t('index.direction')}}:</view>
								<view class="quantity" :style="item.fx==2?'color:red':'color:green'">{{item.fx==1?$t('index.BUY'):$t('index.SELL')}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">{{$t('index.purchase_price')}}:</view>
								<view class="quantity">{{item.price}}</view>
							</view>
							<view class="display">
								<view class="">{{$t('index.Quantity')}}:</view>
								<view class="quantity">{{item.num}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">{{$t('index.gmfy')}}:</view>
								<view class="quantity">{{item.fee}}</view>
							</view>
							<view class="display">
								<view class="">{{$t('index.gmjg')}}:</view>
								<view class="quantity">{{item.total}}</view>
							</view>
						</view>
						
						
						<view class="text-center padding-10 margin-10" style="background-color: #1c4199;color: #fff;" @click="position1(item.id)">Close position</view>
						
					</view>
				</view>

				<!-- <view class="finished-text">
						{{$t('index.no_more')}}
					</view> -->
			</view>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' :cancel-text="$t('index.xc')"
			:confirm-text="$t('index.ck')">
		</u-modal>

		<u-modal :show="show1" :title="title" @cancel="cancel1" @confirm="confirm1(confirmation1)"
			:showCancelButton='showCancelButton' :content='content' :cancel-text="$t('index.xc')"
			:confirm-text="$t('index.ck')">
		</u-modal>

		<view class="transaction" v-if="Inv == 1&&gp_index==0">
			<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
				v-for="(item,index) in storehouses" :key="index" @tap="productDetails(item.goods_info.number_code)">
				<view class="display" style="margin:0 30rpx ;">
					<view class="share-certificate">
						<h6>{{item.goods_info.name}}</h6>

					</view>
				</view>
				<view style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
					<view class="display ">
						<view class="up-date">{{$t('index.Selling_time')}}：{{item.order_sell.created_at}} </view>
					</view>
					<view class="shadow margin-top-10">
						<view class="display">
							<view class="">{{$t('index.dqsy')}}:</view>
							<view class="quantity" style="color: #1c4199;">{{item.order_sell.float_yingkui}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.syze')}}:</view>
							<view class="quantity" style="color: #1c4199;">{{item.order_sell.yingkui}}</view>
						</view>
					</view>
					
					
					<view class="shadow margin-top-10">
						
						<view class="display margin-top-10">
							<view class="">Profitability:</view>
							<view class="quantity" style="color: #1c4199;">{{(item.order_sell.yingkui/item.order_buy.price*100/item.order_sell.num).toFixed(2)}}%</view>
						</view>
					</view>
					
					<view class="shadows margin-top-10">
						<view class="display">
							<view class="">{{$t('index.closing_price')}}:</view>
							<view class="quantity" style="color: #1c4199;">{{item.order_sell.price}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.Quantity')}}:</view>
							<view class="quantity">{{item.order_sell.num}}</view>
						</view>
					</view>
					<view class="shadows margin-top-10">
						<view class="display">
							<view class="">{{$t('index.cjf')}}:</view>
							<view class="quantity">{{item.order_sell.sell_fee}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.scjz')}}:</view>
							<view class="quantity" style="color: #1c4199;">{{item.order_sell.amount}}</view>
						</view>
					</view>
					
				</view>

			</view>
			<!-- <view class="finished-text">
					{{$t('index.no_more')}}
				</view> -->
		</view>


		<view class="transaction" v-if="Inv == 1&&gp_index==1">
			<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
				v-for="(item,index) in storehouses" :key="index" @tap="productDetails(item.goods_info.number_code)">
				<view class="display" style="margin:0 30rpx ;">
					<view class="share-certificate">
						<h6>{{item.goods_info.name}}</h6>
					</view>
				</view>

				<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
					<view class="up-date">{{$t('index.Selling_time')}}：{{item.order_sell.created_at}} </view>
				</view>
				<view style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
					<view class="margin-top-10">
						<view class="display">
							<view class="">{{$t('index.dqsy')}}:</view>
							<view class="quantity">{{item.order_sell.float_yingkui}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.direction')}}:</view>
							<view class="quantity">{{item.fx==1?$t('index.BUY'):$t('index.SELL')}}</view>
						</view>
					</view>
					<view class="margin-top-10">
						<view class="display">
							<view class="">{{$t('index.closing_price')}}:</view>
							<view class="quantity">{{item.order_sell.price}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.Quantity')}}:</view>
							<view class="quantity">{{item.order_sell.num}}</view>
						</view>
					</view>
					<view class="margin-top-10">
						<view class="display">
							<view class="">{{$t('index.cjf')}}:</view>
							<view class="quantity">{{item.order_sell.sell_fee}}</view>
						</view>
						<view class="display margin-top-10">
							<view class="">{{$t('index.scjz')}}:</view>
							<view class="quantity">{{item.order_sell.amount}}</view>
						</view>
					</view>
					<view class="margin-top-10">
					
						<view class="display">
							<view class="">{{$t('index.gmfy')}}:</view>
							<view class="quantity">{{item.fee}}</view>
						</view>
					</view>
				</view>
				

			</view>
		</view>

	</view>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				gp_select: [{
					name: this.$t('index.grd'),
				}, {
					name: this.$t('index.Overseas'),
				}],
				gp_index: 0,
				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: [this.$t('index.shareholding'), this.$t('index.ls')],
				show: false,
				show1: false,
				isShow: false,
				
				title: "Close position",
				content: "Do You Want To Close position?",
				
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				storehouses1: '',
				subscribe: '',
				gp_show: false,
				gp_index: 0,
				pqorder: '',
				userinfo: '',
				timerId: null,
				confirmation: "",
				item_show: false,
				confirmation1: "",
				gdorder: ""
			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: this.$t('index.jzz'),
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.shuaxin()
			// this.flat()
			uni.stopPullDownRefresh()
		},

		methods: {
			shuaxin() {
				// this.storehouse=""
				// uni.showLoading({
				// 	mask:true
				// })
				if (this.Inv == 0) {
					this.hold()
				} else if (this.Inv == 1) {
					this.flat();
				}
			},
			sell(item) {
				this.info = item
				this.item_show = true;
			},
			position(id) {
				this.item_show = false
				this.show = true;
				this.confirmation = id


			},
			gp_changes(index) {
				console.log(index)
				this.gp_index = index.indexs[0]
				this.gp_show = false

				this.storehouse = ""

				this.shuaxin()
			},
		
			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							console.log(_this);
							_this.confirmSell(id);
							uni.hideLoading();
						} else if (res.cancel) {
						}
					}
				})
			},
			qiehuan(index) {
				this.Inv = index
				console.log(111,this.gp_index);

				this.shuaxin()

			},
			async guadan_order() {
				let list = await this.$http.post('api/Product/gdorder', {

				})
				this.gdorder = list.data.data
			},


			gp_select_click(e) {
				this.storehouse = ""

				this.gp_index = e.index
				this.Inv = 0
				this.shuaxin()

			},
			// 平仓
			position(id) {
				this.show = true;
				this.confirmation = id
			},
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			position1(id) {
				this.show1 = true;
				this.confirmation1 = id
			},
			cancel1() {
				this.show1 = false;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				this.closingFunction(confirmation)
				this.show = false;
			},
			confirm1(confirmation) {
				this.closingFunction1(confirmation)
				this.show1 = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver() {

				window.location.href = this.$http.DappUrl + "/#/pages/index/index?uid=" + this.userinfo.uid
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},




			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data.data
				// console.log(list.data.data, '持仓');
				uni.hideLoading()
			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index: this.gp_index
				})
				this.storehouses = list.data.data

			},
			async closingFunction1(confirmation) {
				uni.showLoading({
					title: this.$t('index.gcwzzbpc'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/bi/sell', {
					id: confirmation,
					// price: item.price
				})
				this.show=false;
				this.show1=false;
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {

					this.shuaxin()
					uni.$u.toast('Successly');
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: this.$t('index.gcwzzbpc'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				this.show=false;
				this.show1=false;
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {

					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log(this.$t('index.wzqq'));
					this.shuaxin()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求

			},

			duihuan() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/duihuan/index'
					// url:"/pages/my/components/certificateBank/prove"
				});
			},
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$wsbiUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					// var data=JSON.parse(res.data);

				});
			},
		},

		onShow() {
			uni.showLoading({
				title: this.$t('index.jzz')
			})
			this.is_token()
			this.gaint_info()
			this.hold()
			this.startTimer()
			this.sockets()
		},

		onUnload() {
			console.log(this.$t('index.ypc1'));
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})

		},
		onHide() {
			console.log(this.$t('index.ypc2'));
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})

		},

	}
</script>

<style lang="scss">
	.page {
		padding: 53px 0 26px;
	}

	.page {
		background: #fff;
		min-height: 100vh;
	}

	uni-view,
	uni-text {
		box-sizing: border-box;
	}


	.header {
		height: 53px;
		background: #1c4199;
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 12px;
			height: 20px;
		}

		.header-center {
			font-size: 17px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 17px;
		}
	}

	/deep/.u-modal__content__text {
		text-align: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background:#1c4199;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color:#1c4199;
		font-size: 24rpx;
		vertical-align: middle;
	}

	.toubu {
		width: 100%;
		background-image: linear-gradient(to right,#1c4199,#1c4199);
		display: flex;
		justify-content: space-between;
		color: #fff;
	}

	.dabokl {
		background: #fff;
		width: 100%;
		border-radius: 30rpx 30rpx 0 0;
		padding-top: 30rpx;

		.available-balance {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.balance {
				font-weight: 600;
			}


			.change {
				background: #1e50dc;
				color: #FFFFFF;
				padding: 10rpx 50rpx;
				font-size: 24rpx;
				border-radius: 20rpx;
			}
		}

		.funding-situation {
			display: flex;
			align-items: center;
			justify-content: space-around;
			text-align: center;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.xian {
				height: 100rpx;
				width: 2rpx;
				background: #9e9e9e;
			}


		}


		.inv-h-w {
			background-color: #FFFFFF;
			height: 80rpx;
			display: flex;
			margin-top: 50rpx;
		}

		.inv-h {
			font-size: 28rpx;
			flex: 1;
			text-align: center;
			color: #666666;

			position: relative;
		}

		.inv-h-se {
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #1e50dc;
		}

		.inv-h-se:after {
			content: '';
			position: absolute;
			bottom: 20rpx;
			// top: auto;
			left: 42%;
			height: 6rpx;
			width: 44rpx;
			background-color: #fff;
		}

		//我的持仓
		.up-and-down-range {

			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.position {
				background-image: linear-gradient(to right, #1e50dc, #1e50dc);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				width: 30%;

				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
				width: 30%;
			}

			.time {
				color: #666;
				// width: 60%;
				text-align: right;
			}

			

			

		}
		.shadow {
			background: #aac0ff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx 30rpx;
		
			font-size: 26rpx;
		
			.display {
				width: 40%;
		
				.quantity {
					color: #ff0a0a;
				}
			}
		}
		.shadows {
		
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 6rpx 30rpx;
			font-size: 26rpx;
		
			.display {
				width: 40%;
		
				.quantity {
					color: #ff0a0a;
					text-align: right;
					width: 50%;
				}
			}
		}
		// 没有更多
		.finished-text {
			color: #969799;
			font-size: 28rpx;
			margin: 30rpx auto;
			text-align: center;
			padding: 30rpx 0;
		}

		// 我的交易
		.transaction {

			// padding: 0 30rpx;
			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.overlay {

				position: fixed;
				/* Stay in place */
				top: 0;
				left: 0;
				width: 100%;
				/* Full width */
				height: 100%;
				/* Full height */
				z-index: 999;
				/* Sit on top */
				background-color: rgba(0, 0, 0, 0.5);
				/* Black background with opacity */
				cursor: pointer;
				/* Add a pointer on hover */
			}

			.position {
				background-image: linear-gradient(to right, #1a73e8, #1e50dc);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
			}

			.time {
				color: #666;
			}

	


			// 没有更多
			.finished-text {
				color: #969799;
				font-size: 28rpx;
				margin: 30rpx auto;
				text-align: center;
				padding: 30rpx 0;
			}
		}

	}
	
</style>