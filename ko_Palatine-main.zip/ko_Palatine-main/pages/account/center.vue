<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderPrimary isSearch  :color="$theme.SECOND"></HeaderPrimary>

		<Profile :info="userInfo"></Profile>

	
		<view style="display: flex;align-items: center;padding:20rpx 30rpx;" class="gap10">
			<view @click="linkDeposit()" class="flex-1 flex gap10 text-center justify-center" style="background-color: #fff7ee;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;margin-top: 10px;">
					<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 36rpx;color:#DA7437;font-weight: 700;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>
			
			
			<view @click="linkWithdraw()" class="flex-1 flex gap10 text-center justify-center" style="background-color: #fff7ee;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;margin-top: 10px;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 36rpx;color:#DA7437;font-weight: 700;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			
		
		</view>



		<view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx 32rpx 0 0;">
			
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view>
		</view>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemThird
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>