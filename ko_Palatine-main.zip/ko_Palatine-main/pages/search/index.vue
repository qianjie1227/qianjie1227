<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond :title="$lang.SEARCH_TITLE" :color="$theme.SECOND"></HeaderSecond>
		

		<view style="margin:40rpx;">
		
			<u-search placeholder="" v-model="keyword"  searchIconSize="30" height="40px" :placeholder="$lang.TIP_SEARCH" :showAction="true" @search="searchButton()" :actionText="'찾다'" :actionStyle="{ backgroundColor: '#f6d0ab', color: '#fff', borderRadius: '5px',padding:'5px' }"></u-search>	
		</view>

		<view style="padding:0 40rpx;">
			<TitleSecond :title="$lang.SEARCH_HISTORY">
				<image mode="aspectFit" src="/static/delete.png" :style="$theme.setImageSize(44)"
					style="margin-left: auto;" @click="clearKeywords()"></image>
			</TitleSecond>
		</view>

		<view style="display: flex;align-items: center;margin:0 10px;flex-wrap: wrap;">
			<template v-if="keywords.length>0">
				<block v-for="(item,index) in keywords" :key="index">
					<view
						style="padding:4px 10px;margin:4px;border-radius: 32rpx;background-color:#FFFFFF;color:#333333;"
						@click="selectedItem(item)">{{item}}</view>
				</block>
			</template>
		</view>

		<view style="padding-bottom: 80rpx;">
			<SearchList :list="list"></SearchList>
		</view>
	</view>
</template>
<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import SearchList from './components/SearchList.vue';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
			SearchList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,
			};
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		// 下拉刷新
		onPullDownRefresh() {
			this.searchButton();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton();
			},

			//搜索
			async searchButton() {
				console.log(22222);

				if (this.keyword == '' || this.keyword.length < 3) {
					uni.showToast({
						title: this.$lang.TIP_SEARCH,
						icon: 'none'
					})
					return false;
				}
				uni.showToast({
					title: this.$lang.LOADING_SEATCH,
					icon: 'none',
				});
				const result = await this.$http.get(`api/product/list`, {
					key: this.keyword,
					name:this.name,
					page: this.curPage,
					limit: this.limit,
					gp_index: 0
				})
				console.log(result);
				this.list = result
				console.log('search result:', this.list)
				if (this.keywords.indexOf(this.keyword) < 0) {
					this.keywords.push(this.keyword);
					uni.setStorageSync("keywords", this.keywords)
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.u-search__content__input {
		background-color: transparent !important;
	}
</style>