<template>
	<view style="padding: 20rpx;background-color: #FFFFFF;margin:20rpx;min-height: 100vh;">
		<span>Real Estate Investment Trust (REIT) is an investment vehicle that allows individual investors to
			invest indirectly in real estate projects by purchasing fund shares. REITs are usually managed by a
			management company, which holds and operates a portfolio of real estate assets, including commercial
			real estate, residential real estate, etc.<br><br>

			Investors can capture the returns in the real estate market by purchasing shares or units in a REIT
			without having to buy or hold the property directly. REITs provide a relatively stable investment
			option, usually with high capital preservation and dividend returns.<br><br>

			In the Indian stock market, there are several key differences between buying REITs through an
			institutional account and using a regular stock trading account.<br><br>

			1. Access: Typically, Wealth Management Accounts are held by professional investment institutions or
			companies that manage assets, and they may have wider market access and faster market execution.
			Therefore, it may be more efficient and convenient to purchase REITs through institutional
			accounts.<br><br>

			2. Investment scale: Wealth Management Accounts usually have a larger investment scale and can conduct
			larger transactions. This gives Wealth Management Accounts greater purchasing power and a greater likelihood
			of receiving more favorable trading conditions.<br><br>

			3. Investment purpose: Wealth Management Accounts typically conduct transactions based on more complex
			investment strategies and objectives, including hedging, arbitrage, etc. In contrast, ordinary stock
			trading accounts may be more biased towards long-term investment and value investment.
			<br><br>
			It should be noted that, generally speaking, ordinary investors can purchase REITs through ordinary
			stock trading accounts, but they may need to face some restrictions or conditions, such as minimum
			purchase quantities, transaction fees, etc. Therefore, when choosing which account to purchase REITs
			through, you need to consider your investment purposes, fund size, and market access needs.</span>
	</view>
</template>

<script>
	export default {
		name: 'EaIntroduce',
	}
</script>

<style>
</style>