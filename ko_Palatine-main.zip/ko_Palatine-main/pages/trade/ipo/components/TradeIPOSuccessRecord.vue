<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:30rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_VALUE}" style="font-size: 36rpx;flex:70%;">{{item.goods.name}}
						</view>
						<template v-if="item.status==2">
							<view class="common_btn" @click="subscription(item)">{{$lang.TRADE_IPO_SUCCESS_SUB}}</view>
						</template>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_PRICE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_APPLY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_QUANTITY}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.success)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.success_num_amount)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_FREEZE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.freeze)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_UNPAY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{item.success*item.price-item.freeze>0?
								$util.formatMoney(item.success*item.price*1-item.freeze*1):0+`
								${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_ORDER_SN}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.order_sn}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_SUCCESS_CT}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeIPOSuccessRecord',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		created(option) {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				console.log(result);
				this.list = result || [];
			},

			async subscription(item) {
				const result = await this.$http.post(`api/goods-shengou/pay`, {
					id: item.id
				});
				console.log('result:', result);
				// if (result.code == 0) {
				// 	uni.$u.toast(result.message);
				// 	if (result.success == 0) {
				// 		setTimeout(() => {
				// 			this.$util.linkCustomerService();
				// 		}, 500)
				// 	} else {
				// 		uni.redirectTo({
				// 			url: TRADE_IPO_SUCCESS,
				// 		});
				// 		this.$router.go(0)
				// 	}
				// } else {
				// 	uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				// }
			},
		},
	}
</script>