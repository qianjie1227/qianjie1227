export default {
	LAUNCH_TITLE: '股票線上交易平台',
	LAUNCH_PROGRESS_TITLE: '載入中...',
	TRANSLATE_TITLE: '請選擇語言',








	// 網路檢查及網路狀態
	TIP_NETWORK_TYPE_NONE: '目前無網絡，或網路狀態不佳',
	// API 相關提示
	API_TOKEN_EXPIRES: '登陸狀態已過期，請重新登入',
	API_HTTP_ERROR: '請求異常，請刷新重試',



	// 底部導覽組
	TABBAR_HOME: "首頁",
	TABBAR_FOLLOW: "關注",
	TABBAR_MARKET: '行情',
	TABBAR_TRADE: '交易',
	TABBAR_ACCOUNT: '我的',

	// 登入、註冊
	SIGN_IN_TITLE: "登錄",
	SIGN_UP_TITLE: "加入會員",
	BTN_SIGN_IN: '登錄',
	BTN_SIGN_UP: '加入會員',
	BTN_SIMGN_OUT: "登出",
	GO_TO_SIGN_IN: '去登入',
	USER_NAME: '帳號',
	ENTER_USER_NAME: '請輸入帳戶',
	PASSWORD: '密碼',
	ENTER_PASSWORD: '請輸入密碼',
	VERIFY_PASSWORD: '驗證密碼',
	ENTER_VERIFY_PASSWORD: '請再輸入密碼',
	INVITATION_CODE: '邀請碼',
	ENTER_INVITATION_CODE: '請輸入邀請碼',
	TIP_PWD_NOEQUAL: '兩次輸入密碼不一致',
	TIP_SUCCESS_SIGNIN: '登入成功',
	TIP_SUCCESS_REGISTER: '註冊已完成，請登入',
	TIP_SIGNIN_ING: '登錄中',
	TIP_SIGNUP_ING: '註冊中',
	TIP_REMEMBER_PWD: '記住密碼',
	TIP_SIGN_OUT_SUCCESS: '登出成功',
	TIP_AGREE: '閱讀並同意',
	TIP_PRVITE_PACT: '用戶隱私協定',
	TIP_CHECK_AGREE: '請勾選同意用戶隱私協定',
	// 信箱相關
	ENTER_EMAIL: '請輸入信箱',
	GET_EMAIL_CODE: '驗證碼',
	TIP_ENTER_EMAIL: '請輸入正確的信箱',
	TIP_SEND_CODE: '正在傳送驗證碼',
	TIP_SEND_CODE_SUCCESS: '驗證碼傳送成功',
	TIP_ENTER_EMAIL_CODE: '郵箱驗證碼錯誤',

	// 搜尋頁面
	SEARCH_TITLE: '搜尋',
	TIP_SEARCH: '請輸入股票的名稱或代號',
	SEARCH_HISTORY: '搜尋記錄',
	SEARCH_CLEAR: '清除記錄',
	LOADING_SEATCH: '資料查詢中...',



	LOADING_GET_DATA: '取得最新資料',

	// 股票列表
	STOCK_MARKET_ALL: '市場',
	STOCK_MARKET_FOLLOW: '關注',



	// 帳戶相關
	// 個人中心 認證狀態
	ACCOUNT_AUTH_STATUS: ['已驗證[未驗證]', '已確認[審核中]', '已確認[審核失敗]'],
	ACCOUNT_CHANGE_PWD: '變更登錄密碼',
	ACCOUNT_CHANGE_PAY_PWD: '變更支付密碼',
	ACCOUNT_BANK_CARD: '銀行卡管理',
	ACCOUNT_TRADE_LOG: '餘額變動明細',
	ACCOUNT_AUTH: '實名認證',
	ACCOUNT_ABOUT_US: '關於我們',
	ACCOUNT_CREDIT_SCORE: '信用評分',
	ACCOUNT_NOMINEE: '遺傳繼承',
	ACCOUNT_SERVICE: '客戶服務',

	ACCOUNT_AMOUNT_TOTAL: '總資產',
	ACCOUNT_AMOUNT_AVAILABLE: '可用資金',
	ACCOUNT_MORE_FEATURES: '更多功能',
	ACCOUNT_COLD_AMOUNT: '凍結資金',
	ACCOUNT_REPAY: '回報',
	ACCOUNT_TOTAL_PROFIT: '總獲利',
	CREDIT_SCORE_TITLE: '信用分',

	// 變更登入密碼、變更付款密碼、變更帳號訊息
	TIP_OLD_PWD: '請輸入原密碼',
	TIP_NEW_PWD: '請輸入新密碼',
	TIP_NEW_PWD_VERIFY: '請再輸入新密碼',

	// 個人資訊修改頁面
	AVATAR_TITLE: '更改帳號資訊',
	AVATAR_TIP_NICK_NAME: '請輸入你的暱稱',

	// 個人積分
	CREDIT_SCORE_TITLE: '信用評分',
	CREDIT_SCORE_TIP: '您的信用評分',
	CREDIT_SCORE_BTN_MONEY: '我想藉錢',
	CREDIT_SCORE_BTN_REPAY: '我想還款',
	CREDIT_SCORE_LOAN_MIN_AMOUNT: '貸款最低金額',
	CREDIT_SCORE_LOAN_MAX_AMOUNT: '貸款最高金額',
	CREDIT_SCORE_STATUS: '狀態',
	CREDIT_SCORE_DATETIME: '日期時間',
	CREDIT_SCORE_TIP_ERROR: '抱歉，您的信用評分不足',
	CREDIT_SCORE_MODAL_CONTENT: '您想還款嗎？ ',

	// 貸款
	LOAN_INSTITUTION: '貸款機構',
	TIP_LOAN_NAME: '請選擇貸款機構',
	LOAN_CHOOSE_NAME: '選擇',
	LOAN_AMOUNT: '貸款金額',
	TIP_LOAN_AMOUNT: '請輸入最低貸款金額',

	// 遺傳繼承 nominee
	NOMINEE_TITLE: 'Nominee Details',
	NOMINEE_ADD_ACCOUNT: '新增被提名人',
	NOMINEE_NAME: '被提名人姓名',
	NOMINEE_NAME_TIP: '輸入被提名人姓名',
	NOMINEE_PAN: '永久帳號 (PAN)',
	NOMINEE_PAN_TIP: '輸入永久帳號 (PAN)',
	NOMINEE_UID: 'Aadhaar 號碼 (UID)',
	NOMINEE_UID_TIP: '輸入 Aadhaar 號碼 (1-100)',
	NOMINEE_MOBILE_NO: '手機號碼',
	NOMINEE_MOBILE_NO_TIP: '輸入被提名人手機號碼',
	NOMINEE_EMAIL_ID: '電子郵件 ID',
	NOMINEE_EMAIL_ID_TIP: '輸入被提名人電子郵件 ID',
	NOMINEE_DATE_BIRTH: '出生日期',
	NOMINEE_DATE_BIRTH_TIP: '輸入出生日期',
	NOMINEE_RELATIONSHIP: '與客戶的關係日期',
	NOMINEE_RELATIONSHIP_TIP: '點擊並選擇',
	NOMINEE_UPLOAD_PROOF: '上傳證明',

	// 綁定銀行卡
	REAL_NAME: '開戶人姓名',
	TIP_REAL_NAME: '請輸入姓名',
	BANK_NAME: '開戶銀行名稱',
	TIP_BANK_NAME: '請輸入或選擇開戶行',
	BANK_CARD: '銀行卡號',
	TIP_BANK_CARD: '請輸入銀行卡號碼',
	BTN_CHANGE_BANK_CARD: '帳戶管理',
	BTN_BANK_SELECTED: '選擇銀行',

	// 提款頁面
	WITHDRAW_TITLE: '提款',
	WITHDRAW_AMOUNT: '我的資產',
	WITHDRAW_TITLE: "提取資金",
	TIP_AMOUNT_AVAIL: '可用金額',
	WITHDRAW_WITH_AMOUNT: '提領金額',
	TIP_AMOUNT_WITHDRAW: '輸入提款金額',
	WITHDRAW_PAY_PWD: '提款密碼',
	TIP_WITHDRAW_PWD: '請輸入付款密碼',
	WITHDRAWING_POST_TIP: '處理中....',

	// 提款說明
	WITHDRAW_TIP_TEXT: [`1.在出售目前持有的股票之前無法提取。 `, `2.為了提款，您需要在提款前驗證您的真實姓名並驗證您的帳戶。 `,
		`3.提現交易時間：平日09:00-15:00（週末及公眾假期不可提現）.`, `4.請求提款的最低金額為10,000 韓元.`, `5.申請提款後，原則上當日存入指定提款帳戶. `,
		`※ 付款最多將在 2 個工作天（48 小時）內完成.`
	],

	// 入金頁面
	DEPOSIT_TITLE: '儲值',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: '輸入儲值金額',
	DEPOSIT_TIP_LOW_AMOUNT: '最低1000000',
	DEPOSIT_POST_TIP: '處理中....',
	DEPOSIT_TIP_TITLE: '友情提示',
	DEPOSIT_TIP_TEXT: ['一、儲值時間：平日09:00~18:00，假日休息。 ',
		'感謝您選擇我們。為了確保您的資金安全，請確保您要轉帳的帳戶是我們平台上即時顯示的帳戶，每次從非銀行帳戶轉帳時請與我們的工作人員核實。我們平台上即時顯示的帳戶，您應對因存款而產生的任何損失負責。 '
	],



	// 實名認證頁面
	AUTH_TITLE: '實名認證',
	AUTH_TIP_ID_CARD: '請輸入正確的證件號碼',
	AUTH_TIP_CARD_F: '請上傳證件正面照',
	AUTH_TIP_CARD_B: '請上證件背面照',
	AUTH_ID_CARD: '證件號碼',
	AUTH_CARD_F: '證件正面照',
	AUTH_CARD_B: '證件背面照',
	AUTH_TIP_TEXT: '※ 請完成實名認證，以免部分功能受阻。 ',
	// 認證結果
	AUTH_RESULT_PASS: '認證通過',
	AUTH_RESULT_REVIEW: '等待審核',
	AUTH_RESULT_REPOST: '請求重審',

	// 交易記錄頁面
	TRADE_LOG_TRADE: '資金變動',
	TRADE_LOG_DEPOSIT: '存款記錄',
	TRADE_LOG_WITHDRAW: '取款記錄',
	TRADE_LOG_TIP_MODAL_TITLE: '確定取消提款請求嗎？ ',
	TRADE_LOG_WITHDRAW_STATUS: ['審核中', '提現成功', '提現失敗', '拒絕'],
	LOG_TRADE_AMOUNT_BEFORE: '交易前餘額',
	LOG_TRADE_AMOUNT_AFTER: '交易後餘額',
	LOG_TRADE_DW: '交易額',
	LOG_TRADE_CREATE_TIME: '交易時間',
	LOG_TRADE_DESC: '詳情',
	LOG_TRADE_ORDER_SN: '交易流水號',
	LOG_TRADE_DW_DESC: '交易明細',
	LOG_WITHDRAW_AMOUNT: '提現額',
	LOG_STATUS: '狀態',


	// 交易頁面
	TRADE_TITLE: '投資成果',
	TRADE_HOLD_LOG: '持有記錄',
	TRADE_SELL_LOG: '賣出記錄',
	TRADE_TOTAL_BUY_AMOUNT: '總購買量',
	TRADE_VALUATION_GAIN_LOSS: '持股獲利',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '總收益',
	TRADE_RATE_RESPONSE: '回報率',
	TRADE_TOTAL_GAIN: '利潤總額',

	// 持倉資料明文
	TRADE_HOLD_LABEL_PROFIT_RATE: '盈利率',
	TRADE_HOLD_LABEL_PROFIT_AMOUNT: '獲利額',
	TRADE_HOLD_LABEL_BUY_AMOUNT: '持有量',
	TRADE_HOLD_LABEL_TOTAL_PRICE: '購買總價',
	TRADE_HOLD_LABEL_BUY_PRICE: '買入價',
	TRADE_HOLD_LABEL_CUR_PRICE: '最新價',

	// 賣出資料明文
	TRADE_SELL_LABEL_PROFIT_RATE: '盈利率',
	TRADE_SELL_LABEL_PROFIT_AMOUNT: '獲利額',
	TRADE_SELL_LABEL_BUY_AMOUNT: '持有量',
	TRADE_SELL_LABEL_TOTAL_PRICE: '購買總價',
	TRADE_SELL_LABEL_BUY_PRICE: '買入價',
	TRADE_SELL_LABEL_SELL_PRICE: '賣出價',

	// 持倉與銷售彈層資料明文
	TRADE_MODAL_BUY_TIME: '購買時間',
	TRADE_MODAL_SELL_TIME: '銷售時間',
	TRADE_MODAL_FLOAT_PROFIT: '浮動盈虧',
	TRADE_MODAL_PROFIT: '盈虧',
	TRADE_MODAL_BUY_PRICE: '買入單價',
	TRADE_MODAL_BUY_QTY: '買入數量',
	TRADE_MODAL_LEVER: '槓桿',
	TRADE_MODAL_FEE: '手續費',
	TRADE_MODAL_BUY_AMOUNT: '總額',
	TRADE_MODAL_STOCK_CODE: '股票代號',

	// 賣出的二次確認
	SELL_TIP: '確認賣出嗎？',

	// AI交易
	TRADE_AI_TITLE: 'AI 交易',
	TRADE_AI_TAB_APPLY: '申請',
	TRADE_AI_TAB_HOLD: '持有',
	TRADE_AI_AMOUNT: 'AI 資產',
	TRADE_AI_AMOUNT_TOTAL: 'AI 總資產',
	TRADE_AI_PROFIT: 'AI 收益',
	TRADE_AI_TRANSFER: ['轉入', '轉出'],
	TRADE_AI_LOG: ['申請中', '透過', '駁回'],
	TRADE_AI_CYCLE_TITLE: '選擇一個週期',
	TRADE_AI_TRADE_VOL: '交易額',
	TRADE_AI_BALANCE: '餘額',
	TRADE_AI_TYPE: '交易類型',
	TRADE_AI_CYCLE_DAY: '週期',
	TRADE_AI_DEPOSIT_BTN: '訂金',
	TRADE_AI_ORDER_TABS: ['持有', '銷售'],
	// 持倉資料明文
	TRADE_AI_HOLD_LABEL_1ST: '盈虧',
	TRADE_AI_HOLD_LABEL_2ND: '利潤率',
	TRADE_AI_HOLD_LABEL_3RD: '買入數量',
	TRADE_AI_HOLD_LABEL_4TH: '金額',
	TRADE_AI_HOLD_LABEL_5TH: '平均單價',
	// 賣出資料明文
	TRADE_AI_SELL_LABEL_1ST: '盈虧',
	TRADE_AI_SELL_LABEL_2ND: '利潤率',
	TRADE_AI_SELL_LABEL_3RD: '買入數量',
	TRADE_AI_SELL_LABEL_4TH: '金額',
	TRADE_AI_SELL_LABEL_5TH: '平均單價',
	TRADE_AI_SELL_LABEL_6TH: '賣出價格',

	// 日內交易
	TRADE_DAY_TITLE: '日內交易',
	TRADE_DAY_TABS: ['申請', '申請狀態', '核准詳情'],
	TRADE_DAY_BUY: '申請',
	TRADE_DAY_TIP: '提示',
	TRADE_DAY_TIP_TEXT: ['是指短期快速上漲股票的投資者當日買賣股票，並根據利潤結算交易的一種交易手法。 ',
		'投資者統一交易、結算股票價格。 ', '如果買入後出現盈利，立即顯示在“盤中交易股票”中，您可以選擇賣出獲利。 ', '為了保護短期利潤和保密，購買期間不提供股票代碼和詳細資訊。 '
	],
	TRADE_DAY_BUY_AMOUNT: '申請金額',
	TRADE_DAY_SUCCESS_AMOUNT: '核准金額',
	TRADE_DAY_BUY_PRICE: '買入金額',
	TRADE_DAY_ORDER_SN: '訂單編號',
	TRADE_DAY_CREATE_TIME: '申請時間',
	TRADE_DAY_ORDER_STATUS: '狀態',
	TRADE_DAY_MODAL_CONTENT: '確定提交訂單嗎？ ',
	TRADE_DAY_TIP_INPUT_AMOUNT: '請輸入金額',

	// 折價交易
	TRADE_DISCOUNT_TITLE: '折價交易',
	TRADE_DISCOUNT_TABS: ['產品清單', '交易記錄'],
	TRADE_DISCOUNT_PRICE: '價格',
	TRADE_DISCOUNT_RATE: '漲幅率',
	TEADE_DISCOUNT_RATE_AMOUNT: '漲跌幅額',
	TRADE_DISCOUNT_MIN_QTY: '最少購買量',
	TRADE_DISCOUNT_MAX_QTY: '最大購買量',
	TRADE_DISCOUNT_MIN_DAY: '最低持倉天數',
	TRADE_DISCOUNT_ITEM_LABELS: ['價格', '漲幅率'],
	TRADE_DISCOUNT_ORDER_TITLE: '認購申請單',
	TRADE_DISCOUNT_BUY_AMOUNT: '購買價格',
	TRADE_DISCOUNT_TIP_BUY_COUNT: '請輸入購買數量',
	TRADE_DISCOUNT_ORDER_AMOUNT: '購買數量',
	TRADE_DISCOUNT_TIP_BUY_PWD: '請輸入付款密碼',
	TRADE_DISCOUNT_LOG_FINISH: '購買完成',
	TRADE_DISCOUNT_LOG_PRICE: '購買價格',
	TRADE_DISCOUNT_LOG_NUM: '購買數量',
	TRADE_DISCOUNT_LOG_AMOUNT: '購買總價',
	TRADE_DISCOUNT_LOG_LEVER: '槓桿',
	TRADE_DISCOUNT_LOG_CREATE_TIME: '購買時間',
	TRADE_DISCOUNT_BUY_TOTAL_AMOUNT: '購買總價',


	// EA交易
	TRADE_EA_TITLE: 'EA 交易',
	TRADE_EA_TABS: ['說明', '市場', '交易記錄'],
	// 是否賣出
	TRADE_EA_MODAL_CONTENT: '你確定賣出嗎?',
	// 買入彈層
	TRADE_EA_HIGHEST_RETURN: '最高回報',
	TRADE_EA_BUY_AMOUNT: '請輸入購買數量',
	TRADE_EA_CYCLE_TIP: '請選擇週期',
	// order列表
	TRADE_EA_ORDER_AMOUNT: '購買數量',
	TRADE_EA_ORDER_PERIOD: '收益率',
	TRADE_EA_ORDER_CYCLE: '週期',
	TRADE_EA_ORDER_DATE: '開始日期',
	TRADE_EA_ORDER_END_DATE: '結束日期',
	TRADE_EA_ORDER_SN: '流水號',
	TRADE_EA_ORDER_LEVER: '槓桿',
	TRADE_EA_ORDER_RATE: '回報率',


	// 股權 交易
	TRADE_EQUITY_TITLE: '股權 交易',
	TRADE_EQUITY_SURPLUS: '餘量',
	TRADE_EQUITY_PRICE: '申請價格',
	TRADE_EQUITY_QTY: '申請數量',
	TRADE_EQUITY_TOTAL: '申請總額',
	TRADE_EQUITY_SUCCESS_QTY: '通過數量',
	TRADE_EQUITY_SUCCESS_TOTAL: '通過總額',
	TRADE_EQUITY_SUB_AMOUNT: '已認繳金額',
	TRADE_EQUITY_DEF_AMOUNT: '補繳金額',
	TRADE_EQUITY_DEF_BTN: '補繳',
	TRADE_EQUITY_DEF_AMOUNT_TIP: '請輸入補繳金額',
	TRADE_EQUITY_DEF_BTN_ALL: '全部',

	// IPO 交易
	TRADE_IPO_TITLE: 'IPO',
	TRADE_IPO_TABS: ['產品申購', '申購記錄', '申購成功'],
	TRADE_IPO_MODAL_TITLE: '公開發行股票認購申請',
	TRADE_IPO_MODAL_CONTENT: '如果您想申請訂閱，請點選 確認',
	TADE_IPO_SUB_PRICE: '認購金額',
	TRADE_IPO_PE_RATE: '本益比',
	TRADE_IPO_SUB_CT: '訂閱時間',
	TRADE_IPO_POST_QTY: '發行量',
	TRADE_IPO_RAISE_MONEY: '募集資金',
	TRADE_IPO_LOG_LABELS: ['認購價', '本益比', '訂閱時間', '순환'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 申購成功記錄',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '申購數量',
	TRADE_IPO_SUCCESS_AMOUNT: '中籤數量',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '申購金額',
	TRADE_IPO_SUCCESS_ORDER_SN: '訂單編號',
	TRADE_IPO_SUCCESS_CT: '日期時間',
	TRADE_IPO_SUB: '訂閱',
	TRADE_IPO_PUBLIC_PRICE: '公開發行價',


	// 新股配售
	TRADE_ISSUANCE_TITLE: '新股配售',
	TRADE_ISSUANCE_TABS: ['產品清單', '交易記錄'],
	TRADE_ISSUANCE_MODAL_0: 'Price',
	TRADE_ISSUANCE_MODAL_1: '配售價格',
	TRADE_ISSUANCE_MODAL_2: '發行量',
	TRADE_ISSUANCE_MODAL_3: '申購日期',
	TRADE_ISSUANCE_MODAL_4: 'Announcement Date',
	TRADE_ISSUANCE_MODAL_5: 'Expiration Date',
	TRADE_ISSUANCE_MODAL_6: '發行日期',
	TRADE_ISSUANCE_MODAL_NULL_DATE: '暫未發行',
	TRADE_ISSUANCE_LOG_PRICE: '價格',
	TRADE_ISSUANCE_LOG_SUCCESS: '申購成功量',
	TRADE_ISSUANCE_LOG_AMOUNT: '申購金額',
	TRADE_ISSUANCE_LOG_DATE: '申購日期',
	TRADE_ISSUANCE_LOG_SN: '流水號',


	// 大宗交易
	TRADE_LARGE_TITLE: '大宗交易',
	TRADE_LARGE_TABS: ['產品清單', '交易記錄'],
	TRADE_LARGE_PRICE: '價格',
	TRADE_LARGE_RATE: '漲幅',
	TRADE_LARGE_RATE_AMOUNT: '漲額',
	TRADE_LARGE_MIN_QTY: '最少購買量',
	TRADE_LARGE_MAX_QTY: '最大購買量',
	TRADE_LARGE_MIN_DAY: '最低持倉天數',
	TRADE_LARGE_ITEM_LABELS: ['價格', '漲幅率'],
	TRADE_LARGE_ORDER_TITLE: '認購申請單',
	TRADE_LARGE_BUY_AMOUNT: '購買價格',
	TRADE_LARGE_TIP_BUY_COUNT: '請輸入購買數量',
	TRADE_LARGE_ORDER_AMOUNT: '購買數量',
	TRADE_LARGE_TIP_BUY_PWD: '請輸入付款密碼',
	TRADE_LARGE_LOG_FINISH: '購買完成',
	TRADE_LARGE_LOG_PRICE: '購買價格',
	TRADE_LARGE_LOG_NUM: '購買數量',
	TRADE_LARGE_LOG_AMOUNT: '購買總價',
	TRADE_LARGE_LOG_LEVER: '槓桿',
	TRADE_LARGE_LOG_CREATE_TIME: '購買時間',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '購買總價',


	// 短打交易
	TRADE_SHORT_TITLE: '短打交易',
	TRADE_SHORT_TABS: ['產品清單', '交易記錄'],
	TRADE_SHORT_PRICE: '價格',
	TRADE_SHORT_RATE: '漲幅率',
	TRADE_LARGE_RATE_AMOUNT: '漲額',
	TRADE_SHORT_MIN_QTY: '最少購買量',
	TRADE_SHORT_MAX_QTY: '最大購買量',
	TRADE_SHORT_MIN_DAY: '最低持倉天數',
	TRADE_SHORT_ITEM_LABELS: ['價格', '漲幅率'],
	TRADE_SHORT_ORDER_TITLE: '認購申請單',
	TRADE_SHORT_BUY_AMOUNT: '購買價格',
	TRADE_SHORT_TIP_BUY_COUNT: '請輸入購買數量',
	TRADE_SHORT_ORDER_AMOUNT: '購買數量',
	TRADE_SHORT_TIP_BUY_PWD: '請輸入付款密碼',
	TRADE_SHORT_LOG_FINISH: '購買完成',
	TRADE_SHORT_LOG_PRICE: '購買價格',
	TRADE_SHORT_LOG_NUM: '購買數量',
	TRADE_SHORT_LOG_AMOUNT: '購買總價',
	TRADE_SHORT_LOG_LEVER: '槓桿',
	TRADE_SHORT_LOG_CREATE_TIME: '購買時間',
	TRADE_SHORT_BUY_TOTAL_AMOUNT: '購買總價',


	// VIP 交易
	TRADE_VIP_TITLE: 'VIP',
	TRADE_VIP_TABS: ['產品清單', '交易記錄'],



	// 單股詳情頁面
	STOCK_OVERVIEW_TITLE: '股票詳情',
	// 股票最新數值
	STOCK_INFO_TITLES: ['市價', '前日收盤價', '高價', '低價', '交易量', '交易額'],
	// 股票詳情 一級TABS
	STOCK_OVERVIEW_TABS: ['最新', '概況', '新聞'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['分', '日', '週', '月'],
	// 單股購買頁面
	STOCK_BUY_QUANTITY: '數量',
	STOCK_BUY_TIP_QUANTITY: '請輸入數量',
	STOCK_BUY_AMOUNT: '付款金額',
	STOCK_BUY_FEE: '手續費',
	STOCK_BUY_CONFIRM: '確認購買',
	// 單股概覽 概覽資訊
	STOCK_BASE_INFO: ['公司排名', '平均價格', '股份數', '外國人比例', '行業', '詳細行業', '52週新高', '52週新低'],
	STOCK_KOSDAQ: '科斯達克', // '科斯達克',
	// 概覽
	STOCK_COMPANY: '公司簡介',
	STOCK_SALES: '銷售',
	STOCK_SALES_TABS: ['季度銷售', '年度銷售'],
	// 銷售額三塊數據
	STOCK_SALES_LAST_SALES_AMOUNT: '最近銷售',
	STOCK_SALES_LAST_SALES_PROFIT: '最近營利',
	STOCK_SALES_LAST_SALES_INCOME: '最近淨利',

	// 銷售額折線上方的三個選項
	STOCK_SALES_KLINE_TABS: ['銷售額', '營業利潤', '淨利'],
	// 投資者交易趨勢
	STOCK_TRADE_TREND_TITLE: '投資者交易趨勢',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['淨購買數量', '累積淨買入量'],
	STOCK_TRADE_TREND_INFO_TITLE: ['個人', '機構', '國外'],
	STOCK_TRADE_TREND_RECENT_TITLE: '最近的交易趨勢',
	STOCK_TRADE_TREND_RECENT_LABELS: ['參考日期', '個人', '機構', '國外'],
	// 圓餅圖的title
	STOCK_TRADE_TREND_PIE_TITLE: '交易趨勢',
	STOCK_TRADE_SELL_EMPTY_TITLE: '賣空量',
	// 賣空量兩組資料的Title
	STOCK_TRADE_SELL_EMPTY_TITLE_BALANCE: '賣空餘額',
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_1ST: '與總交易量相比',
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_2ND: '相對於市值',

	// 產業內比較
	STOCK_INDUSTRY_TITLE: '產業內比較',
	STOCK_INDUSTRY_DESC: '汽車零件',
	STOCK_INDUSTRY_DESC_SUFFIX: '之中',
	STOCK_INDUSTRY_DATA_TITLES: ['目前', '產業平均'],
	STOCK_INDUSTRY_DATA_LABELS: ['評價金額', '淨利潤成長率', '資產負債比率', 'PER', 'PBR', 'ROE'],


	// 市集頁面
	MARKET_TABS: ['概況', '熱股', '指標', '新聞'],
	// 市場概況
	MARKET_OVERVIEW_SELF_TITLE: '國內項目',
	//國內、國外、虛擬貨幣
	MARKET_OVERVIEW_SELF_TABS: ["國內", "國外", "虛擬貨幣"],
	MARKET_MORE_HOT_TITLE: '看更多熱門商品',
	MARKET_NEWS_TITLE: '市場新聞',
	MARKET_OVERVIEW_THEAD: ["上漲幅度", "下跌幅度", "申報價格", "交易量", '交易金額'],
	// 熱門股票
	MARKET_HOT_TABS: ['上升率', '下降率', '報告價格', '交易量', '交易金額', '외국인순매수', '機構淨買入', '新上市', '賣空比例'],
	// 熱門股票過濾
	MARKET_HOT_FILTER: ['天', '1週', '1月', '3月', '6月'],
	MARKET_HOT_THEAD: ['名稱', '時價', '波動率', '當前指數'],
	// 市場指標
	MARKET_INDEX_TABS: ['指數', '匯率', '原料', '虛擬貨幣'],
	MARKET_NEWS_TABS: ['新聞', '市場', '經濟', '產業', '債券', '理財', '公司', '投資'],
	MARKET_NEWS_TIP: '僅提供前 100 名的資料. ',



	// 首頁中簽彈圖層
	DIALOG_IPO_SUCCESS_TIP_TITLE: '恭喜您',
	DIALOG_IPO_SUCCESS_TIP_TEXT: '您贏得了公開發售認購.',
	DIALOG_IPO_SUCCESS_LABEL_QTY: '數量',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: '總金額',

	LEVER: '槓桿',
	STOCK_ALL: '股票列表',
	STOCK_FOLLOW: '關注列表',
	PAGE_TITLE_NOTIFICATION: '通知',

	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '亿',
	UNIT_POS: '名',
	UNIT_DAY: '天',
	MORE: '更多',
	BRIEF: '简要',
	EMPTY_NOTIFIY: '暂无消息',
	EMPTY_DATA: '暂无数据',
	BTN_CONFIRM: '确认',
	BTN_CANCEL: '取消',
	BTN_SEND_SERVICE: '联系客服',
	BTN_SERVICE: '客服',
	BTN_DETAIL: '详情',
	BTN_BUY: '购买',
	BTN_SELL: '卖出',
	BTN_DETAIL_NOW: '现在查看',
	STATUS_LOADING: "加载中",
	STATUS_SUBMIT: '数据提交中',
	STATUS_GET_NEW_DATA: '获取新数据',
	STATUS_UPLOAD: "上传中",

	// Loading 相关

	LOADING_GET_NEW_DATA: '获取新数据',

}