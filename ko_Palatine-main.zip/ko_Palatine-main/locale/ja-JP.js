// 底部导航组
const TABBAR = {
	TABBAR_HOME: "ホームページ",
	TABBAR_FOLLOW: "焦点",
	TABBAR_MARKET: '市場',
	TABBAR_TRADE: '貿易',
	TABBAR_ACCOUNT: '私の',
};

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "ログイン",
	SIGN_UP: "会員になる",
	SIMGN_OUT: "サインアウト",
	GO_TO_SIGN_IN: 'ログインに移動',
	USER_NAME: 'アカウント',
	ENTER_USER_NAME: 'アカウントを入力してください',
	PASSWORD: 'パスワード',
	ENTER_PASSWORD: 'パスワードを入力してください',
	VERIFY_PASSWORD: 'パスワードを照合します',
	ENTER_VERIFY_PASSWORD: 'パスワードをもう一度入力してください',
	INVITATION_CODE: '招待コード',
	ENTER_INVITATION_CODE: '招待コードを入力してください',
	TIP_PWD_NOEQUAL: '2回入力したパスワードは一致しません',
	TIP_SUCCESS_SIGNIN: '正常にサインインします',
	TIP_SUCCESS_REGISTER: '登録が完了しましたのでログインしてください',
	TIP_SIGNIN_ING: 'ログインする',
	TIP_SIGNUP_ING: '登録する',
	TIP_REMEMBER_PWD: 'パスワードを覚える',
	API_TOKEN_EXPIRES: 'ログインステータスの有効期限が切れています。再度ログインしてください',
	TIP_SIGN_OUT_SUCCESS: 'ログアウト成功',
	TIP_AGREE: '読んで同意します',
	TIP_PRVITE_PACT: 'ユーザープライバシー同意書',
	TIP_CHECK_AGREE: 'ユーザープライバシー規約に同意するボックスにチェックを入れてください',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
	TIP_OLD_PWD: '元のパスワードを入力してください',
	TIP_NEW_PWD: '新しいパスワードを入力してください',
	TIP_NEW_PWD_VERIFY: '新しいパスワードをもう一度入力してください',
	// 个人信息修改页面
	PAGE_TITLE_AVATAR: 'アカウント情報の変更',
	AVATAR_TIP_NICK_NAME: 'ニックネームを入力してください',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: '口座名義人名',
	TIP_REAL_NAME: 'あなたの名前を入力してください',
	BANK_NAME: '口座を開設した銀行名',
	TIP_BANK_NAME: '口座開設銀行を入力または選択してください',
	BANK_CARD: '銀行カード番号',
	TIP_BANK_CARD: '銀行カード番号を入力してください',
	BTN_CHANGE_BANK_CARD: 'アカウント管理',
	BTN_BANK_SELECTED: '銀行を選択してください',

};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: 'お金を引き出す',
	WITHDRAW_AMOUNT: '私の資産',
	WITHDRAW_TITLE: "資金を引き出す",
	TIP_AMOUNT_AVAIL: '利用可能量',
	WITHDRAW_WITH_AMOUNT: '金額を撤回',
	TIP_AMOUNT_WITHDRAW: '出金額を入力してください',
	WITHDRAW_PAY_PWD: '出金パスワード',
	TIP_WITHDRAW_PWD: '支払いパスワードを入力してください',
	WITHDRAWING_POST_TIP: '処理....',

	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. 現在保有している株式が売却されるまで出金することはできません。`, `2. お金を引き出すには、お金を引き出す前に本名を確認し、アカウントを確認する必要があります。`,
		`3. 出金取引時間：平日9:00～15:00（土日祝日は出金不可）。`, `4. 出金申請の最低金額は10,000ウォンです。 5. 出金申請後、原則として同日中に指定の出金口座に入金されます。 `,
		`※ 支払いは最大 2 営業日 (48 時間) 以内に処理されます.`
	],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '補充する',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: 'リチャージ金額を入力してください',
	DEPOSIT_TIP_LOW_AMOUNT: '最低1000000',
	DEPOSIT_POST_TIP: '処理....',
	DEPOSIT_TIP_TITLE: 'フレンドリーなリマインダー',
	DEPOSIT_TIP_TEXT: ['一、充電時間：平日9:00～18:00、祝日は休業。',
		'私達を選んで頂き有難うございます。資金の安全を確保するため、送金先の口座が当社のプラットフォームにリアルタイムで表示されている口座であることを確認し、銀行以外の口座から資金を送金する場合は毎回当社のスタッフに確認してください。アカウントは当社のプラットフォーム上にライブで表示され、入金の結果生じた損失についてはお客様の責任となります。'
	],
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['確認済み[未確認]', '確認済み[検討中]', '確認済み[監査失敗]'],
	ACCOUNT_CHANGE_PWD: 'ログインパスワードを変更する',
	ACCOUNT_CHANGE_PAY_PWD: '支払いパスワードを変更する',
	ACCOUNT_CARD_MANAGEMENT: '銀行カードの管理',
	ACCOUNT_TRADE_LOG: 'バランス変更詳細',
	ACCOUNT_SERVICE: '顧客サービス',
	ACCOUNT_AMOUNT_TOTAL: '総資産',
	ACCOUNT_AMOUNT_AVAILABLE: '利用可能な資金',
	ACCOUNT_MORE_FEATURES: 'その他の機能',
	ACCOUNT_COLD_AMOUNT: '資金を凍結する',
	ACCOUNT_REPAY: '戻る',
	ACCOUNT_TOTAL_PROFIT: '利益総額'
}

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: '実名認証',
	AUTH_TIP_ID_CARD: '正しいID番号を入力してください',
	AUTH_TIP_CARD_F: '身分証明書の正面写真をアップロードしてください',
	AUTH_TIP_CARD_B: '身分証明書の裏面の写真をアップロードしてください',
	AUTH_ID_CARD: '証明書番号',
	AUTH_CARD_F: '身分証明書の表面写真',
	AUTH_CARD_B: '身分証明書の裏面の写真',
	AUTH_TIP_TEXT: '※一部の機能がブロックされることを避けるため、実名認証を完了してください。 ',
	// 认证结果
	AUTH_RESULT_PASS:'認証に合格しました',
	AUTH_RESULT_REVIEW:'検討中',
	AUTH_RESULT_REPOST:'再提出',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_TRADE: '入出金',
	TRADE_LOG_DEPOSIT: '入金',
	TRADE_LOG_WITHDRAW: '出金',
	TRADE_LOG_TIP_MODAL_TITLE: '出金リクエストをキャンセルしてもよろしいですか? ',
	TRADE_LOG_WITHDRAW_STATUS: ['審査中',
		'出金成功',
		'出金失敗',
		'拒否されました'
	],
	LOG_TRADE_AMOUNT_BEFORE: '取引前の残高',
	LOG_TRADE_AMOUNT_AFTER: '取引後の残高',
	LOG_TRADE_DW: '取引金額',
	LOG_TRADE_CREATE_TIME: '取引時間',
	LOG_TRADE_DESC: '詳細',
	LOG_TRADE_ORDER_SN: '取引シリアル番号',
	LOG_TRADE_DW_DESC: '取引の詳細',
	LOG_WITHDRAW_AMOUNT: '出金金額',
	LOG_STATUS: 'ステータス',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TITLE: '投資結果',
	TRADE_HOLD_LOG: '記録を保持',
	TRADE_SELL_LOG: '記録を売却',
	TRADE_TOTAL_BUY_AMOUNT: '購入総額',
	TRADE_VALUATION_GAIN_LOSS: 'ポジション利益',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '合計利益',
	TRADE_RATE_RESPONSE: '返品率',
	TRADE_TOTAL_GAIN: '総利益',
	// 持仓数据明文
	TRADE_HOLD_LABEL_1ST: '案件名',
	TRADE_HOLD_LABEL_2ND: '評価損益',
	TRADE_HOLD_LABEL_3RD: '保有数量',
	TRADE_HOLD_LABEL_4TH: '盈亏',
	TRADE_HOLD_LABEL_5TH: '仕入価格',
	TRADE_HOLD_LABEL_6TH: '現在価格',
	TRADE_HOLD_LABEL_7TH: '最新の価格',
	// 卖出数据明文
	TRADE_SELL_LABEL_1ST: '案件名',
	TRADE_SELL_LABEL_2ND: '評価損益',
	TRADE_SELL_LABEL_3RD: '保有数量',
	TRADE_SELL_LABEL_4TH: '盈亏',
	TRADE_SELL_LABEL_5TH: '仕入価格',
	TRADE_SELL_LABEL_6TH: '現在価格',
	TRADE_SELL_LABEL_7TH: '最新の価格',
	
	// 持仓与销售弹层数据明文
	TRADE_MODAL_BUY_TIME:'購入時期',
	TRADE_MODAL_SELL_TIME:'販売時期',
	TRADE_MODAL_FLOAT_PROFIT:'経常損益',
	TRADE_MODAL_PROFIT:'総損益',
	TRADE_MODAL_BUY_PRICE:'購入価格',
	TRADE_MODAL_BUY_QTY:'数量',
	TRADE_MODAL_LEVER:'レバレッジ',
	TRADE_MODAL_FEE:'手数料',
	TRADE_MODAL_BUY_AMOUNT:'合計購入金額',
	TRADE_MODAL_STOCK_CODE:'コード',

	SELL_TIP: '販売を確認しますか? ',

};

// 日内交易
const TRADE_DAY = {
	TRADE_DAY_TITLE: '日中取引',
	TRADE_DAY_TABS: ['日中取引', '申請状況', '承認内容'],
	TRADE_DAY_BUY: '適用',
	TRADE_DAY_TIP: 'チップ',
	TRADE_DAY_TIP_TEXT: ['股票采用人工智能构建的量化系统进行当天交易，当收盘时，所有持有的股票将被清算，并根据利润进行结算。',
		'AIデイトレードをお申込みいただいたお客様は、AIシグナルに基づいて自動的に売買を行い、保有する株式を直接売却することができます。',
		'人工知能による自動取引では、業務上の機密性を保つために取引関連情報の一部が保護・管理されます。'
	],
	TRADE_DAY_BUY_AMOUNT: '申請金額',
	TRADE_DAY_SUCCESS_AMOUNT: '承認された金額',
	TRADE_DAY_BUY_PRICE: '購入金額',
	TRADE_DAY_ORDER_SN: '注文番号',
	TRADE_DAY_CREATE_TIME: '申請時間',
	TRADE_DAY_ORDER_STATUS: 'ステータス',
	TRADE_DAY_MODAL_CONTENT: '注文を送信してもよろしいですか? ',
	TRADE_DAY_TIP_INPUT_AMOUNT: '金額を入力してください',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '大規模な取引',
	TRADE_LARGE_TABS: ['商品リスト', '取引記録'],
	TRADE_LARGE_TAB1_TITLES: ['', ''],
	TRADE_LARGE_PRICE: '価格',
	TRADE_LARGE_RATE: '増加率',
	TEADE_LARGE_RATE_AMOUNT: '増加額',
	TRADE_LARGE_MIN_QTY: '最低購入数量',
	TRADE_LARGE_MAX_QTY: '最大購入数量',
	TRADE_LARGE_MIN_DAY: '最小保有日数',
	TRADE_LARGE_ITEM_LABELS: ['価格', '増加率'],
	TRADE_LARGE_ORDER_TITLE: '定期購入申し込み注文',
	TRADE_LARGE_BUY_AMOUNT: '購入価格',
	TRADE_LARGE_TIP_BUY_COUNT: '購入数量を入力してください',
	TRADE_LARGE_ORDER_AMOUNT: '購入数量',
	TRADE_LARGE_TIP_BUY_PWD: '支払いパスワードを入力してください',
	TRADE_LARGE_LOG_FINISH: '購入が完了しました',
	TRADE_LARGE_LOG_PRICE: '購入価格',
	TRADE_LARGE_LOG_NUM: '購入数量',
	TRADE_LARGE_LOG_AMOUNT: '合計購入価格',
	TRADE_LARGE_LOG_LEVER: 'レバレッジ',
	TRADE_LARGE_LOG_CREATE_TIME: '購入時間',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '合計購入価格',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['製品', 'レコード', '成功'],
	TRADE_IPO_MODAL_TITLE: '公募株式引受申込み',
	TRADE_IPO_MODAL_CONTENT: 'に申し込みたい場合は[確認] をクリックしてください',
	TADE_IPO_SUB_PRICE: '定期購入額',
	TRADE_IPO_PE_RATE: 'PER',
	TRADE_IPO_SUB_CT: '購読時間',
	TRADE_IPO_POST_QTY: '発行',
	TRADE_IPO_RAISE_MONEY: '資金調達',
	TRADE_IPO_LOG_LABELS: ['定期購入価格', 'PER', '定期購入時間', '순환'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 申し込み成功記録',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '数量',
	TRADE_IPO_SUCCESS_AMOUNT: '当選チケットの枚数',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '金額',
	TRADE_IPO_SUCCESS_ORDER_SN: '注文番号',
	TRADE_IPO_SUCCESS_CT: '日付時刻',
};

// 股权 交易
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: '株式取引',
	TRADE_EQUITY_SURPLUS: '余剰',
	TRADE_EQUITY_PRICE: '申請価格',
	TRADE_EQUITY_QTY: '申請数量',
	TRADE_EQUITY_TOTAL: '申請総額',
	TRADE_EQUITY_SUCCESS_QTY: '合格した数量',
	TRADE_EQUITY_SUCCESS_TOTAL: '渡された合計金額',
	TRADE_EQUITY_SUB_AMOUNT: '購読金額',
	TRADE_EQUITY_DEF_AMOUNT: '追加支払い額',
	TRADE_EQUITY_DEF_BTN: 'バックペイメント',
	TRADE_EQUITY_DEF_AMOUNT_TIP: '追加の支払い金額を入力してください',
	TRADE_EQUITY_DEF_BTN_ALL: 'すべて',
};

// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '在庫詳細',
	STOCK_INFO_TITLES: ['市場価格', '前日終値', '高値', '安値', '取引量', '取引金額'],
	STOCK_OVERVIEW_TABS: ['最新', '概要', 'ニュース'],
	STOCK_OVERVIEW_KLINE_TABS: ['分', '日', '週', '月'],
	STOCK_BUY_QUANTITY: '数量',
	STOCK_BUY_TIP_QUANTITY: '数量を入力してください',
	STOCK_BUY_AMOUNT: '支払い金額',
	STOCK_BUY_FEE: '手数料',
	STOCK_BUY_CONFIRM: '購入を確認',
	STOCK_BASE_INFO: ['企業', '平均株価', '株数', '外国人比例', '外国人比率', '详细行业', '52週高値', '52週安値'],
	STOCK_KOSDAQ: 'コスダック', // '科斯达克',
	STOCK_COMPANY: '会社概要',
	STOCK_SALES: '売上',
	STOCK_SALES_TABS: ['四半期売上高', '年間売上高'],
	STOCK_SALES_LAST_SALES_AMOUNT: '最新の売上高',
	STOCK_SALES_LAST_SALES_PROFIT: '最新の利益',
	STOCK_SALES_LAST_SALES_INCOME: '最新の純利益',
	STOCK_SALES_KLINE_TABS: ['売上高', '営業利益', '純利益'],
	STOCK_TRADE_TREND_TITLE: '投資家の取引傾向',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['純購入数量', '累積純購入数量'],
	STOCK_TRADE_TREND_INFO_TITLE: ['個人', '機関', '海外'],
	STOCK_TRADE_TREND_RECENT_TITLE: '最近の取引傾向',
	STOCK_TRADE_TREND_RECENT_LABELS: ['基準日', '個人', '機関', '外国'],
	STOCK_TRADE_TREND_PIE_TITLE: '取引トレンド',
	STOCK_TRADE_SELL_EMPTY_TITLE: '空売り数量',
	STOCK_TRADE_SELL_EMPTY_TITLE_BALANCE: '空売り残高',
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_1ST: '総取引高と比較',
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_2ND: '時価総額と比較',
	STOCK_INDUSTRY_TITLE: '業界内の比較',
	STOCK_INDUSTRY_DESC: '自動車部品',
	STOCK_INDUSTRY_DESC_SUFFIX: '間',
	STOCK_INDUSTRY_DATA_TITLES: ['現在', '業界平均'],
	STOCK_INDUSTRY_DATA_LABELS: ['評価額', '純利益成長率', '資産負債比率', 'PER', 'PBR', 'ROE'],
};

// 市场页面
const MARKET = {
	MARKET_TABS: ['概要', '注目株', '指標', 'ニュース'],
	MARKET_OVERVIEW_SELF_TITLE: '国内プロジェクト',
	MARKET_OVERVIEW_SELF_TABS: ["国内", "海外", "仮想通貨"],
	MARKET_MORE_HOT_TITLE: '人気のアイテムをもっと見る',
	MARKET_NEWS_TITLE: 'マーケット ニュース',
	MARKET_OVERVIEW_THEAD: ["金額の増加", "金額の減少", "レポート価格", "取引量", '取引金額'],
	MARKET_HOT_TABS: ['上昇率', '下落率', '報道価格', '出来高', '出来高', '외국인순매수', '機関投資家買い越し', '新規上場', '空売り比率'],
	MARKET_HOT_FILTER: ['日', '1週間', '1月', '3月', '6月'],
	MARKET_HOT_THEAD: ['名前', '現在の価格', 'ボラティリティ', '現在のインデックス'],
	MARKET_INDEX_TABS: ['指数', '為替レート', '原材料', '仮想通貨'],
	MARKET_NEWS_TABS: ['ニュース', '市場', '経済', '産業', '債券', '財務管理', '会社', '投資'],
	MARKET_NEWS_TIP: '上位 100 件のデータのみが提供されます ',
};

// 首页中签弹层
const DIALOG_IPO_SUCCESS = {
	DIALOG_IPO_SUCCESS_TIP_TITLE: 'おめでとうございます',
	DIALOG_IPO_SUCCESS_TIP_TEXT: '公募のサブスクリプションを獲得しました。',
	DIALOG_IPO_SUCCESS_LABEL_QTY: '数量',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: '合計金額',
}

export default {
	TRANSLATE_TITLE: '言語を選択してください',
	LAUNCH_TITLE: '株式オンライン取引プラットフォーム',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EQUITY,
	...STOCK_INFO,
	...MARKET,
	...DIALOG_IPO_SUCCESS,
	LEVER: 'てこ',
	STOCK_ALL: '在庫リスト',
	STOCK_FOLLOW: 'ウォッチリスト',
	STOCK_THEAD: ['名前', '最新価格', '上昇率'],
	PAGE_TITLE_NOTIFICATION: '通知',
	PAGE_TITLE_SEARCH: '検索',
	TIP_SEARCH: '銘柄名または銘柄コードを入力してください',
	SEARCH_HISTORY: 'レコードの検索',
	SEARCH_CLEAR: 'レコードをクリア',
	PAGE_TITLE_TRADE_DISCOUNT: '割引取引',
	TIP_POST_SUCCESS: '送信成功',
	ABOUT_US: '当社について',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '億',
	UNIT_POS: '名',
	UNIT_DAY: '日',
	MORE: 'もっと',
	BRIEF: '簡潔',
	EMPTY_NOTIFIY: 'まだニュースはありません',
	EMPTY_DATA: 'まだデータがありません',
	BTN_CONFIRM: '確認',
	BTN_CANCEL: 'キャンセル',
	BTN_SEND_SERVICE: 'カスタマーサービスに連絡してください',
	BTN_SERVICE: '顧客サービス',
	BTN_DETAIL: '詳細',
	BTN_BUY: '購入',
	BTN_SELL: '販売',
	BTN_DETAIL_NOW: '今すぐ表示',
	STATUS_LOADING: "読み込み中",
	STATUS_SUBMIT: '送信中',
	STATUS_REQUEST: '新しいデータを取得',
	STATUS_HTTP_ERROR: 'リクエスト例外、再試行中',
	STATUS_UPLOAD: "アップロード中",
}